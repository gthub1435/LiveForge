'use strict';
const http = require('node:http'), fs = require('node:fs'), path = require('node:path');
const files = { '/': ['demo.html', 'text/html'], '/demo.html': ['demo.html', 'text/html'], '/live-layout-editor.cjs': ['live-layout-editor.cjs', 'text/javascript'], '/overrides.js': ['live-layout-changes/overrides.js', 'text/javascript'] };
http.createServer((req, res) => {
  const route = new URL(req.url, 'http://127.0.0.1').pathname, file = files[route];
  if (!file || !fs.existsSync(path.join(__dirname, file[0]))) return res.writeHead(404).end();
  res.writeHead(200, { 'Content-Type': file[1] + '; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(fs.readFileSync(path.join(__dirname, file[0])));
}).listen(8080, '127.0.0.1', () => console.log('Open http://127.0.0.1:8080 — preview mode. Ctrl+C stops this playground.'));
