@echo off
setlocal
cd /d "%~dp0"
if not exist "package.json" goto :extract
if not exist "package-lock.json" goto :extract
if not exist "source\install.cjs" goto :extract
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 20 or newer first, then run this file again.
  pause
  exit /b 1
)
node source\install.cjs
if errorlevel 1 (
  echo Companion installation failed. See the error above.
  pause
  exit /b 1
)
echo Ready. The installed companion stays in your user folder.
pause
exit /b 0
:extract
echo Please use Extract All on the ZIP first.
echo Run INSTALL-COMPANION.cmd from the complete extracted folder.
echo Opening this script directly inside the ZIP cannot install the companion.
pause
exit /b 1
