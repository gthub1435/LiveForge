'use strict';
const $ = id => document.getElementById(id);
$('id').textContent = chrome.runtime.id;
(async () => {
  const settings = await chrome.storage.local.get(['shared', 'tokens']);
  for (const key of ['shared', 'tokens']) { $(key).checked = settings[key] === true; $(key).onchange = () => chrome.storage.local.set({ [key]: $(key).checked }); }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let local = false, origin;
  try { const url = new URL(tab.url); origin = url.origin; local = ['http:', 'https:'].includes(url.protocol) && ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname); } catch {}
  $('local').hidden = !local;
  const send = async message => { const result = await chrome.runtime.sendMessage({ kind: 'lle', ...message }); if (!result?.ok) throw new Error(result?.error || 'Extension connection failed'); return result.data; };
  async function binding() {
    if (!local) return;
    try {
      const result = await send({ action: 'ping' }), project = result.projects.find(p => p.origin === origin);
      $('binding').textContent = project ? 'Connected: ' + project.name + ' ↔ ' + origin : 'Connect the folder that serves ' + origin + '.';
      $('source').disabled = !project;
    } catch (error) { $('binding').textContent = 'Companion unavailable: ' + error.message + '. Extract the full ZIP, then run INSTALL-COMPANION.cmd.'; $('source').disabled = true; }
  }
  $('browse').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('project.html') + '?tab=' + tab.id });
  $('connect').onclick = async () => {
    try {
      if (!$('root').value.trim()) throw new Error('Enter the full project folder path.');
      $('status').textContent = 'Connecting project…';
      const project = await send({ action: 'connect', tab: tab.id, root: $('root').value.trim().replace(/^"(.*)"$/, '$1') });
      $('status').textContent = 'Connected ' + project.name + '. Start local editing when ready.'; await binding();
    } catch (e) { $('status').textContent = e.message; }
  };
  async function start(mode) {
    $('status').textContent = 'Connecting…';
    try {
      const result = await send({ action: 'start', tab: tab.id, mode, allowShared: $('shared').checked, allowTokenOverride: $('tokens').checked });
      window.close();
      $('status').textContent = result.mode === 'source' ? 'Connected to ' + result.project + '. Double-click an element.' : 'Temporary preview enabled. Reload to discard changes.';
    } catch (e) { $('status').textContent = e.message; }
  }
  $('source').onclick = () => start('source'); $('preview').onclick = () => start('preview'); binding();
})();
