/* Packaged UI: no remote code or eval. */
globalThis.__LLE_BRAND__ = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAzC0lEQVR4nO29ebRkV33f+/ntfc6pqjt2t3pQSy0hCRAggQwoTMJYiogBD5BgpxXsxJZf4mdsyPOQxM4jxG7dBWZhx46TsB4YBzt+NsaxOnZ4xtiyDajbDEJIzBosgYZWd6vn7jtWnWHv/Xt/7H2qqmUkNaivQLh+a9WqunVrOHV+8/f33fvARCYykYlMZCITmchEJjKRiUxkIhOZyEQmMpEnLPLNPoCJTGQiE5nIt6s84RRjzsZRTGQiE5nIRCYykYlMZCITmchEJjKRiUzkW1++rYYVqiq7d2N2P+L5y+5EFxZEAf1mHNeZiKrKdbt3G9gJtL9gJ5ftRBdEwjfz2J4Sskv1DFBN/ZY0+F27HvfYRXV9jv1b8oR8vaKqIiKqqr1PN1zxqXvKqf4asrjkWF5Tv7g/rN740/OfExEl/uZvnUigKsRjn/69T3LFXQ8sdqbmO1p3nG7YkHHti3vHrhS5e72+/ilvALtUzYJI+JtKr/jTm0/d+LFPPvysk4eWafoVg6VlBstriM+Q/tFb1pb3v+HKG9956JL775TLdl7+d8LqHuCar/Hc2ZL2s4ffcyeGy3HZ+xe/63Of/Ozv7Pnk/RcvO4/NQDOwNmPLvPXf8+rn/O/3/vxLfwzoAyRDHpdv2Kif+gawa5fh8p3Zfrvt4x/56IEXv/L8uv4Hz9po6rJGmxoL3HzL/eGDf/WVwrrFP/IHfuUN3+xjfqRc9n0f/tu7PnPLs37sn31H/R3PO89UVYMYwVrLH33wC3r3oW7+2p0veesf/uLz3nH11Tdne/f+Q3e2vvupbQC7dhkWFsKb3t9/2t7bvnL3uXap85Fff0Ub5odSVUGf812/zgMHD538/lvf/kvnnzPlqRpjPGItajDiCAIEDBAADOqDOIt6kOBRAxICxhuCBoIapAlgQMQiXk3wBJGA5gaCGBN8UAOha4wqwQCUFdY6z+yGrjv48eMXfPhf/fZ/uPaqOf3oH//U39HH4aN9d9GLf9XOXXDRzcc+8X98N4yO8GxIdrY+6Jsph7+ybJePLIXnXioC6NJKjYgQVNEANi9kOm9gbmYLG6bec6IL2s3xxLgZAMXSWs5IC/E5T3yhBUQgPCLYCmAUMgGDJQuQKeQKHSydAF0PnWCZEeh2oOdz5jN46NzNfLhedefMbTIAJxcrrDV4r+S5pXYqU4XawdJgXc7dt4UBlKt9X6+VUpdZ0p2MbgJVHajrAM75ow87r1uE2ioqoJrcSZMi02caFSyKUSFTpaNRqSbdMgRRxQDWg1UlR6LSFTKvFAGKIOQBcqcUXiiAzINzcLwWFu+uQY1tXIrqYlCE2LMK/TLgm0DlB+tSuD61DWAh3Z86xWB5RUPV0RCgXwaMEVTBB8VYgzEGo0HOndJsy7SwHZgDOjI6CYFRbDUaz7eg2Fb5Id0QNGiMHopar5KpQGscAXAg6QNNUDIbI0JooGzANYoGo0crD80AQ0PjYVB6jBG8V2oHqgaDo+kv2vU4hU9tA0iy/767fL3mOXYcLRvYsKFDCNB4yDI4dAyWFlcwxmJ6lkuN180+Or1XCAg+FdEmKRJVFFEJ8TVVQH1QJCCtYTkPGqLyJSiqQBCMV6yPBmBCfGw9qFOaAUgD0ii5g8HAQ6jk+ImGJsD0bBeRGCGmpuCB/QMGyys+68zoWav8xuSpYgDytbucG4Ab7eDgoWOmax649fPLz/2nb/pT97znbJFyZQUNUHQyPv2Zr3Donru48PofZWrOIK6RhzGElAJAk9KBoIiChqhkjQUC3quoioZoMQSFEEC9ICEqWzQq2aZIgQfjwTjAQVOCbaBoIHNgBp7cTrFpyyb+5qOf5Q0/8j94xtPPpWlqFEORG/7iL2+jqY195gte8Ml7DgFX7zLsXThrReA3rQtQVHbvxNx5NB7D5Vujhu+8LN7fcEO8/xo979eWqe+7Ura84H/qWnUx/RL8QPCAG0CvyyWvupbtu36Ai56TcQFKTdS3pLAdkqJD9GqCSlR0iMagAYJPBhFk+JwmT0ejsiUpXzyQ/tYGXBmjQFZD4ZIRVAHKDnfdfh83/cmvsbZ4iJElTgFl6Gzaal5wzXf+xb/5Tz/6z697OsvxoM/wnJyBPOkGsGuXmsvvQq7bLf7re+eN9kouMfmOK7Ot02TSXbRFI2aNrKipi40Xb/T7//aWbUd+fOYd9hkbX+VOqbdqjLUNM+fMM3f5RjqbAjumAhkaK39t87SiPhWEQQg+GkCr5LY4CAHUxcdR+YoJMQJoigASoqJN7ATU1UhTRY/PxwwgbyBvFFNCs1Rwct8qJx8+RGgC3SKn6BRu9tKiWNmR/87737zpXzHS1VktBp/UFHDjTrXXLUTFv3RucdMrrpp+abenzzdGLlSVc5qGntPQcYHMB8lDoPCOzKvmQckUseAKF8hFZmywmK6Qk3fySpv8ootf0kxtNTL1enTlAAYH2VQ8c7mp2dqLYX8l9X9hqNyo7JBueCEE8CmMpz4xvi6lAPXxdaLR203qJ60fFYJ1gLIE62KqwCmkesB4RRx0Ee30atm+o8eFG5/JtEJPIJ+Hjd8Jn+iGDJBdqnZB5KyXAU+SAajoLkQWxP/IS8rnPOsi+ZmZKfu6qSm7PcviSfcKjYPKWXwA13pZatOci/deR717EAhGcZnSZOAbirXacaUlHNwYW7cNOSwBzhhKhTWnUQ/J49Wnx62Xa/Ty1vvHvZsQFRgrRxm+x/iUSnzsFrL0+WUpYppW6UrwEJxGY0hZPKhKx0J3xtObdkyL0LUwfY5IZz5jyoSLAb0B/MLXOrVPUJ4EA1DZFZUffuH763/z9KeZt5233U4VM0pnzjdFj+BqZHVZZXUZBn2oayhrcI1K44W6AQS8ExoPXlVqJ9ReaYJQBhgINBWcOoBsQLBd2CBQaPTE4wEGHhqFyjP08Fb5mrw9pPuo+Ij6tEUew//FmlRSuxdC9Pq2YAwe6gHgIhbQRoyQogYpirRGYBA1BqwI1qrkHSHLRTIvzE+ZbVytmYi4OM08e/kf1t0AVG7cibluQfwv/kD1m5dfmr9x7hwfznuOrzdfgF1dwu67W+2Br8LJY7C8Bv2+UjlwDdQeahf7YRcgBMUreDTWdz6dT5TGgveG1YeF2inToB2FBmSgUHql8kIVogH4EBUSwigSqB95vaRisM3rrVG0j81YbSAppYjG/r0sQVxq/drXufi++B2CpnSAghHEElsdTQbkKqRXK110G29cPYe9HBlClWdR1tUAbtyJuW63+P/7ddWvPO/ZxRvPOd9Vz3y5ZDObyO74G+XLH1dOnYRBHb3ZOdEyeb0LSuOJyveKD0og3rwqzitOYzHnVHEqeG+ol3L6lWVzEQGcZUUHDqk8lE6pg9A4jd7fVvfJe9sCb6jUEJVqUu5pq3vxowKyfV0sIBU3SIXgWDEoLn12+1o3SiuWGD1EFWNERGJqcY1KKEPoBGYv2FZs3g9HdoEsPFWKwBt3qr1ut/g3X9O8+tkXZ78we46rn/lyyeY2I5/848CXPwGurYtEqT1UdZDGg0OpG6WqFUWpm4Ca+Pdg4FEU21EwUIeAR2gCeBXKZWW57LG5C3WjElSisbhoTI2PAI5L4d+PtXqtR0rb2nmJ0G9QJEULCWDHwn8L+ARiq4eLNcCoUIw3SViABEWCIBqh5Mj1ia6tLRwh8bt9hZ/p2PwZ03r+frjzrt1nv2tbLwOQnTcSrhTNz9/W/Or8RuW8Z4nMbERu+7Dyhb0KPdGmhuUlkUGpsZjTqJh+P5AVQqfnOXE8ILlS9gNbzhVe98qCleXAxz4yYHnFE2yMBI1RAkK96Gn6XXQjMkjgnAbEOQgOvIsIoWtrgLbadyMwJ0aAqHycDhU/TAfJw00b2hV8ExG+YWrwnBYxcGBcnC0MsYL2M6UtbBWvQjAxovhKdTaDc4pwIcDRLU8RA9i5U42I+J++dnDNpvnuFdmUc3PbxH7ls8oX9wakKwxK6K8iT3u2kvfgjs9Bfy1QVsp5F8MP/miGGMvNN1V85C9Lul24/idnmd9oKSshmzK8/38cxxRKozEteANu1VGtzoOxsT5wbf8uhDp5v1caFYIfpYE2PLftnKQ+X/0oVOMFcXoaPqABXB093KToYTXCwa3yJbV+9hEFoCEOlQwa8WUDalI76hVfC5mHTZm5COCaa2DvWdbVuhjAZQndm5/JXt/rojPnSCgHmLs/rQxqwQusLCHf+VrhRdcqZV+4+LnCB97r8Rr4vutyul1l8ZRw1bVdbr1lwOw8TE8bHtrnMZlh/hxLVngq5/EyqgdC1dBfciiWWpEQ0NBAaBTXoM6D9yIhKCHIsPDTpLyQhj5t/xlSmzde9UcPjvg/TSr40vusBxsU49rHEQdoI4ZxI+9vizptCT0tNGnjcfkSbA3TyjMALl8HKtu6LA+/YQ8eVLKMlylI3lFz6D7lyAHFC7q2ivZm4fIXwfFDyqH9ypbtsHWH0jhHtyMsnoCmVlwNKg2HHq5YXlFmZzNmZjP2PdBneaUC4wnq8L7Bhxpf9llNBrDqFe8V60VpRNt8TKNILWhNVGADtolDG5MUKg6Mk+GNGrRStInQrrqANkAdx7u5h45Pc38PvQDTAe0pdCSOhI0DGyTiBi6+N9Sa0oigGhVPmkH4GiMNTAs7AHaeRSJIK+sQASJB81U7dJOB871RQoMcOwgr/VjolE2Q3ApVX2gaQ5ZDU8OxEzUnTzm+/EXHC1/Uoa4Nn/70MocOVxDg93/nGC95+QwHH6742EdPYDLFeU8IgUAghABNw4ljNSVQKfQQpFFoBNsgxqOmFkLy6JAqetrefgzZM6pYFQqFDkJh0vjYRKTPKOQdIVclc6IyhlIZINI9YxGJCuI1RpMm4QIhtrEqESRSCxQSwSKJx9b0YXZGzuU193ZEpDrbWMBZN4C2Vdm6pdxUezvrgw91KSyfVJyLIVjV6LFjXm6+SXnpKy1q4aY/HXDfvRXdaaO7f39JvvSFjLJ2fPmLA1DFFsrdd63ypS8t4oMn6wg2E7z62ByqR9WDq1k63tAAfYWug1CDNoqv0ViMxZCdEXN7LpBn0BWho9BRpQA66QQZH8keWTKQ0Ch1nRTmotKDqowPiIKLaCE+Rgzx0dO1HqWWEKI6wxilM+IQ0raLEgYBO63bNv3LZ24+eRMH2YWwcPZSwTriAF3qppGygqqEtVWlaaD2KlWjSAY3/2XNbbc6BqXn6NFAtycoXpTAZ29ZI4jS6UYCnlelUxhsZojooKce1DTB4YPH06Cd2NsNTlX0iSezqypbC2VGhSYbVd6ZxuKr9eS2Om8nfsPZgE+thI/YASFGK9/Efl7avr5NL462t40Kd0pwIHXiAXiNTHBNmE4MDsP2TxtFU/igUTGN+sKY6Yt7/fNPwsGdlyOPXPjyRGTdDMBrJc5bGoc0Neqc0HiVoLHSxQemp2D5lFI3MDNjcE5p6oj7G2PwzrOy5AgERAImU4oezMwZpmYsvZkO03OW6Q05xZRBpnOCFpy4vEOJY2MOz86F4wZWM6grqBw0DXiv+ATPeg9NyrstF6DFBh4JA7smtpOnIXtD5SvBSar8FXHRCKgZGoZgEpkgnqdW8UEVldOLUjzoQMNUx9qNU3YH8Bl2nl09rZsBVA7rPMY7tG5UnIs4Z1NBWUFVKWUFjTPxfDiPLZT5DYbpGWFmLmN2g2Fuk7BhgzAzZ5mZsUzNWIquxViDx1B56NdwclU5XgYWlwJ1CcELGBgkAKhuoGyUpknzhEbRdpTbTvgCaOIBtKBQG9Lx0evDOJrXKr9FEJ1Ao0NEUcZaQXyaKTA2W2A02NIUCRAhONA8pZsS7RnY1DPnA1y25+xiAetmAMF1QuMbGi/iGgmuUSnXYH6rsnU+MDtnmJkXZjZkzG4QZuZhekbo9WJuT90x3kWlDUpl0FcGNZw8GRgMHIMm0K+VlTKwWiv9oJSVMpiyVC7DAk3rTQnZI4yqfE3hWIOMiB9pBqCe5JqAV0IDPg4ektHE8N6OhdsIEDsERZr4nSbEKNASRLQtCNsTFYnMI/7BGIqoQaCEPMBcRy5cDz2tmwEYqdQ5o97HoQ0Gdv5fhue/HNRbhAjEVJVSDaAuY60wWFbKvlJVnqpS6jrQeIY3HyJi2ASlCREy9p4xHrAi/UDdQG6hDCPvHnq21xEun4Yvw9A7vG9bsljEeQckmrm0+IFr64CU833imHk57fPGkcG21mirOCXm/LYmGBpGG30awTTQM/I0gMuveYrMAqDC+SkNAR0M4Mpr4ZofEA5/NbB8EqqBUpUxL7tG8S7m4uA0DX8Erzrk4MvY7xZSnm4U1yjORazfhRBD+5qnqRSdjqNgafOpV9TJyLtaJpBPoFAK3SF5dPBK8IKvk4LS57REEm1GBBGCjgrARkZEkhb1U4mgS6vYBAINDbdlPeropqpog9CHwnIBnH0sYP1qADr4oOJUxHv0vIvh1CHlxOHoTc61s/jIrW+xcB0jaAYHzsVhThML/JZUA6IUXSGfhllr8JlQCwy8oZMRFW0Ul3j5beHVhmwN8fODV7yTIRw8nNunPO+Tlw/TSDKctso/TdEOaGSsaEyJPYE7kh5rqi9aqqsCmBg9QoiEkeBim9mUKsUAerO6nesf6IpI2S4oPRt6Wr8aQJGgKt5Hjp33wmAlDlaiC2tcZePBVeBdxOlDAEUwGXS7Qs8qNhdsAUXPIJkgGZhMYputQulgtYLFPiz1lZW1wMmBMrNZaIKSBU2eJ0MGUGTnRAV712L+Y6HbKa5pWT+J9h1kmD40KdyopMgCuMgRpI06Q8OTYW9v0s+PSJQgMv7a+M/YisaYJ42IrAWm59jSfc22LeX/y35uOHsrnNeVDxCCRGq1JnQrABoXVWBiVT09JxQ9ECNkHbAZmBwkI3qFkIggkWzhUvSok/LqWqkapUx1hGuUrIk4uhJrgG5ICzncWL53EFw8LtLfPozAG59axaHXDgvCaCTidRhJRAVt4qRvCDePpZ5xBbcsZDOW84dbVwQSOJ9GwwqiKn4Q/HSWTV3a0/O+BPt3Xr77rGEB61gEohpQ1Qi7tj8oqCJG8SVs3mHYemGayWvrmVHJTRPrgbaI9F4Jqjgv8W+NzymSqurk5cQhjOtHXTbJ4Fzy+Db0+yb27MHLaS1di+L5Fp9PaWPEBkpGMv7YRzpX5BFomiYq4iW1fTqMAO1QSUjrCSynKX6sOhymIWp8UWC3zYQLgFuPbtl51lrBdTOAplYNPTQEYouj8aRqiL8378Dm86GsYqEVGTWnkzSGdK206kZV0kKOKBpSrkwYvAxvCgMlN0KtI8X60NYfGj28Sd/t2/AOGieG0no3p92iwrVlB+moDpCEFrajZELkE8jwPk0BYXSsxM9VSQWqFdS2nUksWMmE0I9M4Q1dcwHEvQXO1lh43QwgLyTOVZJSw1jtqgFsESND8NGYQ6r4g56u7BB0uAqnnd23rZtvI0Ma5FiTZuxGmWriSfeQ+vk4cHEuhXcXMYbhSp8msXa9iD6SuNl2Ea1nh/H/j9YUyHj4H1b/8T2tEUgLAysgGiNBm9HH0kT7OjSOhLs1zGf2GWdbT+u2W3hTlxpUNYz31sl9h/1x/CtWvq1y21U3SekxZ8vo/QIigrVCngt5YckLg7VpMahTQhnoH/VtnYUfR+va6t9pqvaF4CRGhoT0tbcRyCPDUD9s9ULb/7epgeHjlivYPo7MIIkYAIl0oqP3GgUjcloUS+UP6hWpka6DmY5eBHDDNU+R/QG8jxOyln07bHQ1nuzW8rXtjdscKYI18f8iEs+GF0KjVJUyGATKgbK6piyvBpZXPcsrgeW+Z60JDJY9i0WXCynwxJpi6M1tnk/DnOBjLeAb1AdEtK3yEyXM67CYO21DgcQWMsiI+jW8jwVhSxIxYeT1MlxWLhiJtUOr7LZDEBhGHCuAU7ElzBo5D0DO4q5h61gDdDR0o9M63ybu1AEIDJYCS8css1sM0kQ6V6hinVBXUPaV/qqythoY9JX+QFlZ8VRlwHmhX/nI7VOhdiGigil9WATpB6pGMcQWVJTkvWD8GAiU2kDvhND26kHT1C7mcEl9fMsSjqBP4vbBKLyPgT42ebZtPZqxe5GW+IMRTcqX0WvSvgMmCFZAHMIa9GbCNt6kM7xbVs8WFrBuBmDz2gTfEedSjmbk6QYQAw983jN9jqCirC4FyjWNyq+Uqgw0TRzBKnE9QKwRoqIsCQfwSmYFsZFr70OCVtegqmHOCN6PCJpDmpaXtFBDW5q2kNrF8ZA+npdjBNAhpWvYzrWeP2YIrXFIWjreerjR9l6xJqYEi5DJiCJukEg6MYm3EAQzCDo1K5vmX1puWXo3q2cLC1hfHIAE/LS9f1v5AjYzGAmcPBgSlBuLPecVdYqxggkSlZ9OYBZdhsIoWUfIu7FKPnyo4cRSUKMqRhVjFNtXqKCTdtTJVOi07LsQe37vBddIHNMOK/1E1/aRwdOGfBlfJaSns3otohpUIoVchkVfTAOaAKDozTZxv42kvQOMYEQxApkR8gyyXDQ3KhYlV6BWsXUIM1nW2dGrt7/qRn0IRttJPhFZNwPQEtFCDSLtsvv4fMr5ADYT8jwVfia6eGYg6wq2EGwOeRfybnxsc8HmyduJnYILwvYdHb7w2VU5dMwPZwZ5pbi1QG8qtn6ZU6YNWImGpmJQwIW4gER8MtYWtUvj2+jFKfwnL7dDz9e0YwiQwr4ExaooqmLHDMWIDnO8kchCsu3Nilqjklno5pCLyozA7MYCW8SGI8vxF27Bvnxq7oLfukQ+xc4bz8qOIWfdABbSvTOJTpGcINKgErsGwZhYHE7NCVs2gGSCzWJ7aNI6KZBYb7WLOuo4/GnqFixSXIC8MJy3o8PDR2pMSovNUmBacrZsgv4MzOURHewLTFl0cdmJrwIu5WOncbXucDlYilaSvF+S97d5vQ3v7eZQqA4HPobWeNIeQiYWf/G1igWshTyF+QIkN0KRQWFgfsayvFXZ/eV9PHj4BF4b5FOlrcOqz2c6v/z2373/ordef/GvgYrE8/QNp4L1KwKlUtVOiNV96/6pBjCRS7/pPGH7pTKcBjZ1ujVp8JNYO0P2TmjDd+rJTdrcwce5gjUxwViFK6/scfKTD/Gn9x/BrSiuDJTLK/gGtm/ZIc969iXaK6wEFyKRQwSyiAdoaJU5QvyyEF8yzNM6MgAbVKJxaKzqVcUYVAJiTTQKq4oRwSIYCVgRChNzfZEJhYXcKD0x3N5U/Pr7PsaJ+/az9fxACCXa9CXDc+K4e/o9n33wnXff+9ziD97xsrft3Hmj3b0b/2h6eDxZNwPo0EFVRVt8PXk0GqnaWSFsu0QYrCp1OUL/vGtBoREsqm0NEVIqae09FYaiUfnWxFW5my/r8sn9t/OJ3/8KOzZafGhwgzW1qBw/NeC2Qw9z6cteKj/4o9dTDWrURvavAiGL96YFe5KyrcRizZDyt2oM64axHcWScRhBVMVKu3VcNBbber8RMhuPNxJSlSKDqY5o5az8Px/6LIMjX+ZTf/HDvOCK7VRV3Bag2+twx11H6mu+99fsX9/k/oWq/rKIeJ4AU3j9OIFBTGSIC9ZGoEPbwVBQOt1YC7g6vSFEcEZVUGS4aLOFg2G0758maHm4z5vGMKs+UHQybnv4MB/f80X+5De+j9d819OpqhoBsTbj+Mk1vv+H3sOXPvs5Dl3zGjZt3YaEul36H7EJk6jkpNBtIzPYauw+rIkG0tLGs1T8xdYt5X2JRV9MCTFy2PScbSv8VAPkWSSv9ApktWo4eOAOrnrJJl724gtZWfPkeQdroT/wPO95282zL7/A3n7HieJBKIDyiehpXQkhIeTDWbd3LdSaOPAJkVNOx/2Davo7onM+jBtBel+7RVvqDobdRQBP4KEHDnHxjnm+5xUXowI2zwFhUHku2DHP1d91OV/6xL30V9bYfn7EAtRGxNG06F4WF3CYEFOK9TIygrRi2ASJih1rB4ftHLGqt6JYSWsJUpTKDBgT21drIbOoMZBnhiNLFTR98VVGfxB/WymG5RXPxumcskSqtTUYLNvf/dATR3LXzQBcrSF0NO6qldbhDZdhjym1JWC0++49ckOmlpxx2nCI9JiEwZM8N6WYcm2JjilZ7XtsEY1PVWmauPdAORgANXlmyTOQbgrTIRaCJowt5fJp/YBGZedEzzdBNAcyUclF4mtEyRKKabNY65i46QPGxiLXiHhrRFWCCIgxIioaV4Y3hunVHvgq4GtU4Z4jgZ9/x4f59Me/zOu+92X82594BbnxUK7av/jrE09Yf+u8QUQM58Fpq5shxq+eUXs49nwL9rTRoOXt6VgUGMqotiSVwxCUpizJCxdHwE0cAKmmLWjiziOAJ3ilU8B0EQuxTJK3h7i+T4BMJFXuSmbi4wjdaizwNJE6ADEywhFMTGPexxE2QwDI5q6C4A3eQz0I+EYdPlQZduXA4RVHefjc4LeYrIB3vvcL7PmzW/ihf3IZf/i+P+ZDf3Y7m+ZmMdk+1/vSl/uw08I3Dg2vXw1QiEFG5JdW2+PDoREVmyFnoB23jmYHpPkAp88NxgwmcusioCLGJAJKQ8DGDiPt+lXXaam36QCW3iaYOTeCNHkhZHlrSIqoGUJt9TAqMVwP6NNIWZ3iSsWV4Prxsa8VreOMITMm8g1VdPGwMawN3jU/xW2hNmsa7OLaKV2u6rB2/HhYu/dgvnz/0v+2Uizecd9XdMtNe076w/uO2enpWj7w3h/hZ994NT/+pt/ny58/oPk55xZ3HtlzCey+NxrBZQpf//6B6zcOVkRD7ALaXS/aSV87mg2PVL5G2PeRosTi8LTn0nvbS0CIARHFimF6eobDDyzx6c8f4R+84HyqVEsoGV95sOG2278K3RlWL9rIvbNQDWIB6cuINYR+QNcCuqqEQXzsVhUdeHzp8WXAlz4uOfNAE1AX4r7CmcVmQrdrmdvQYcu5XWxhwasuLhv58w+e+qNjnP/Jxzp3Vl772yePhbf+0A/8n7a37TmUpYQ77z7Ii194Ibfu+QVZePsHw6/+xl9vO77Uu3Xuab/4luV9b/vN+M6dFnZ/XS3hOq4MaoyiMtx/py362pzfJvBhW5cUrDrM7cOQr3L6S9PLpX1O05TNGKgCl194Mfvu28sP/vP/yqWXXkBwA1zTICjHjpxk6eEHeMZVOznxEeXAhw4RKo0j3jokDn/A+DC2TDyBQ8RxoSJiRGJeF4l7+xvIOxlFR+h2M6Zmc2Y3ZGzebLAGQiW6NguXXtLZ9qYf0Yy7MJeDbzfGBGDhBhYAXy3ckHX/STlYOf6Pq2zj04LOnnPq1GrKdMI7375TvufVzwtv/tk/3HDn5w6/JzvnZ161ZduGnz1018JDyQjG4+djyjoCQaoSG7Wht8eNGlIaCIqqidRnRsptySCMGwjE/7aMIE3z87TiGxIoJELAcZHZxuu/94f5wh2f4sDxJRSXWLye2XM2c/lLrmGrfQnugUWmsggCBUnkEwG1sfEfTls0pQWyBGeIWoktrojBGCI/IbMUhaE3ldGbypidyZiZNmSiNALdAkStWVgQt3On2oVH3ywzuPKDbwfePrPhlf96+eFj7zp6bLUGMucCq67m6lc8W27Z8xa/a+F/+d94182vP7Taf/ncjn//c8sHfuUD8SPOLBqs3zRQWiJXyvcSq8AhP8CPdAxEQwitvpVxG4gyRgeT0T+G/PrUUxsjhLpie30+2y97Q9xDKLRookfE4AZCf7WPnYrovBKBHKsmkVNacxxFpfaLjSAtIUXExJl+ZsgzQ5YZiq6hN2WZnrJMzximpxJQ5ePG1T5kGcDRo3tOz2mni8BrCripFtzfUlccOHjCQExlmbUsrzRkeSH/+df+Rfaa11zR/PTPvn/rPXce/INsw0+8trNp9mfW7v/1o+2Zeiw9rRsjSKRQ9WgIGrH91N/7lmkz1ha0Xt3SxrSFYMd0MJShwZweHCRFBUHiwlJtKE/28YsV4VRFWCphxeGWKkIzoNuxFNaSGxPRODFkRiisoZNbOllGkVuKzGiRWYo8o1NkdApLp8go8oxeN6PbG913e5Zez9LtWnpThm5H6BRKkUOei2YR8DmTc67wkgbQTiFH0EofOrBoIHEsE9WpaTwnF2v+0T+6wn587y7/4z95VeOWlt6wdujkbXb++mvi5+x6zO9bNwMwValx0wZAE6jjIsAzXHbdKjyF/ViBSxtmT3PAttcftlwtiyYxh2IhGD/DiGDFkBexIMtyyHJLlhvy3FBkltwacivkRsitiVCyCFny5jw3dHJDr5PJdK/Q6amCmemcqekO09M5U1M5na6NhtQxdDqGqeksen/P0u0YihwKC51CyKySC/S6WRF/1TWPcwZvUIDNc3PHwK3sP3DEAENuZJtSRYyePNXo9Mw0//09P2U/cvOucvO8vVAHg/ddeeVP5LDwmBFgHVcGQc4w8qdFIDrcGWOcJNq28DIM7ZHs0j7fBrL2z3HvF4SiYzh5wlFXSmZNxA9MGxVi+pcQcQVJUHIgLseOEF68QJOxgskMxiSalo0pIoQwTGhKTDPGxP7fCGSZkGWxlex2DJ2uIc9FbQY2i/BAp4iQr9HQPbMzGH/tK1/aOXXXbeH4w4dOzdUODSrSYiNthByUnrvvPSa33HoPt33mzm7lhRDqZmbmnsctBNdvZVD0ZxmndROE4MNw9c9Iw2mV0CNq1/aEtyCfNXGMrCJDbMEHWF5y3H/PWoyPrcUl8ECI0KtLdUjRiZtMZIUZKlxMDIQqQnCxZmiPI3pcLGdjQZPqDStDQ7HJADp5VH7RgaKj0ikiwUNE0ULodMDV4Uzn+ArIu971MxXyTw8fO756SX/NKWJoXLQAH5QNGzry/g/s5ef+9btJm+wdIpv5Ykb5tr1797qYAh49CqzrLICQZjYteBNGFHFXc1obOJ7qsywqI2uRQRdHxnWtDPqB1dUQuYKrgbJWlpc9dRMvExN8ZNmEROA0YvAhML8hY8vWKSQTApKWooXRimMHwYchEISkmkJAjE222pqjpijQQr1CXkCnG++LQugUQpHH32IEpBDyDoglP/NzuNPAbo81B44dXWFpuc/U9BwARccyGDS6tOz44Te8nN/7vQ/zxc/eF8592qXXP3z/uz/qhp/x2ODQ+jGCVARRUQ2omLjhURXn+gDLJ5Wl48L8FqjbTZuayAeoSyjXlP5qiMTQFc/aaqAsA1UVqGql8SPIKCsM3cJibCyQ+n0/5NuhaGcqk4ueMUvj0nLyOgwpaMO20kBkAGiqT+Olm1TSVrGjgQNGbKSdWcEaE2lcBRRdoSgiyynPNdLW8/TWTOPUL7fFmZ/Fo/ELLQeWltY48PCivvCFc9x6+8P81ns/pL/xn98k/X5JPtPVd73rp/XVr3prcfjg4V++7LKdH7/rrqMB9rY85keVdTMAkUIjG6StXBPGn1jB6pR7bw1suSROxFaWosLLNWGwppSDEFE5ojICASwUhWFmNlLGOtMmrhDuGrI89uMgHNhXcfBASW5F60aZn4/TwKYJaVOIeIxhGM5N3FDQRNCS0LacCQswbV1CKjLje3IbPdwWQpYRi76caAAZFEX8mxDXO3a7kNu45+Q1nPnqnsz4fW6wxsmTy5QNvOUt79NP7/1L8+znPCO8+U2v4siRNa74jovkrb/4z5r/8O/e/ZKvHjjnLbB34UywgHWMALVoavFOg319BHDECtrAQ3eiTRnEpxVAmpbQdrqG2Q1QTAtZV+lOCd0pQ941iB3NAXyIQ552jwBV2Lajy4ljDWXlU0QXXNrNS8cCogGCqoiJ/1KNqwzteJuBgppYyaWnsywSVG0mZBayPIb3TtGmAOh0ZGgQaCxEixyCD19H57VVAfKCA26wHOq65J3/6UPh03tvzore1vqXF/5L/qIXPTs8/4oLuf/BNfmxf/k6c/Oeu8Nff/hvfu6SS37yPfff/5tHUw3wqGlg3aHguEw8grZxyBMnZcErrhYKi8xvN2Q9KHpCPhWJoFkBpogwawijDSRcE3cbc+0av+ESMiIfwAMGsjzCwsMOI1UZYhJrN7WOBFFCXMRpNBanasYQFBl5vkgkbmRFjFo2jXjzHPJC6HUZGkCvFz2+2431iJMEgzeyCGd6TeLLFMA11YNkU+atv/R+uf/+Y5nJpv6qV/h3Li0NPvILP/8u/eD/9yuyZcs0h482urbmEOrCuZVUbC485jesIxIYKaAtITQCPS0XH5pamN0Mlzwf8l4ifyaE0DloXCR/tiuEh6uHdayNTJ/doopBIybf+Dj7NyYtS9fRNFGkBT8ETW3ccKJkY0Rpp4uaRsBiEisoEThsFls/m0OeScr3UeFFR+gU8XGvC51urGkywayuwMqy3gewdeuZYPULATBN/8++SPaa373nS3ddj5EvUGQ/sbT05/vy3j9+2x2f+9yu//hL7yuvfeVV8rZd7yn23/dVsR35rw899AeHHs/741k46xIvsXvZ3B3PmJvafMf5W2aLp23thJd/r0ovhxOHRm3h818t2I7SX9OhUkOI+wAMWUNjncOQN9h2Fgph+BPiApCmUfY/WHH8aI3JYsTYtLnDxi0dykG8OmBMSaPtZ5C2UkqrgxKkLCJxxtCSO7LE5s0MeaFkmWBsVH6nI+keej1hakqZnRGmZqC/hEow5sZ3u9Xf/u3m0n3MHOYb4PHNzFx72YYN9z5w4MCBAVydwd5g8mv/PDSdV0dC2+BU1rH/0VV73g1ndo3hdYgANwAgtl+F4GsNdJq08NKbOEdvamV2k2ByWFsZ1QkujChjbTQYYf0JfzcR1KnruE6wLAPVIC4fGwwCK6uOahAwWYSThTjvb1N6SCVR+3zbS1gTcQlt27ssfpfNBGM0pQEdRoFxIMgayCxjnq/0uvHCj0ah18WfOGDMvnu4eR8zh3WXGln4ukkcsrr6sbtWV9vDjxV+aA6/Lu+cd71K2DTTzf7n4uLN+87E81tZDwNQWODQqXuWnrlly6oPMjuo4waQ5FA3qG8QV6ftWZp22/ZRdW4S/1podwGBwQD6q57V5YQBrCllHXcRa+lkYuPNGBOZyCZ+YFWnZVgqiEGNIqZjGFLWBUxaW66alqOnXcFCnf6fgdhY7YvGaaHJYuE3NRVDfa8nUfk9YXY+XiT65CFlfpPhlpuQ/Q+E/wJw3V3fUOTVMVBnLHbdVTfVXf8dYLGEWPkvnDEnYB0MQBRUTiLLjd7zoHNsr2t0+YTKhhkTt25XOHUUTh6CuS1xezijQlPDoK+sLSury7CyBGvLIV5HqAqp90/eaGIyb8expFZNA6hoYiFHr+2vBE4dbZjdkOGcivfg68gUaomnPvg4ZNH2c2Olb2zL70utXhYRvW4vKr3bi/sbTk0rUz2YmhZ6vXgBqyP7YPM2U99xs+3e+rH+7/7Vwembd+5Uu/vRx8Dj07uvMcn7O16d4uPVqeDbG74lCCFXs8fuBVf5/t6y9i+rXR4OH8Fc9PS4X4xv4grgL3xU2bwjFnmLp2BtJTBYU60qxPl2kZci7WpSG7eXGbZzmip2jZs2qMTCTmJhn4ZDkdt34phneTEgJu1b5ImebeJSs/haM1q2lcVUkBexO+l0oTcVc3p76/ZiB2Algki+hKVVOD5ArdGwcQt6xx7b/aPfqj7xkc8vvnnXLjULC4+al+UR92cqCnvd47/ssb/0LMuNFq7zF0595IVbpy+8/fxN5/mtWwr5/teLnDgAiyfTSiAXrxLWNIpPvXekf6V9+2SMHUQM6aMIABhNVDDiyJlYgg6h3HQ5LmNGuV6kVXaCcTMht3HdYZYn8KYXt4Evukq3F3t7m41SUmjA1aKhUlyNBodaK9rrKtOzyPQ8WWYyufNWuOXm5gN3fnX5pz5zcvNyxBUfs/B7pD6+riLxG5F1MgDYhZoFJFw6f8tNF2y89NVz3an65ddk2TMvhvvuSDuHt5eGqzVdFq6t9lM4h2QEKdIZhlBte5211hiioqNxaOrZjUlVvIktXJZDkQudPMK2eSfiDVkRq3tNAynvoOyjdQn1AK0HqHeod7FdyIyaToHt9DLp9SLAY0w01LKCE8dcdehBPnPgQP3fPvzA9P+KZ+SMq/5xnTx1DaBtB8+f/vMrNnUvuH3Hxh0yN92V177OChUc3A/9AVrXxCuF+XafwLjz1+iX6zBmRmVKSglJsUn51sTePM+jt3Y6UcF5AVkeN6WSLL4vRR+tShisqQ4GomUfLQfxcm3qRQhirbEyrPLTYAeJu5bVVe19kOPBc7Qpw6FqEB5qnHlgUMpXD+zXL3yp7t4L8VrJCwstZeVbT9bRAKBNBRf0bvqp8+Yve/eW6XPqTZvFfvd35yI1HDqArq2o9JuYDtrr+UWMftS6qWraEyjCrpmFLIvwcN4R8o4m0kfE3J2DxqN1jZaVUpaiVYn2V2FQIk0lpmmwBDsildCCScTrE1DX6jnlvR52jR50Luz3XvYF5w+WtTlQrumh+1f9oSU2Ln6tX66qct11mMco+L4lZJ0NAEAtiL9o+q/ece7cc98yV0z7DRuzcNVVmd2+2bC6JCydDAz6MKgSEgcpH6cNEwqJ+wTkgIltmli0duigVAaVCSsrymAA5QCp+piqMVaDGaJ/wPAKHS40+FAPQvBL3uux4MNhH9gfNHy1rtw+H8z+pbo8dHz5xPElXrD4eL9w1y417IkA4x72cM3ea8LCE1is8WTKk2AA0BrBju5N/3bz9I5f3TxzkTHGu4uelodLn2XMpg1WMkFC2rrNB8Uh6jw6GKj2S6VfqZZ9Ya0UWV1TW9cYV2X4xqSZfvwmQyAwwGtZgh7DcMyrf7hx+lBwPOjxD5X9+sF+XR3ZV504Ad+58nhHv2uXmj17RvS5rXvRy0AXRkyGb8nwfibyJBkAtOlgS3f3VRu7F94w29n03T2zlSIXpqeV6WkNnUJUMFSNSH9gTFkLTW3ijt2J0qU0eF0jaL2ihOOqetiHer/C/iDhQHC6v2rqg65xhx4sbz8Gb+w/3pHtQs2eq5OC9+5hK9fo7hFV5Smr3DORJ9EAoDUCgHO7f3L1XGf7Dxa29wohv8hoPm+kEB9n/w3il8GfEAnHjejhIP7BJoT7nW8earQ5sFofO3Ji8PnjsFA/3rfuRO3R4W/dw1aO6W52/r1Q8OPJk2wAkOgVOt4PT09/YNumYttmI35Wfdb0B4OVqj5+YoXrl4ibuz36p6FyHZhWwVtBd7MbuFMjLP33W8HfwnKjvZqbHxeJVFR2ovZqbs6u5uZsZ1zJbyIurt8EA57IOohKVOqNSbnaKvfbScHyKI8n8vdQnogBTIznKSxnS3nfbtHx21YeqaiJ0iYykYlMZCITmchEJjKRiUxkIhOZyEQmMpGJ/D2RcXh0Ao1+k2Xdtol7FPlaCx++USN4sgYiEyOdyEQmMpGJTGQiE5nIRCYykYlMZCITmchEJvIUl/8f5iX1n56mOqMAAAAASUVORK5CYII=";
globalThis.__LLE_BROWSER_PLUGIN__ = function browserPlugin(config = {}) {
    if (window.LiveLayoutEditor) return;
    const properties = ['translate', 'width', 'height', 'min-width', 'max-width', 'min-height', 'max-height',
      'color', 'background-color', 'font-size', 'font-weight', 'line-height', 'letter-spacing', 'text-align',
      'padding', 'margin', 'gap', 'border-width', 'border-style', 'border-color', 'border-radius',
      'display', 'position', 'top', 'right', 'bottom', 'left', 'z-index', 'opacity',
      'flex-direction', 'justify-content', 'align-items', 'grid-template-columns', 'box-sizing', 'overflow', 'transform', 'object-fit', 'box-shadow', 'fill', 'stroke', 'stroke-width'];
    const local = ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);
    const sourceMode = local && config.source === true && config.origin === location.origin && typeof config.request === 'function';
    const bridge = sourceMode ? 'native' : local && config.origin === location.origin && config.base && config.token ? config.base : null;
    const copy = value => JSON.parse(JSON.stringify(value));
    const blank = () => ({ version: 1, revision: 0, pages: {} });
    let db = copy(window.LiveLayoutEditorSaved || blank()), revision = db.revision || 0;
    let selected = null, active = true, destroyed = false, drag = null, inline = null, advanced = false, menuOpen = false, menuPosition = null;
    let selection = [], marquee = null;
    let undoStack = [], redoStack = [], dirty = false, saving = false, blocked = false, ready = !bridge;
    let timer = null, applyFrame = null, path = location.pathname, changes = 0;
    let feedbackTimer = null, feedbackJob = null, feedbackItems = [];
    const panelPositions = Object.create(null);
    const hiddenRecords = new Map(); let hiddenListOpen = false;
    let panelGesture = null;
    let cssFocusProperties = [], cssFocusLabel = '', pendingActionPages = null;
    let cssOpen = false, cssMode = 'normal', cssPrevious = 'normal', cssSaved = null, cssRowsKey = '', cssLast = 0;
    let panelMode = 'normal', previousPanelMode = 'normal', panelNormalStyle = null, panelNormalPosition = null;
    const originalPageAttribute = document.documentElement.getAttribute('data-lle-page');
    const originals = new Map(), detachedNodes = new Map(), cleanups = [];
    const host = document.createElement('div');
    host.dataset.liveLayoutEditor = 'ui';
    host.style.cssText = 'all:initial;position:fixed!important;z-index:2147483647!important;inset:0!important;pointer-events:none!important;';
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `<style>
      :host{font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif!important;
        color:#17233d!important;font-size:14px!important;line-height:1.5!important;color-scheme:light!important}
      *,*::before,*::after{box-sizing:border-box}
      #panel,#inspector,#quickbar,#launcher,#outline{
        font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
        font-size:14px;font-weight:450;line-height:1.5;color:#17233d;text-align:left;letter-spacing:normal;
        --ink:#17233d;--muted:#455570;--accent:#6242d7;--line:rgba(95,105,147,.23)}
      button,input,select,textarea{font:inherit;letter-spacing:inherit}
      button{appearance:none;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:6px;
        min-height:36px;padding:8px 12px;border:1px solid var(--line);border-radius:11px;background:rgba(255,255,255,.8);
        color:#263450;font-size:13px;font-weight:650;line-height:1.25;box-shadow:0 1px 2px #192a4d06;
        transition:background .16s,border-color .16s,box-shadow .16s,transform .16s}
      button:hover:not(:disabled){background:#fff;border-color:#aa9ce7;box-shadow:0 3px 12px #6242d715;transform:translateY(-1px)}
      button:active:not(:disabled){transform:translateY(0)}
      button:disabled{color:#68758a;background:rgba(235,239,246,.8);box-shadow:none;cursor:default}
      button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible,summary:focus-visible{
        outline:3px solid #8b73ea;outline-offset:3px}
      button.primary,#done{background:linear-gradient(125deg,#6e4be5,#5136bd);border-color:#6242d7;
        color:#fff;box-shadow:0 4px 14px #6341d72b}
      button.primary:hover:not(:disabled),#done:hover:not(:disabled){background:linear-gradient(125deg,#7956ed,#5c3dcf);border-color:#7657dd;color:white}
      #panel,#inspector,#quickbar{
        background:linear-gradient(130deg,rgba(255,255,255,.42),rgba(239,233,255,.2)),rgba(242,246,255,.88);
        -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
        border:1px solid rgba(255,255,255,.92);outline:1px solid rgba(101,110,155,.15);
        box-shadow:0 16px 48px #28385b24,0 4px 14px #6651b00d,inset 0 1px 0 #fff;
        pointer-events:auto;isolation:isolate}
      #panel{position:fixed;left:18px;bottom:18px;width:min(740px,calc(100vw - 36px));max-height:min(250px,calc(100dvh - 36px));
        overflow:auto;padding:18px 20px;border-radius:22px}
      .panel-drag{cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none}
      .panel-drag:focus-visible{outline:3px solid #8b73ea;outline-offset:4px;border-radius:8px}
      .panel-drag.is-dragging{cursor:grabbing}
      .drag-hint{margin-left:auto;font-size:11px;font-weight:500;color:#596581;letter-spacing:0}
      #quickbarDrag{display:flex;align-items:center;gap:12px;width:100%;padding:0 2px 7px;margin-bottom:2px;
        border-bottom:1px solid rgba(98,87,149,.14);font-size:12px;font-weight:650;color:#455570}
      .dock-header{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:14px}
      .brand{display:flex;align-items:center;gap:11px}.brand strong{display:block;font-size:16px;font-weight:750;letter-spacing:-.4px;line-height:1.3;color:#17233d}
      .brand>div{min-width:0}
      .brand-caption{display:block;font-size:10px;letter-spacing:1.8px;font-weight:750;color:#596581;margin-top:3px}
      .brand-mark{position:relative;display:grid;place-items:center;width:39px;height:39px;flex-shrink:0;border-radius:13px;
        background:linear-gradient(135deg,#7657ec,#5840bf 60%,#358c9d);box-shadow:0 4px 12px #6242d72b}
      .brand-mark::before,.brand-mark::after{content:"";position:absolute;width:15px;height:15px;border:1.5px solid #ffffffed;border-radius:4px;transform:rotate(-15deg)}
      .brand-mark::before{top:10px;left:9px;background:#ffffff20}.brand-mark::after{top:14px;left:15px;background:#ffffff12}
      #close{background:rgba(255,255,255,.48);color:#47536c;font-weight:550;font-size:12px;border-color:rgba(95,105,147,.17)}
      .row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:8px 0}
      .toolbar{padding:0 0 12px;margin:0 0 11px;border-bottom:1px solid rgba(98,87,149,.13)}
      .button-icon{font-size:17px;line-height:1;font-weight:500;color:#64558e}
      #flush{margin-left:auto}#resetPage:hover,#hide:hover{background:#fff0f3;border-color:#eab9c6;color:#962f50}
      #mode{display:flex;gap:8px;align-items:flex-start;margin:0;color:#314a58;font-size:12px;line-height:1.6;font-weight:550}
      #mode::before{content:"";display:block;flex-shrink:0;width:7px;height:7px;background:#178476;border-radius:50%;margin-top:6px;box-shadow:0 0 0 3px #16897b12}
      #status{margin:8px 0 0;font-size:13px;line-height:1.6;color:#334466;font-weight:500;overflow-wrap:anywhere}
      #inspector{position:fixed;right:18px;top:18px;width:min(340px,calc(100vw - 36px));max-height:calc(100dvh - 290px);
        overflow:auto;border-radius:20px;padding:18px}
      .inspector-title{display:flex;align-items:center;gap:8px;margin:0 0 10px;font-weight:750;color:#27364e;font-size:14px}
      .inspector-title::before{content:"";width:7px;height:7px;border-radius:2px;background:#7351dc}
      #target{overflow-wrap:anywhere;max-height:70px;overflow:auto;padding:10px 12px;background:rgba(255,255,255,.65);
        border:1px solid rgba(120,116,165,.16);border-radius:10px;color:#4d426e;font-size:12px;font-family:ui-monospace,SFMono-Regular,Consolas,monospace;margin:0 0 14px}
      #quickbar{position:fixed;display:flex;align-items:center;gap:7px;flex-wrap:wrap;width:min(550px,calc(100vw - 16px));padding:12px;border-radius:18px}
      #quickbar button{min-height:34px;padding:7px 10px;font-size:12px}
      #quickbar label{margin:0;display:flex;gap:5px;align-items:center;font-size:12px;font-weight:650;color:#344461}
      #quickbar input[type=color]{width:34px;height:32px;padding:3px;margin:0;cursor:pointer;border-radius:9px;background:#fff}
      input[type=color]::-webkit-color-swatch-wrapper{padding:0}input[type=color]::-webkit-color-swatch{border:0;border-radius:5px}
      #quickbar input[type=number]{width:59px;margin:0;min-height:32px;padding:5px 7px}
      .grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:10px}
      h2{font-size:16px;margin:0 0 8px}p{line-height:1.6;margin:8px 0}.muted{color:#455570;font-size:13px}
      label{display:block;font-size:13px;font-weight:550;color:#3c4c67;margin:8px 0}
      input,select,textarea{width:100%;min-height:38px;padding:9px 10px;border:1px solid #bdc5d8;border-radius:9px;color:#17233d;
        background:rgba(255,255,255,.93);margin-top:5px;line-height:1.5;box-shadow:inset 0 1px 2px #192a4d04}
      input::placeholder,textarea::placeholder{color:#596780;opacity:1;font-weight:400}
      input:disabled,textarea:disabled{background:#e8ecf4;color:#576780;cursor:not-allowed}
      textarea{resize:vertical;min-height:80px}select option{background:#fff;color:#17233d}
      details{border-top:1px solid rgba(98,87,149,.16);padding:12px 0}summary{cursor:pointer;font-size:13px;font-weight:650;color:#344461;padding:3px 0}
      details[open]>summary{color:#6242d7;margin-bottom:9px}
      #selectionMarks{position:fixed;inset:0;pointer-events:none}.selection-mark{position:fixed;border:1px solid #7956df;background:#7956df08;pointer-events:none}#marquee{position:fixed;border:1px solid #6242d7;background:#6242d71a;pointer-events:none}#outline{position:fixed;border:1.5px solid #7956df;box-shadow:0 0 0 3px #7956df18;border-radius:3px;pointer-events:none;display:none}
      #move{position:absolute;left:-2px;top:-39px;pointer-events:auto;touch-action:none;cursor:move;min-height:30px;
        padding:6px 12px;background:#6242d7;color:#fff;border:1px solid #8f76e5;border-radius:9px;box-shadow:0 3px 10px #6242d730}
      #resize{position:absolute;right:-7px;bottom:-7px;width:14px;height:14px;min-height:0;padding:0;pointer-events:auto;touch-action:none;
        cursor:nwse-resize;border:2px solid #fff;border-radius:4px;background:#7956df;box-shadow:0 0 0 1px #7956df55}
      #launcher{position:fixed;bottom:18px;right:18px;pointer-events:auto;background:#6242d7;color:white;border-color:#7656dc;
        border-radius:14px;box-shadow:0 6px 22px #6242d730}
      #feedbackLayer{position:fixed;inset:0;pointer-events:none;z-index:0}
      #panel,#inspector,#quickbar,#launcher{z-index:3}#quickbar{z-index:7}#outline{z-index:2}
      .effect-area{position:fixed;pointer-events:none;border:2px solid var(--effect-color);border-radius:7px;
        background:var(--effect-fill);box-shadow:0 0 0 4px var(--effect-halo);transition:left .1s,top .1s,width .1s,height .1s}
      .window-controls{display:flex;gap:6px;align-items:center;flex-shrink:0}
      #panelMinimize,#panelMaximize{min-width:32px;min-height:32px;padding:5px;font-size:19px;line-height:1}
      #panel[data-window="minimized"]{width:min(420px,calc(100vw - 16px));max-height:none;padding:10px 12px;border-radius:16px}
      #panel[data-window="minimized"]>.toolbar,#panel[data-window="minimized"]>#mode,#panel[data-window="minimized"]>#status{display:none}
      #panel[data-window="minimized"] .dock-header{margin:0;gap:8px}
      #panel[data-window="minimized"] .brand{gap:8px;min-width:0}
      #panel[data-window="minimized"] .brand strong{font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      #panel[data-window="minimized"] .brand-caption{display:none}
      #panel[data-window="minimized"] .brand-mark{display:none}
      #panel[data-window="minimized"] #close{width:32px;min-height:32px;padding:4px;font-size:19px}
      #panel[data-window="maximized"]{inset:12px!important;width:calc(100vw - 24px)!important;height:calc(100dvh - 24px)!important;max-height:none!important;z-index:5}
      #panel[data-window="maximized"] #dockDrag{cursor:default;touch-action:auto}
      @media(max-width:480px){.dock-header{gap:8px}.brand{min-width:0}.brand strong{font-size:13px}.brand-mark{display:none}#close{max-width:82px;padding:6px}}
      #quickbar{width:min(390px,calc(100vw - 16px));max-height:calc(100dvh - 16px);overflow:auto;gap:6px;padding:12px}
      #quickbar>button{flex:1 1 calc(50% - 6px);justify-content:flex-start;text-align:left}
      #quickbar>label{flex:1 1 calc(50% - 6px);justify-content:space-between;padding:5px 4px}
      #quickbar #inspector{position:static;width:100%;max-height:none;overflow:visible;padding:12px 0 0;margin:4px 0 0;border:0;border-top:1px solid #c2b8df;border-radius:0;background:transparent;outline:0;box-shadow:none;backdrop-filter:none}
      #inspectorDrag{cursor:default;touch-action:auto}
      .brand-mark.has-logo{background-color:transparent!important;box-shadow:none;border-radius:0;background-size:contain!important;background-position:center!important;background-repeat:no-repeat!important}
      .brand-mark.has-logo::before,.brand-mark.has-logo::after{display:none}
      #cssPanel{position:fixed;right:18px;top:18px;width:min(440px,calc(100vw - 36px));max-height:calc(100dvh - 36px);overflow:auto;padding:16px;border-radius:18px;pointer-events:auto;z-index:4;font:13px/1.5 system-ui;color:#17233d;background:rgba(245,247,255,.94);backdrop-filter:blur(24px);border:1px solid white;box-shadow:0 12px 40px #17233d33}
      #cssDrag{display:flex;align-items:center;gap:8px;font-weight:750;margin-bottom:10px}.css-window-buttons{display:flex;gap:4px;margin-left:auto}#cssDrag button{min-width:30px;min-height:30px;padding:4px;font-size:17px}
      #cssPanel[data-window="minimized"]{width:min(360px,calc(100vw - 16px));padding:10px 12px}#cssPanel[data-window="minimized"] #cssBody{display:none}#cssPanel[data-window="minimized"] #cssDrag{margin:0}
      #cssPanel[data-window="maximized"]{inset:12px!important;width:calc(100vw - 24px)!important;height:calc(100dvh - 24px)!important;max-height:none!important;z-index:6}
      .css-row.css-active{background:#e8dfff;border-left:3px solid #7956df;padding-left:7px}.css-row.css-active code{color:#5030ad;font-weight:750}#cssActivity{padding:8px 10px;background:#ebe4ff;border-radius:9px;color:#5030ad;font-size:12px}#cssFollowLabel{display:flex;align-items:center;gap:8px}#cssFollow{width:auto;min-height:0;margin:0}#cssTarget{overflow-wrap:anywhere;font:12px/1.5 ui-monospace,monospace;color:#455570;margin:8px 0}.css-row{display:grid;grid-template-columns:minmax(120px,40%) minmax(0,1fr);gap:8px;align-items:center;border-top:1px solid #dce0ef;padding:4px 0}.css-row code{font:11px/1.4 ui-monospace,monospace;overflow-wrap:anywhere}.css-row input{margin:0;padding:6px;font:12px/1.4 ui-monospace,monospace;min-height:30px}.css-rule{white-space:pre-wrap;overflow-wrap:anywhere;background:white;border:1px solid #dce0ef;border-radius:8px;padding:10px;font:11px/1.5 ui-monospace,monospace}#cssNotice{color:#455570;font-size:12px}#cssCount{font-size:12px;color:#455570}#cssPanel select{font-size:12px}
      #hiddenMarkers{position:fixed;inset:0;pointer-events:none;z-index:1}.hidden-marker{position:fixed;pointer-events:auto;max-width:min(250px,calc(100vw - 16px));min-height:30px;padding:6px 10px;border:1px dashed #ae5b8c;border-radius:10px;background:rgba(255,241,250,.96);color:#703251;font:600 12px/1.3 system-ui;box-shadow:0 3px 12px #71305120;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      #hiddenRack{position:fixed;left:10px;top:10px;z-index:4;pointer-events:auto;font:12px/1.4 system-ui;max-width:calc(100vw - 20px)}#hiddenRack>button{background:#fff1fa;color:#703251;border:1px dashed #ae5b8c;font-size:12px}#hiddenList{margin-top:5px;padding:8px;max-height:min(300px,50dvh);overflow:auto;width:min(320px,calc(100vw - 20px));background:rgba(250,247,255,.97);border:1px solid #dcc4dc;border-radius:12px;box-shadow:0 6px 24px #17233d20}#hiddenList button{display:block;width:100%;margin:4px 0;text-align:left;justify-content:flex-start;font-size:12px}
      @media(prefers-reduced-motion:reduce){.effect-area{transition:none}}
      a{color:#5b37c4;text-decoration:underline}[hidden]{display:none!important}
      #panel,#inspector{scrollbar-width:thin;scrollbar-color:#aaa0cc transparent}
      @supports not ((backdrop-filter:blur(1px)) or (-webkit-backdrop-filter:blur(1px))){#panel,#inspector,#quickbar{background:#f2f4fd}}
      @media(max-width:600px){#panel{left:10px;bottom:10px;width:calc(100vw - 20px);padding:14px;max-height:230px;border-radius:18px}
        .dock-header{gap:8px}.brand strong{font-size:14px}.brand-caption{font-size:9px;letter-spacing:1.1px}.brand-mark{width:34px;height:34px}
        .toolbar{gap:6px}#flush{margin-left:0}#inspector{top:10px;right:10px;width:calc(100vw - 20px);max-height:calc(100dvh - 270px)}}
      #quickbar{width:min(390px,calc(100vw - 16px));max-height:calc(100dvh - 16px);overflow:auto;gap:6px;padding:12px}
      #quickbar>button{flex:1 1 calc(50% - 6px);justify-content:flex-start;text-align:left}
      #quickbar>label{flex:1 1 calc(50% - 6px);justify-content:space-between;padding:5px 4px}
      #quickbar #inspector{position:static;width:100%;max-height:none;overflow:visible;padding:12px 0 0;margin:4px 0 0;border:0;border-top:1px solid #c2b8df;border-radius:0;background:transparent;outline:0;box-shadow:none;backdrop-filter:none}
      #inspectorDrag{cursor:default;touch-action:auto}
      @media(prefers-reduced-motion:reduce){button{transition:none}button:hover:not(:disabled){transform:none}}
    </style>
    <button id="launcher" aria-label="Open live layout editor" hidden>Edit page</button>
    <section id="panel" aria-label="Live layout editor">
      <div id="dockDrag" class="dock-header panel-drag" tabindex="0" role="group" aria-label="Move editor panel" title="Drag to move. Arrow keys move; Home restores the default position."><div class="brand"><span class="brand-mark" aria-hidden="true"></span><div><strong>Live Layout Editor</strong><span class="brand-caption">DRAG TO MOVE</span></div></div><div class="window-controls"><button id="panelMinimize" aria-label="Minimize editor panel" title="Minimize panel; keep editing active">−</button><button id="panelMaximize" aria-label="Maximize editor panel" title="Maximize panel">□</button><button id="close" aria-label="Close editor">Exit edit mode</button></div></div>
      <div class="row toolbar">
        <button id="undo" aria-label="Undo"><span class="button-icon" aria-hidden="true">↶</span>Undo</button>
        <button id="redo" aria-label="Redo"><span class="button-icon" aria-hidden="true">↷</span>Redo</button>
        <button id="cssDock">Live CSS</button><button id="resetPage" aria-label="Reset page"><span class="button-icon" aria-hidden="true">⟲</span>Reset page</button>
        <button id="export" aria-label="Export report" title="Download JSON and a readable report. Does not apply changes.">Export report</button><button id="flush" class="primary">Apply changes in code</button><button id="reload" hidden>Reload saved version</button></div>
      <p id="mode" class="muted"></p><p id="status" role="status" aria-live="polite">Double-click anything to edit. Click outside to keep your preview.</p>
    </section>
    <div id="quickbar" role="dialog" aria-label="Element options" hidden>
      <div id="quickbarDrag" class="panel-drag" tabindex="0" role="group" aria-label="Move element toolbar" title="Drag to move. Arrow keys move; Home restores its position.">Element options<span class="drag-hint">Right-click menu · drag to move ⠿</span></div>
      <button id="parent">Parent</button><button id="layerFront" title="Raise this element and its ancestor branches; override ancestor clipping when needed">Bring to front</button><button id="layerBack" title="Lower this element and its ancestor branches behind ordinary page layers">Send to back</button><button id="layerForward">Bring forward</button><button id="layerBackward">Send backward</button><button id="detach">Free element</button><button id="ungroup">Free children</button>
      <label>Color<input type="color" id="quickColor" aria-label="Text or fill color"></label>
      <label>Background<input type="color" id="quickBackground" aria-label="Background color"></label>
      <label>Size<input type="number" min="1" id="quickSize" aria-label="Font size"></label>
      <button id="replace">Replace</button><button id="upload">Image file</button><input id="imageFile" type="file" accept="image/png,image/jpeg,image/gif,image/webp,image/avif" hidden>
      <button id="liveCSS">Live CSS inspector</button><button id="hide">Hide</button><button id="more">More</button><button id="done">Done</button>
    <section id="inspector" aria-label="Advanced element controls" hidden>
      <div id="inspectorDrag" class="inspector-title">More element options</div>
      <p id="target" class="muted">Double-click to select; right-click for element options.</p>
      <div id="controls" hidden><div class="grid" id="geometry"></div>
        <details><summary>Appearance & spacing</summary><div class="grid" id="styles"></div></details>
        <details><summary>Any CSS property</summary><label>Property<input id="customProp" placeholder="e.g. rotate"></label><label>Value<input id="customValue" placeholder="e.g. 15deg"></label><button id="customApply">Set CSS</button></details>
        <details><summary>Content & attributes</summary>
          <label>Plain text (leaf elements)<textarea id="text"></textarea></label><button id="applyText">Apply text</button>
          <label>Image source URL<input id="src" type="url"></label><button id="applySrc">Apply image</button>
          <label>Image alt text<input id="alt"></label><button id="applyAlt">Apply alt text</button>
          <label>Attribute<input id="attrName" placeholder="href, placeholder, title…"></label><label>Value<input id="attrValue"></label><button id="applyAttr">Set attribute</button>
          <label>Replace inner HTML (removes child markup)<textarea id="html"></textarea></label><button id="applyHtml">Replace contents</button>
        </details><button id="resetElement">Reset element</button>
      </div>
    </section></div><section id="cssPanel" aria-label="Live CSS inspector" hidden><div id="cssDrag" class="panel-drag" tabindex="0" role="group" aria-label="Move CSS inspector">Live CSS<div class="css-window-buttons"><button id="cssMin" aria-label="Minimize CSS inspector">−</button><button id="cssMax" aria-label="Maximize CSS inspector">□</button><button id="cssClose" aria-label="Close CSS inspector">×</button></div></div><div id="cssBody"><p id="cssTarget"></p><label id="cssFollowLabel"><input id="cssFollow" type="checkbox" checked>Follow current action</label><p id="cssActivity" hidden></p><button id="cssAll" type="button">Show all CSS</button><label>CSS view<select id="cssView"><option value="computed">Computed properties · editable</option><option value="rules">Matching CSS rules · read only</option><option value="before">::before · computed, read only</option><option value="after">::after · computed, read only</option></select></label><label>Filter CSS<input id="cssSearch" type="search" placeholder="color, margin, --custom-property…"></label><p id="cssNotice">Values update live. Editing a computed property stages an element-level style change.</p><p id="cssCount"></p><div id="cssRows"></div></div></section><div id="hiddenMarkers"></div><div id="hiddenRack" hidden><button id="hiddenSummary" aria-expanded="false">Hidden elements</button><div id="hiddenList" hidden></div></div><div id="feedbackLayer" aria-hidden="true"></div><div id="selectionMarks"></div><div id="marquee" hidden></div><div id="outline"><button id="move" aria-label="Move selected element">Move</button><button id="resize" aria-label="Resize selected element"></button></div>`;
    (document.body || document.documentElement).append(host);
    const $ = id => shadow.getElementById(id);
    const logo = config.logo || globalThis.__LLE_BRAND__;
    if (typeof logo === 'string' && logo.startsWith('data:image/png;base64,')) { shadow.querySelector('.brand-mark').classList.add('has-logo'); shadow.querySelector('.brand-mark').style.backgroundImage = 'url("' + logo + '")'; }
    const status = message => { $('status').textContent = message; };
    $('mode').textContent = bridge ? 'LOCAL • connecting to project source writer…' : local ? 'LOCAL PREVIEW • connect the project folder in the extension to enable source saving.' : 'LIVE PREVIEW • changes stay in this tab, like DevTools. Reload to discard.';
    $('flush').hidden = !bridge;
    const listen = (node, event, handler, opts) => { node.addEventListener(event, handler, opts); cleanups.push(() => node.removeEventListener(event, handler, opts)); };
    const page = () => db.pages[path] || {};
    const isEditorUI = event => event.composedPath().includes(host) || event.composedPath().some(node => node instanceof Element && node.hasAttribute('data-lle-review'));
    const eligible = el => el instanceof Element && el !== host && !['script', 'style', 'link', 'meta', 'head', 'noscript'].includes(el.localName);
    const allowedAttrs = ['src', 'srcset', 'alt', 'href', 'title', 'placeholder', 'value', 'aria-label', 'poster'];
    function selectorFor(el) {
      for (const [selector, node] of detachedNodes) if (node === el) return selector;
      for (const attr of ['data-lle-id', 'data-gallery-layout', 'id']) {
        const value = el.getAttribute(attr);
        if (value) {
          const selector = '[' + attr + '="' + CSS.escape(value) + '"]';
          if (document.querySelectorAll(selector).length === 1) return selector;
        }
      }
      const parts = [];
      while (el && el !== document.documentElement) {
        const siblings = el.parentElement ? [...el.parentElement.children].filter(s => s.tagName === el.tagName) : [];
        parts.unshift(el.tagName.toLowerCase() + ':nth-of-type(' + (siblings.indexOf(el) + 1) + ')');
        const selector = parts.join(' > ');
        if (document.querySelectorAll(selector).length === 1) return selector;
        el = el.parentElement;
      }
      return parts.join(' > ');
    }
    function matches(selector) { if (detachedNodes.get(selector)?.isConnected) return [detachedNodes.get(selector)]; try { return [...document.querySelectorAll(selector)].filter(eligible); } catch { return []; } }
    function sanitizeHTML(markup) {
      const template = document.createElement('template'); template.innerHTML = markup;
      for (const node of template.content.querySelectorAll('*')) {
        if (['script', 'style', 'iframe', 'object', 'embed', 'link', 'meta', 'base', 'template'].includes(node.localName)) { node.remove(); continue; }
        for (const attr of [...node.attributes]) {
          if (/^on/i.test(attr.name) || ['srcdoc', 'style', 'is', 'autofocus', 'formaction', 'action'].includes(attr.name) ||
              (['href', 'src', 'xlink:href', 'poster'].includes(attr.name) && !safeURL(attr.value, attr.name))) node.removeAttribute(attr.name);
        }
      }
      return template.content;
    }
    function safeURL(value, attr = 'src') {
      if (/^data:image\/(?:png|jpeg|gif|webp|avif);base64,[a-z0-9+/=]+$/i.test(value)) return attr === 'src' || attr === 'poster';
      try { return (attr === 'href' ? ['http:', 'https:', 'mailto:', 'tel:'] : ['http:', 'https:']).includes(new URL(value, location.href).protocol); }
      catch { return false; }
    }
    const feedbackColors = {
      select: ['#b77912', 'rgba(234,169,45,.19)', 'rgba(234,169,45,.1)'],
      edit: ['#7956df', 'rgba(121,86,223,.17)', 'rgba(121,86,223,.08)'],
      layout: ['#0b8b9f', 'rgba(14,165,185,.17)', 'rgba(14,165,185,.08)'],
      remove: ['#ce4265', 'rgba(225,77,115,.18)', 'rgba(225,77,115,.09)'],
      save: ['#0b8875', 'rgba(16,158,130,.17)', 'rgba(16,158,130,.08)']
    };
    function captureArea(node, selector = null) {
      if (!node?.getBoundingClientRect) return null;
      const r = node.getBoundingClientRect();
      return { node, selector, rect: { left: r.left, top: r.top, width: r.width, height: r.height } };
    }
    function captureSelectors(selectors) { return selectors.flatMap(selector => matches(selector).map(node => captureArea(node, selector))).filter(Boolean); }
    function updateFeedback() {
      for (const item of feedbackItems) {
        let node = item.selector ? matches(item.selector)[0] : item.node;
        const live = node?.isConnected ? node.getBoundingClientRect() : null;
        // Hidden/deleted elements retain a temporary outline of their former area.
        const r = live?.width > 0 && live?.height > 0 ? live : item.rect;
        const left = Math.max(0, r.left), top = Math.max(0, r.top);
        const width = Math.max(0, Math.min(innerWidth, r.left + r.width) - left);
        const height = Math.max(0, Math.min(innerHeight, r.top + r.height) - top);
        Object.assign(item.box.style, { left: left + 'px', top: top + 'px', width: width + 'px', height: height + 'px', display: width && height ? 'block' : 'none' });
      }
    }
    function pulse(items, message, kind = 'edit') {
      if (destroyed) return;
      clearTimeout(feedbackTimer); feedbackItems = []; $('feedbackLayer').replaceChildren();
      const palette = feedbackColors[kind] || feedbackColors.edit;
      const unique = [...new Map(items.filter(Boolean).map(item => [item.node, item])).values()];
      if (!unique.length) unique.push(captureArea($('panel').hidden ? $('launcher') : $('panel')));
      for (const item of unique.slice(0, 80)) {
        const box = document.createElement('div'); box.className = 'effect-area';
        box.style.setProperty('--effect-color', palette[0]); box.style.setProperty('--effect-fill', palette[1]); box.style.setProperty('--effect-halo', palette[2]);
        $('feedbackLayer').append(box); feedbackItems.push({ ...item, box });
      }
      updateFeedback();
      feedbackTimer = setTimeout(() => { feedbackItems = []; $('feedbackLayer').replaceChildren(); }, 2800);
    }
    function deferFeedback(fn) {
      clearTimeout(feedbackJob); feedbackJob = setTimeout(() => { feedbackJob = null; if (!destroyed) fn(); }, 0);
    }
    function changedAreas(before, after) {
      const a = before[path] || {}, b = after[path] || {};
      return [...new Set([...Object.keys(a), ...Object.keys(b)])].filter(key => JSON.stringify(a[key]) !== JSON.stringify(b[key]));
    }
    function remember(node) {
      if (!originals.has(node)) originals.set(node, { style: new Map(), text: undefined, textRuns: new Map(), attrs: new Map(), anchor: null, children: null, value: undefined, marker: node.getAttribute('data-lle-source') });
      return originals.get(node);
    }
    function restore(sourceApplied = false) {
      for (const [node, orig] of [...originals].reverse()) {
        if (orig.anchor?.parentNode) { orig.anchor.replaceWith(node); }
        if (orig.children) { node.replaceChildren(orig.children); }
        if (orig.value !== undefined) node.value = orig.value;
        const sourceChanged = sourceApplied && orig.marker !== node.getAttribute('data-lle-source');
        for (const [prop, old] of orig.style) {
          if (sourceApplied && node.style.getPropertyPriority(prop) !== 'important') continue;
          if (old.value) node.style.setProperty(prop, old.value, old.priority); else node.style.removeProperty(prop);
        }
        if (!sourceChanged) for (const [textNode, value] of orig.textRuns) if (textNode.parentNode === node) textNode.data = value;
        if (!sourceChanged && orig.text !== undefined && !node.children.length) node.textContent = orig.text;
        if (!sourceChanged) for (const [attr, value] of orig.attrs) value === null ? node.removeAttribute(attr) : node.setAttribute(attr, value);
      }
      originals.clear(); detachedNodes.clear();
    }
    function apply() {
      applyFrame = null;
      if (destroyed || inline) return;
      observer.disconnect();
      document.documentElement.setAttribute('data-lle-page', path);
      restore();
      const resolved = new Map(Object.keys(page()).map(selector => [selector, matches(selector)]));
      for (const [selector, entry] of Object.entries(page())) {
        const nodes = resolved.get(selector).length ? resolved.get(selector) : matches(selector);
        // An edit must never silently apply to multiple components after a rerender.
        if (nodes.length !== 1) continue;
        const node = nodes[0], orig = remember(node);
        if (entry.detached && node !== document.body && node !== document.documentElement &&
            (node instanceof HTMLElement || node instanceof SVGSVGElement)) {
          orig.anchor = document.createComment('Live Layout Editor original position');
          node.before(orig.anchor); document.body.append(node); detachedNodes.set(selector, node);
        }
        if (entry.html !== undefined) {
          orig.children = document.createDocumentFragment();
          while (node.firstChild) orig.children.append(node.firstChild);
          node.append(sanitizeHTML(entry.html));
        }
        // Capture every original before setting shorthands: setting overflow first
        // also changes overflow-x/y, which would otherwise corrupt Undo/reset.
        if (entry.styles?.display === 'none' && !hiddenRecords.has(selector)) rememberHidden(node, selector);
        const styleEntries = Object.entries(entry.styles || {});
        for (const [prop] of styleEntries) orig.style.set(prop, { value: node.style.getPropertyValue(prop), priority: node.style.getPropertyPriority(prop) });
        for (const [prop, value] of styleEntries) node.style.setProperty(prop, value, 'important');
        if (entry.textRuns) { const texts = [...node.childNodes].filter(child => child.nodeType === Node.TEXT_NODE); for (const run of entry.textRuns) { const textNode = texts[run.index]; if (textNode && textNode.data === run.before) { orig.textRuns.set(textNode, textNode.data); textNode.data = run.after; } } }
        if (entry.text !== undefined && !node.children.length) { orig.text = node.textContent; node.textContent = entry.text; }
        for (const [attr, value] of Object.entries(entry.attrs || {})) {
          orig.attrs.set(attr, node.getAttribute(attr));
          if (attr === 'value' && 'value' in node) orig.value = node.value;
          node.setAttribute(attr, value);
          if (attr === 'value' && 'value' in node) node.value = value;
          if (attr === 'src' && node.localName === 'img' && node.parentElement?.localName === 'picture') {
            for (const source of node.parentElement.querySelectorAll('source')) { remember(source).attrs.set('srcset', source.getAttribute('srcset')); source.setAttribute('srcset', ''); }
          }
        }
      }
      observer.observe(document.body || document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class', 'id', 'data-lle-id', 'data-gallery-layout'] });
      outline(); updateHiddenHints();
    }
    function hiddenStorageKey() { return 'live-layout-hidden-v1:' + (config.hiddenScope || (bridge ? String(bridge) : 'preview')) + ':' + path; }
    function loadHiddenRecords() {
      hiddenRecords.clear(); hiddenListOpen = false;
      try {
        const records = JSON.parse(sessionStorage.getItem(hiddenStorageKey()) || '[]');
        if (!Array.isArray(records)) return;
        for (const record of records.slice(0, 100)) if (record && typeof record.selector === 'string' && record.selector.length <= 2000 && typeof record.label === 'string' && record.label.length <= 140 && typeof record.display === 'string' && record.display !== 'none' && CSS.supports('display', record.display) && [record.x, record.y].every(Number.isFinite)) hiddenRecords.set(record.selector, { ...record, saved: true, previous: null });
      } catch {} // Private/blocked storage does not prevent in-tab restoration.
    }
    function persistHiddenRecords() {
      try { sessionStorage.setItem(hiddenStorageKey(), JSON.stringify([...hiddenRecords.values()].filter(record => record.saved).slice(0, 100).map(({ selector, label, display, x, y, fixed }) => ({ selector, label, display, x, y, fixed: !!fixed })))); } catch {}
    }
    function rememberHidden(node, selector) {
      const r = node.getBoundingClientRect(), style = getComputedStyle(node), existing = hiddenRecords.get(selector);
      const rect = r.width || r.height ? r : node.parentElement?.getBoundingClientRect() || r;
      const text = (node.getAttribute('aria-label') || node.getAttribute('alt') || node.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80);
      const label = (node.localName + (node.id ? '#' + node.id : '') + (text ? ': ' + text : '')).slice(0, 140);
      const fixed = style.position === 'fixed';
      hiddenRecords.set(selector, { selector, label, display: style.display !== 'none' ? style.display : existing?.display || 'block', previous: page()[selector]?.styles?.display ?? null, x: rect.left + (fixed ? 0 : scrollX), y: rect.top + (fixed ? 0 : scrollY), fixed, saved: existing?.saved || false });
    }
    function showHidden(selector) {
      if (!ready || blocked || saving) return;
      const record = hiddenRecords.get(selector), nodes = matches(selector);
      if (!record || nodes.length !== 1) return;
      const node = nodes[0]; finishInline(); checkpoint(); db.pages[path] ||= {};
      const entry = db.pages[path][selector] ||= { styles: {}, attrs: {} };
      if (sourceMode) { entry.source = node.getAttribute('data-lle-source'); entry.descriptor ||= config.describe?.(node); }
      if (record.saved) { entry.styles.display = record.display; record.restoring = true; }
      else if (record.previous && record.previous !== 'none') entry.styles.display = record.previous;
      else delete entry.styles.display;
      if (!Object.keys(entry.styles).length && !Object.keys(entry.attrs || {}).length && entry.text === undefined && !entry.textRuns?.length && entry.html === undefined && !entry.detached) delete db.pages[path][selector];
      selected = selector; menuOpen = false; advanced = false;
      changed();
      const shownRect = node.getBoundingClientRect();
      if (shownRect.bottom < 0 || shownRect.top > innerHeight) node.scrollIntoView({ block: 'center', behavior: 'auto' });
      if (sourceMode && !Object.values(db.pages).some(entries => Object.keys(entries).length)) { dirty = false; updateAvailability(); }
      pulse([captureArea(node, selector)], 'Hidden element shown', 'save');
      persistHiddenRecords(); updateHiddenHints();
    }
    function commitHiddenRecords() {
      for (const [selector, record] of hiddenRecords) {
        if (page()[selector]?.styles?.display === 'none') { record.saved = true; record.restoring = false; }
        else if (record.saved && record.restoring && page()[selector]?.styles?.display) hiddenRecords.delete(selector);
      }
      persistHiddenRecords();
    }
    listen($('hiddenSummary'), 'click', () => { hiddenListOpen = !hiddenListOpen; updateHiddenHints(); });
    function updateHiddenHints() {
      if (destroyed) return;
      const layer = $('hiddenMarkers'), list = $('hiddenList');
      const hidden = [...hiddenRecords.values()].filter(record => { const nodes = matches(record.selector); return nodes.length !== 1 ? record.saved : getComputedStyle(nodes[0]).display === 'none'; });
      $('hiddenRack').hidden = !active || !hidden.length; layer.hidden = !active;
      $('hiddenSummary').textContent = 'Hidden elements · ' + hidden.length;
      $('hiddenSummary').setAttribute('aria-expanded', String(hiddenListOpen)); list.hidden = !hiddenListOpen;
      const wanted = new Set(hidden.map(record => record.selector));
      for (const button of [...layer.children]) if (!wanted.has(button.dataset.hiddenSelector)) button.remove();
      for (const button of [...list.children]) if (!wanted.has(button.dataset.hiddenSelector)) button.remove();
      const positions = [];
      for (const record of hidden) {
        const nodes = matches(record.selector), available = nodes.length === 1 && ready && !blocked && !saving;
        for (const container of [layer, list]) {
          let button = [...container.children].find(item => item.dataset.hiddenSelector === record.selector);
          if (!button) {
            button = document.createElement('button'); button.type = 'button'; button.dataset.hiddenSelector = record.selector;
            if (container === layer) { button.className = 'hidden-marker'; button.dataset.hiddenMarker = ''; }
            button.addEventListener('click', () => showHidden(record.selector)); container.append(button);
          }
          button.textContent = 'Hidden · ' + record.label + ' · Show'; button.setAttribute('aria-label', 'Show hidden ' + record.label);
          button.title = 'Last visible location. Click to show only this element. ' + record.selector; button.disabled = !available;
          if (container === layer) {
            let x = record.x - (record.fixed ? 0 : scrollX), y = record.y - (record.fixed ? 0 : scrollY);
            const onscreen = x > -250 && x < innerWidth && y > -35 && y < innerHeight;
            button.hidden = !onscreen;
            if (onscreen) {
              x = Math.max(8, Math.min(x, innerWidth - Math.min(250, innerWidth - 16) - 8)); y = Math.max(8, Math.min(y, innerHeight - 40));
              while (positions.some(pos => Math.abs(pos.y - y) < 32 && Math.abs(pos.x - x) < 250) && y + 64 < innerHeight) y += 34;
              positions.push({ x, y }); Object.assign(button.style, { left: x + 'px', top: y + 'px' });
            }
          }
        }
      }
    }
    function scheduleApply() { if (inline) return; if (!applyFrame) applyFrame = requestAnimationFrame(apply); }
    const observer = new MutationObserver(scheduleApply);
    function current() { const nodes = selected ? matches(selected) : []; return nodes.length === 1 ? nodes[0] : null; }
    function selectedItems() {
      const keys = selection.includes(selected) ? selection : selected ? [selected] : [];
      return keys.map(selector => ({ selector, node: matches(selector) })).filter(item => item.node.length === 1).map(item => ({ selector: item.selector, node: item.node[0] }));
    }
    function chooseNodes(nodes) {
      finishInline();
      const unique = [...new Set(nodes)].filter(eligible).filter(node => node !== document.body && node !== document.documentElement);
      // A selected container already includes its descendants: never translate twice.
      selection = unique.filter(node => !unique.some(parent => parent !== node && parent.contains(node))).map(selectorFor);
      selected = selection.at(-1) || null; menuOpen = false; advanced = false;
      if (selected) cssOpen = true;
      render();
    }
    function outline() {
      const node = current();
      $('quickbar').hidden = !active || !node || !menuOpen; $('inspector').hidden = !active || !node || !menuOpen || !advanced;
      $('outline').style.display = active && node ? 'block' : 'none';
      $('cssPanel').hidden = !active || !cssOpen;
      if (!node || !active) { $('selectionMarks').replaceChildren(); clampPanels(); return; }
      const items = selectedItems(), rects = items.map(item => item.node.getBoundingClientRect());
      const r = { left: Math.min(...rects.map(r => r.left)), top: Math.min(...rects.map(r => r.top)), right: Math.max(...rects.map(r => r.right)), bottom: Math.max(...rects.map(r => r.bottom)) }; r.width = r.right - r.left; r.height = r.bottom - r.top;
      $('selectionMarks').replaceChildren();
      if (items.length > 1) for (const rect of rects) { const mark = document.createElement('div'); mark.className = 'selection-mark'; Object.assign(mark.style, { left: rect.left + 'px', top: rect.top + 'px', width: rect.width + 'px', height: rect.height + 'px' }); $('selectionMarks').append(mark); }
      $('move').textContent = items.length > 1 ? 'Move ' + items.length + ' objects' : 'Move';
      if (menuOpen && !panelPositions.quickbar) { const point = menuPosition || { x: r.left, y: r.bottom + 12 }; placePanel('quickbar', point.x, point.y); }
      Object.assign($('outline').style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
      clampPanels();
    }
    function placePanel(id, left, top) {
      const panel = $(id), r = panel.getBoundingClientRect();
      const x = Math.max(8, Math.min(Number.isFinite(left) ? left : 8, Math.max(8, innerWidth - r.width - 8)));
      const y = Math.max(8, Math.min(Number.isFinite(top) ? top : 8, Math.max(8, innerHeight - r.height - 8)));
      Object.assign(panel.style, { left: x + 'px', top: y + 'px', right: 'auto', bottom: 'auto' });
      panelPositions[id] = { left: x, top: y };
    }
    function clampPanels() {
      for (const [id, pos] of Object.entries(panelPositions)) if (!$(id).hidden && !(id === 'panel' && panelMode === 'maximized') && !(id === 'cssPanel' && cssMode === 'maximized')) placePanel(id, pos.left, pos.top);
    }
    function setPanelMode(mode) {
      finishInline();
      if (mode === panelMode) return;
      const panel = $('panel'), r = panel.getBoundingClientRect();
      if (panelMode === 'normal') {
        panelNormalStyle = panel.style.cssText;
        panelNormalPosition = panelPositions.panel ? { ...panelPositions.panel } : null;
      }
      if (mode === 'minimized') previousPanelMode = panelMode;
      panelMode = mode; panel.dataset.window = mode;
      if (mode === 'normal') {
        panel.style.cssText = panelNormalStyle || '';
        if (panelNormalPosition) panelPositions.panel = { ...panelNormalPosition }; else delete panelPositions.panel;
        panelNormalStyle = null; panelNormalPosition = null;
      } else if (mode === 'minimized') placePanel('panel', r.left, r.top);
      $('panelMinimize').textContent = mode === 'minimized' ? '▣' : '−';
      $('panelMinimize').setAttribute('aria-label', mode === 'minimized' ? 'Restore editor panel' : 'Minimize editor panel');
      $('panelMinimize').title = mode === 'minimized' ? 'Restore panel; preview edits are kept' : 'Minimize panel; keep editing active';
      $('panelMaximize').textContent = mode === 'maximized' ? '▱' : '□';
      $('panelMaximize').setAttribute('aria-label', mode === 'maximized' ? 'Restore editor panel size' : 'Maximize editor panel');
      $('panelMaximize').title = mode === 'maximized' ? 'Restore previous size and position' : 'Maximize panel';
      $('close').textContent = mode === 'minimized' ? '×' : 'Exit edit mode';
      outline();
    }
    listen($('panelMinimize'), 'click', () => setPanelMode(panelMode === 'minimized' ? previousPanelMode : 'minimized'));
    listen($('panelMaximize'), 'click', () => setPanelMode(panelMode === 'maximized' ? 'normal' : 'maximized'));
    for (const [handleId, panelId] of [['dockDrag', 'panel'], ['quickbarDrag', 'quickbar'], ['cssDrag', 'cssPanel']]) {
      const handle = $(handleId);
      listen(handle, 'pointerdown', event => {
        if (((panelId === 'panel' && panelMode === 'maximized') || (panelId === 'cssPanel' && cssMode === 'maximized')) || event.button !== 0 || event.target.closest('button,input,select,textarea,a')) return;
        event.preventDefault(); event.stopPropagation();
        const r = $(panelId).getBoundingClientRect();
        panelGesture = { handle, panelId, pointer: event.pointerId, x: event.clientX, y: event.clientY, left: r.left, top: r.top };
        handle.setPointerCapture(event.pointerId); handle.classList.add('is-dragging');
      });
      listen(handle, 'pointermove', event => {
        const move = panelGesture;
        if (!move || move.handle !== handle || move.pointer !== event.pointerId) return;
        event.preventDefault(); placePanel(panelId, move.left + event.clientX - move.x, move.top + event.clientY - move.y);
      });
      const stopPanel = () => {
        if (panelGesture?.handle !== handle) return;
        handle.classList.remove('is-dragging'); panelGesture = null;
      };
      listen(handle, 'pointerup', stopPanel); listen(handle, 'pointercancel', stopPanel); listen(handle, 'lostpointercapture', stopPanel);
      listen(handle, 'keydown', event => {
        if (event.target !== handle || ((panelId === 'panel' && panelMode === 'maximized') || (panelId === 'cssPanel' && cssMode === 'maximized'))) return;
        const step = event.shiftKey ? 40 : 12, delta = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[event.key];
        if (event.key === 'Home') {
          event.preventDefault(); delete panelPositions[panelId];
          for (const prop of ['left', 'top', 'right', 'bottom']) $(panelId).style.removeProperty(prop);
          outline();
        } else if (delta) {
          event.preventDefault(); const r = $(panelId).getBoundingClientRect(); placePanel(panelId, r.left + delta[0], r.top + delta[1]);
        }
      });
    }
    const geom = [['x', 'Move X'], ['y', 'Move Y'], ['width', 'Width'], ['height', 'Height']];
    for (const [prop, label] of geom) {
      const lab = document.createElement('label'); lab.textContent = label;
      const input = document.createElement('input'); input.type = 'number'; input.id = prop; input.setAttribute('aria-label', label);
      if (prop === 'width' || prop === 'height') input.min = '8';
      lab.append(input); $('geometry').append(lab);
      listen(input, 'change', () => {
        if (input.value === '') { edit(entry => { if (prop === 'x' || prop === 'y') delete entry.styles.translate; else delete entry.styles[prop]; }); return; }
        const value = input.valueAsNumber;
        if (!Number.isFinite(value)) return;
        if (prop === 'x' || prop === 'y') {
          const xy = translation(); xy[prop === 'x' ? 0 : 1] = value;
          edit(entry => { entry.styles.translate = xy.map(v => v + 'px').join(' '); });
        } else edit(entry => { entry.styles[prop] = Math.max(8, value) + 'px'; });
      });
    }
    for (const prop of properties.filter(p => !['translate', 'width', 'height'].includes(p))) {
      const lab = document.createElement('label'); lab.textContent = prop;
      const input = document.createElement('input'); input.dataset.prop = prop; input.setAttribute('aria-label', prop);
      input.placeholder = 'Original'; lab.append(input); $('styles').append(lab);
      listen(input, 'change', () => {
        const value = input.value.trim();
        if (value && (!CSS.supports(prop, value) || /[;{}<>]/.test(value))) { status('Invalid CSS value for ' + prop); return; }
        edit(entry => { if (value) entry.styles[prop] = value; else delete entry.styles[prop]; });
      });
    }
    function translation(node = current(), selector = selected) {
      const existing = page()[selector]?.styles?.translate;
      const value = existing || (node ? getComputedStyle(node).translate : 'none');
      const vals = String(value).split(/\s+/).slice(0, 2);
      if (vals.some(v => v !== 'none' && !/^-?[\d.]+(?:px)?$/.test(v))) {
        throw new Error('Existing percentage/3D translate: change translate in your stylesheet before moving this element.');
      }
      return [parseFloat(vals[0]) || 0, parseFloat(vals[1]) || 0];
    }
    const voidTags = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
    const textField = node => node instanceof HTMLTextAreaElement || (node instanceof HTMLInputElement && ['text', 'search', 'url', 'email', 'tel', 'number'].includes(node.type));
    const canText = node => !!node && (!sourceMode || textField(node) || config.capabilities?.(node)?.text !== false) && (textField(node) || (!node.children.length && !voidTags.has(node.localName) &&
      !['video', 'audio', 'canvas', 'iframe', 'select'].includes(node.localName) && (!(node instanceof SVGElement) || ['text', 'tspan', 'textPath'].includes(node.localName))));
    const canMarkup = node => node instanceof HTMLElement && node !== document.body && node !== document.documentElement && !voidTags.has(node.localName);
    function supportedAttribute(node, name) {
      if (!node) return false;
      if (['title', 'aria-label'].includes(name)) return true;
      if (name === 'src') return ['img', 'video', 'audio', 'source', 'iframe'].includes(node.localName);
      if (name === 'srcset') return ['img', 'source'].includes(node.localName);
      if (name === 'href') return ['a', 'area', 'image', 'use'].includes(node.localName);
      if (name === 'poster') return node.localName === 'video';
      if (name === 'alt') return ['img', 'area'].includes(node.localName) || (node.localName === 'input' && node.type === 'image');
      if (name === 'placeholder') return ['input', 'textarea'].includes(node.localName);
      if (name === 'value') return ['input', 'textarea', 'select', 'option', 'button'].includes(node.localName);
      return false;
    }
    function updateAvailability() {
      const node = current();
      const writable = !!node && ready && !blocked && (!sourceMode || !saving);
      const multiple = selectedItems().length > 1;
      const draft = !!inline && (inline.kind === 'value' ? inline.node.value : inline.node.textContent) !== inline.text;
      const root = node === document.body || node === document.documentElement;
      const movable = writable && !root && getComputedStyle(node).display !== 'contents' && (() => { try { translation(); return true; } catch { return false; } })();
      const image = writable && node.localName === 'img';
      $('parent').disabled = !node || !eligible(node.parentElement) || node.parentElement === document.body || node.parentElement === document.documentElement;
      $('detach').disabled = sourceMode || !writable || !canFree(node) || !!page()[selected]?.detached;
      $('ungroup').disabled = sourceMode || !writable || ![...node.children].some(canFree);
      $('hide').disabled = !writable || root;
      for (const id of ['layerFront', 'layerBack', 'layerForward', 'layerBackward']) $(id).disabled = !writable || !canLayer(node);
      if (writable && canLayer(node)) {
        const siblings = [...node.parentElement.children];
        const rank = item => parseInt(getComputedStyle(item).zIndex, 10) || 0;
        const peers = siblings.filter(item => canLayer(item) && !item.hasAttribute('data-live-layout-editor') && !item.hasAttribute('data-lle-review')).sort((a, b) => rank(a) - rank(b) || siblings.indexOf(a) - siblings.indexOf(b));
        const index = peers.indexOf(node);
        $('layerForward').disabled = index === peers.length - 1;
        $('layerBackward').disabled = index <= 0;
      }
      $('replace').disabled = !writable || !(image || canText(node) || (!sourceMode && canMarkup(node)));
      $('upload').hidden = false; $('upload').disabled = !image;
      $('quickSize').disabled = !writable || !(node.textContent.trim() || textField(node) || node.localName === 'select');
      $('quickColor').disabled = !writable || !(node instanceof SVGElement || node.textContent.trim() || textField(node));
      $('quickBackground').disabled = !writable;
      $('move').disabled = !movable; $('resize').disabled = !writable || root;
      $('x').disabled = $('y').disabled = !movable;
      $('width').disabled = $('height').disabled = !writable || root;
      $('applyText').disabled = $('text').disabled = !writable || !canText(node);
      for (const id of ['src', 'alt', 'applySrc', 'applyAlt']) $(id).disabled = !image;
      $('applyHtml').disabled = $('html').disabled = sourceMode || !writable || !canMarkup(node);
      $('applyAttr').disabled = !writable || !supportedAttribute(node, $('attrName').value.trim());
      $('customApply').disabled = !writable || !$('customProp').value.trim();
      $('resetElement').disabled = !writable || (!page()[selected] && !draft);
      $('resetPage').disabled = !ready || blocked || (!Object.keys(page()).length && !draft);
      $('undo').disabled = (!undoStack.length && !draft) || !ready || blocked;
      $('redo').disabled = !redoStack.length || draft || !ready || blocked;
      $('flush').disabled = !bridge || (!dirty && !draft) || !ready || blocked || saving;
      if (multiple) { for (const id of ['parent','replace','upload','applyText','text','applyHtml','html','applyAttr','applySrc','applyAlt','src','alt','detach','ungroup','layerFront','layerBack','layerForward','layerBackward']) $(id).disabled = true; }
      $('export').disabled = !Object.values(db.pages).some(entries => Object.keys(entries).length) && !draft;
    }
    function render() {
      const node = current(); $('controls').hidden = !node;
      $('target').textContent = (selectedItems().length > 1 ? selectedItems().length + ' objects selected · ' : '') + (selected || 'Double-click to select; right-click for element options.');
      updateAvailability();
      if (!node) { outline(); refreshCSS(true); return; }
      const style = page()[selected]?.styles || {}, r = node.getBoundingClientRect();
      let xy = [0, 0]; try { xy = translation(); } catch {}
      $('x').value = Math.round(xy[0]); $('y').value = Math.round(xy[1]);
      $('width').value = parseFloat(style.width) || Math.round(r.width); $('height').value = parseFloat(style.height) || Math.round(r.height);
      for (const input of shadow.querySelectorAll('[data-prop]')) {
        input.value = style[input.dataset.prop] || ''; input.placeholder = getComputedStyle(node).getPropertyValue(input.dataset.prop);
      }
      $('text').disabled = $('applyText').disabled = !!node.children.length;
      $('text').value = textField(node) ? node.value : (canText(node) ? node.textContent : '');
      $('quickSize').value = parseFloat(getComputedStyle(node).fontSize) || 16;
      updateAvailability();
      for (const attr of ['src', 'alt']) { $(attr).value = node.getAttribute(attr) || ''; }
      outline(); refreshCSS(true);
    }
    function setCSSMode(mode) {
      const panel = $('cssPanel'), r = panel.getBoundingClientRect();
      if (cssMode === 'normal') cssSaved = { style: panel.style.cssText, position: panelPositions.cssPanel ? { ...panelPositions.cssPanel } : null };
      if (mode === 'minimized') cssPrevious = cssMode;
      cssMode = mode; panel.dataset.window = mode;
      if (mode === 'normal') { panel.style.cssText = cssSaved?.style || ''; if (cssSaved?.position) panelPositions.cssPanel = { ...cssSaved.position }; else delete panelPositions.cssPanel; cssSaved = null; }
      if (mode === 'minimized') placePanel('cssPanel', r.left, r.top);
      $('cssMin').textContent = mode === 'minimized' ? '▣' : '−'; $('cssMin').setAttribute('aria-label', mode === 'minimized' ? 'Restore CSS inspector' : 'Minimize CSS inspector');
      $('cssMax').textContent = mode === 'maximized' ? '▱' : '□'; $('cssMax').setAttribute('aria-label', mode === 'maximized' ? 'Restore CSS inspector size' : 'Maximize CSS inspector');
      outline(); refreshCSS(true);
    }
    listen($('cssDock'), 'click', () => { cssOpen = true; if (cssMode === 'minimized') setCSSMode('normal'); outline(); refreshCSS(true); });
    listen($('liveCSS'), 'click', () => { finishInline(); cssOpen = true; menuOpen = false; advanced = false; outline(); refreshCSS(true); });
    listen($('cssClose'), 'click', () => { cssOpen = false; outline(); });
    listen($('cssMin'), 'click', () => setCSSMode(cssMode === 'minimized' ? cssPrevious : 'minimized'));
    listen($('cssMax'), 'click', () => setCSSMode(cssMode === 'maximized' ? 'normal' : 'maximized'));
    listen($('cssSearch'), 'input', () => { $('cssFollow').checked = false; cssFocusProperties = []; cssFocusLabel = ''; refreshCSS(true); });
    listen($('cssFollow'), 'change', () => { if (!$('cssFollow').checked) { cssFocusProperties = []; cssFocusLabel = ''; refreshCSS(true); } });
    listen($('cssAll'), 'click', () => { cssFocusProperties = []; cssFocusLabel = ''; $('cssSearch').value = ''; cssRowsKey = ''; refreshCSS(true); }); listen($('cssView'), 'change', () => { cssRowsKey = ''; refreshCSS(true); });
    function followCSS(properties, label) {
      if (!$('cssFollow').checked || !properties.length || shadow.activeElement?.matches?.('[data-css-property]')) return;
      const next = [...new Set(properties)];
      const key = next.join('|');
      const different = key !== cssFocusProperties.join('|') || label !== cssFocusLabel;
      cssFocusProperties = next; cssFocusLabel = label;
      // Never steal focus from a CSS input or reopen a deliberately closed panel.
      if (!cssOpen || cssMode === 'minimized') return;
      const typing = shadow.activeElement?.matches?.('[data-css-property]');
      if (typing) return;
      $('cssView').value = 'computed'; $('cssSearch').value = '';
      refreshCSS(true);
      if (different) { const row = $('cssRows').querySelector('.css-active'); if (row) { const panel = $('cssPanel'); panel.scrollTop += row.getBoundingClientRect().top - panel.getBoundingClientRect().top - 72; } }
    }
    function followChangedCSS(before) {
      if (!before) return;
      const names = new Set();
      const old = before[path] || {}, now = page();
      for (const selector of new Set([...Object.keys(old), ...Object.keys(now)])) {
        const a = old[selector]?.styles || {}, b = now[selector]?.styles || {};
        for (const prop of new Set([...Object.keys(a), ...Object.keys(b)])) if (a[prop] !== b[prop]) names.add(prop);
      }
      if (names.size) followCSS([...names], names.has('translate') ? 'Position' : names.has('width') || names.has('height') ? 'Size' : names.has('z-index') ? 'Layer order' : names.has('display') ? 'Visibility' : 'Style');
    }
    function refreshCSS(force = false) {
      if (!cssOpen || !active || cssMode === 'minimized' || (!force && Date.now() - cssLast < 500)) return;
      cssLast = Date.now(); const node = current(), rows = $('cssRows');
      $('cssActivity').hidden = !cssFocusProperties.length; $('cssActivity').textContent = cssFocusLabel + ' · ' + cssFocusProperties.join(', ');
      $('cssTarget').textContent = selectedItems().length > 1 ? selectedItems().length + ' objects · values from the last selected object; CSS edits apply to all.' : selected || 'Double-click an element to inspect its CSS.';
      if (!node) { rows.replaceChildren(); cssRowsKey = ''; $('cssCount').textContent = ''; return; }
      const view = $('cssView').value, filter = $('cssSearch').value.trim().toLowerCase();
      if (view === 'rules') {
        const blocks = [], seen = new Set(); let inaccessible = 0, inspected = 0;
        if (node.style.cssText) blocks.push('element.style { ' + node.style.cssText + ' }');
        function visit(sheet, label) {
          if (seen.has(sheet)) return; seen.add(sheet);
          let rules; try { rules = sheet.cssRules; } catch { inaccessible++; return; }
          for (const rule of rules || []) {
            if (++inspected > 10000) return;
            if (rule.media && !matchMedia(rule.media.mediaText).matches) continue;
            if (rule.constructor?.name === 'CSSSupportsRule' && !CSS.supports(rule.conditionText)) continue;
            if (rule.selectorText) {
              let target = node, inherited = 0;
              while (target && inherited < 12) {
                let match = false; try { match = target.matches(rule.selectorText); } catch {}
                if (match) { blocks.push((inherited ? 'Ancestor ' + target.localName + ' · ' : '') + label + '\n' + rule.cssText); break; }
                target = target.parentElement; inherited++;
              }
            } else if (rule.styleSheet) visit(rule.styleSheet, rule.href || label);
            else if (rule.cssRules) visit(rule, label + (rule.conditionText ? ' · ' + rule.conditionText : ''));
          }
        }
        for (const sheet of [...document.styleSheets, ...(document.adoptedStyleSheets || [])]) visit(sheet, sheet.href || 'inline stylesheet');
        const found = blocks.filter(text => !filter || text.toLowerCase().includes(filter)), signature = selected + '|rules|' + found.join('\n');
        if (signature !== cssRowsKey) { rows.replaceChildren(); for (const text of found) { const pre = document.createElement('pre'); pre.className = 'css-rule'; pre.textContent = text; rows.append(pre); } cssRowsKey = signature; }
        $('cssCount').textContent = found.length + ' matching rule blocks';
        $('cssNotice').textContent = 'Rules are read only; edit the Computed view to stage a change. Ancestor blocks also contain non-inherited properties. ' + (inaccessible ? inaccessible + ' cross-origin stylesheet(s) are inaccessible to this extension. ' : '') + (inspected > 10000 ? 'Rule scan capped at 10,000 entries.' : ''); return;
      }
      const style = getComputedStyle(node, view === 'before' ? '::before' : view === 'after' ? '::after' : null);
      const names = [...style].filter(name => !filter || name.toLowerCase().includes(filter)).sort((a,b) => Number(cssFocusProperties.includes(b)) - Number(cssFocusProperties.includes(a)) || a.localeCompare(b)), signature = selected + '|' + view + '|' + names.join('|') + '|' + cssFocusProperties.join('|');
      if (signature !== cssRowsKey) {
        rows.replaceChildren();
        for (const name of names) {
          const row = document.createElement('label'), key = document.createElement('code'), input = document.createElement('input'); row.className = 'css-row' + (cssFocusProperties.includes(name) ? ' css-active' : ''); key.textContent = name;
          input.dataset.cssProperty = name; input.setAttribute('aria-label', 'CSS ' + name); input.disabled = view !== 'computed'; input.spellcheck = false;
          input.addEventListener('change', () => {
            const value = input.value.trim();
            if (!value || !CSS.supports(name, value) || /[;{}<>]|!important|url\s*\(|expression\s*\(/i.test(value)) { input.setCustomValidity('Enter a supported CSS value.'); input.reportValidity(); return; }
            input.setCustomValidity(''); edit(entry => { entry.styles[name] = value; }); refreshCSS(true);
          });
          row.append(key, input); rows.append(row);
        }
        cssRowsKey = signature;
      }
      for (const input of rows.querySelectorAll('input')) { if (shadow.activeElement !== input) input.value = style.getPropertyValue(input.dataset.cssProperty); input.title = style.getPropertyValue(input.dataset.cssProperty); }
      $('cssCount').textContent = names.length + ' properties'; $('cssNotice').textContent = view === 'computed' ? 'Live computed values. Editing stages an element-level style change; Apply changes in code saves supported source edits.' : 'Pseudo-element computed values are read only.';
    }
    function checkpoint() { pendingActionPages = copy(db.pages); undoStack.push(copy(db.pages)); if (undoStack.length > 60) undoStack.shift(); redoStack = []; }
    function changed() {
      dirty = true; changes++; apply(); render(); followChangedCSS(pendingActionPages); pendingActionPages = null;
      if (sourceMode && config.autoApply && !saving && !blocked) { clearTimeout(timer); timer = setTimeout(save, 450); }
      status(bridge ? 'Preview staged • click Apply changes in code when ready.' : 'Temporary preview • reload the page to discard. No website or source files are changed.');
    }
    function edit(fn) {
      if (!current() || !ready || blocked || (sourceMode && saving)) { status('Source connection is not ready. Reload saved version or export first.'); return; }
      const items = selectedItems(), primary = selected;
      const affected = items.map(item => captureArea(item.node, item.selector));
      checkpoint(); db.pages[path] ||= {};
      for (const { node, selector } of items) {
        selected = selector;
        const entry = db.pages[path][selector] ||= { styles: {}, attrs: {} };
        if (sourceMode) { entry.source = node.getAttribute('data-lle-source'); entry.descriptor ||= config.describe?.(node); }
        fn(entry, node, selector);
        if (!Object.keys(entry.styles).length && !Object.keys(entry.attrs).length && entry.text === undefined && !entry.textRuns?.length && entry.html === undefined && !entry.detached) delete db.pages[path][selector];
      }
      selected = primary;
      changed(); pulse(affected, 'Preview updated', 'edit');
    }

    async function request(route, options = {}) {
      if (sourceMode) return config.request(route, options);
      const res = await fetch(bridge + route, { ...options, mode: 'cors', credentials: 'omit', headers: {
        'X-LLE-Token': config.token, ...(options.body ? { 'Content-Type': 'application/json' } : {}) } });
      const data = await res.json();
      if (!res.ok) { const error = new Error(data.error || 'Source writer failed'); error.status = res.status; throw error; }
      return data;
    }
    async function save() {
      finishInline(); clearTimeout(timer);
      if (!bridge) { status("Live-site preview only. No changes were written anywhere."); return; }
      if (!dirty) { status('No pending source changes. Export report only downloads a copy of the saved/preview changes.'); return; }
      if (saving || blocked || !ready) return;
      saving = true; updateAvailability(); const sent = changes;
      try {
        const result = await request('/save', { method: 'POST', body: JSON.stringify({ ...db, revision }) });
        revision = result.revision; db.revision = revision;
        commitHiddenRecords();
        dirty = changes !== sent;
        if (sourceMode) {
          restore(true); db.pages = {}; dirty = false; undoStack = []; redoStack = []; apply(); render();
        }
        pulse(captureSelectors(Object.keys(page())), 'Applied to code • visible edited areas', 'save');
        status(sourceMode ? 'Updated original source: ' + (result.files || []).join(', ') : (dirty ? 'Newer edits remain in preview • click Apply changes in code again.' : 'Saved to project: live-layout-changes/ (revision ' + revision + ')'));
      } catch (error) {
        // Do not overwrite edits from another tab, or retry uncertain writes automatically.
        if (!sourceMode) blocked = true; $('reload').hidden = false;
        clearTimeout(timer);
        status('Not saved: ' + error.message + '. Export edits before reloading.');
      } finally { saving = false; updateAvailability(); }
    }
    function cssText() {
      return Object.entries(db.pages).map(([route, entries]) => '/* Page ' + route.replace(/[*/\r\n]/g, '_') + ' */\n' +
        Object.entries(entries).map(([selector, entry]) => 'html[data-lle-page="' + CSS.escape(route) + '"] ' + selector + ' {\n' +
          Object.entries(entry.styles || {}).map(([p, v]) => '  ' + p + ': ' + v + ' !important;').join('\n') + '\n}').join('\n')).join('\n\n');
    }
    function download(name, content, type) {
      const url = URL.createObjectURL(new Blob([content], { type })); const a = document.createElement('a');
      a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
    function report() {
      const lines = ['LIVE LAYOUT EDITOR — MANUAL CHANGE REPORT', 'Apply changes to the matching components/styles in your source.',
        'Selectors are page-specific. data-lle-id is recommended for stable targeting.', ''];
      for (const [route, entries] of Object.entries(db.pages)) for (const [selector, entry] of Object.entries(entries)) {
        lines.push('Page: ' + route, 'Element: ' + selector);
        for (const [prop, value] of Object.entries(entry.styles || {})) lines.push('  CSS ' + prop + ': ' + value);
        if (entry.text !== undefined) lines.push('  Text: ' + JSON.stringify(entry.text));
        for (const run of entry.textRuns || []) lines.push('  Text segment ' + run.index + ': ' + JSON.stringify(run.before) + ' → ' + JSON.stringify(run.after));
        if (entry.detached) lines.push('  Detach: move element to document body, independently of its original container.');
        if (entry.html !== undefined) lines.push('  Replace inner HTML: ' + entry.html);
        for (const [attr, value] of Object.entries(entry.attrs || {})) lines.push('  Attribute ' + attr + ': ' + JSON.stringify(value));
        lines.push('');
      }
      return lines.join('\n');
    }
    function exportChanges() {
      finishInline();
      download('live-layout-changes.json', JSON.stringify(db, null, 2), 'application/json');
      download('live-layout-changes.txt', report() + '\n\nCSS (requires data-lle-page on html):\n' + cssText(), 'text/plain');
      pulse(captureSelectors(Object.keys(page())), 'Export report • download only; no changes applied', 'edit');
      status('Downloaded JSON + readable TXT report. Export does not save or apply changes. Allow multiple downloads if Chrome asks.');
    }
    function inlineText(node) {
      let value = '';
      for (const child of node.childNodes) {
        if (child.nodeType === Node.TEXT_NODE) value += child.data;
        else if (child.nodeType === Node.ELEMENT_NODE) {
          if (child.localName === 'br') value += '\n';
          else { if (['div','p'].includes(child.localName) && value && !value.endsWith('\n')) value += '\n'; value += inlineText(child); }
        }
      }
      return value;
    }
    function finishInline() {
      if (!inline) return;
      const session = inline; inline = null;
      const value = session.kind === 'value' ? session.node.value : session.node.textContent === session.text ? session.text : inlineText(session.node);
      if (session.kind === 'value') {
        session.node.value = session.text;
        for (const [prop, old] of session.editStyles || []) old.value ? session.node.style.setProperty(prop,old.value,old.priority) : session.node.style.removeProperty(prop);
        if (value !== session.text) edit(entry => { entry.attrs.value = value; });
        else scheduleApply();
        return;
      }
      if (session.kind === 'run') {
        session.textNode.data = session.text; session.node.replaceWith(session.textNode);
        if (value !== session.text) edit(entry => { entry.textRuns ||= []; const previous = entry.textRuns.find(run => run.index === session.index); if (previous) previous.after = value; else entry.textRuns.push({ index: session.index, before: session.text, after: value }); }); else scheduleApply();
        return;
      }
      for (const [prop, old] of session.editStyles || []) old.value ? session.node.style.setProperty(prop, old.value, old.priority) : session.node.style.removeProperty(prop);
      if (session.attr === null) session.node.removeAttribute('contenteditable'); else session.node.setAttribute('contenteditable', session.attr);
      // Restore the baseline first, so undo/reset can restore the original content.
      session.node.textContent = session.text;
      if (value !== session.text) edit(entry => { delete entry.html; entry.text = value; });
      else scheduleApply();
    }
    function deselect() { finishInline(); selected = null; selection = []; advanced = false; menuOpen = false; render(); }
    function textEditingStyles(node) {
      const values = [['user-select','text'],['-webkit-user-select','text'],['-webkit-user-modify','read-write-plaintext-only'],['pointer-events','auto']];
      const saved = new Map(values.map(([property]) => [property, { value: node.style.getPropertyValue(property), priority: node.style.getPropertyPriority(property) }]));
      for (const [property, value] of values) node.style.setProperty(property,value,'important');
      return saved;
    }
    function beginInline(node, event) {
      if (sourceMode && saving) return;
      if (textField(node)) {
        inline = { kind: 'value', node, text: node.value, editStyles: textEditingStyles(node) }; node.focus(); try { node.select(); } catch {} return;
      }
      if (!(node instanceof HTMLElement) || !node.textContent.trim() || ['input','textarea','select','option','img','video','audio','canvas','iframe','script','style'].includes(node.localName)) return;
      if (node.children.length) {
        const texts = [...node.childNodes].filter(child => child.nodeType === Node.TEXT_NODE);
        let textNode;
        if (event && document.caretPositionFromPoint) { const caret = document.caretPositionFromPoint(event.clientX,event.clientY); if (texts.includes(caret?.offsetNode)) textNode = caret.offsetNode; }
        if (!textNode && event && document.caretRangeFromPoint) { const caret = document.caretRangeFromPoint(event.clientX,event.clientY); if (texts.includes(caret?.startContainer)) textNode = caret.startContainer; }
        if (!textNode || !textNode.data.trim()) {
          let best = Infinity;
          for (const candidate of texts.filter(text => text.data.trim())) { const range = document.createRange(); range.selectNodeContents(candidate); for (const rect of range.getClientRects()) { const distance = event ? Math.hypot(event.clientX - Math.max(rect.left,Math.min(event.clientX,rect.right)),event.clientY - Math.max(rect.top,Math.min(event.clientY,rect.bottom))) : 0; if (distance < best) { best = distance; textNode = candidate; } } }
        }
        if (!textNode?.data.trim()) return;
        const span = document.createElement('span'); span.textContent = textNode.data; span.setAttribute('contenteditable','plaintext-only'); span.style.cssText = 'all:initial;font:inherit;color:inherit;line-height:inherit;letter-spacing:inherit;text-transform:inherit;text-decoration:inherit;display:inline;white-space:pre-wrap;';
        textEditingStyles(span);
        inline = { kind: 'run', node: span, textNode, owner: node, index: texts.indexOf(textNode), text: textNode.data };
        textNode.replaceWith(span); span.focus();
      } else {
        if (sourceMode && !canText(node)) return;
        inline = { node, text: node.textContent, attr: node.getAttribute('contenteditable'), editStyles: textEditingStyles(node) };
        node.setAttribute('contenteditable','plaintext-only'); node.focus();
      }
      const range = document.createRange(); range.selectNodeContents(inline.node);
      const textSelection = window.getSelection(); textSelection.removeAllRanges(); textSelection.addRange(range);
    }
    function toggle(value) { finishInline(); active = value; $('panel').hidden = !value; $('launcher').hidden = value; if (!value) selected = null; render(); updateHiddenHints(); }
    listen($('launcher'), 'click', () => toggle(true)); listen($('close'), 'click', () => toggle(false));
    listen(document, 'pointerdown', event => {
      if (!active) return;
      const inUI = isEditorUI(event);
      if (inline && (inUI || !inline.node.contains(event.target))) finishInline();
      if (menuOpen && !event.composedPath().includes($('quickbar'))) { menuOpen = false; advanced = false; outline(); }
      if (!inUI && event.button === 0 && !event.ctrlKey && !event.metaKey && !inline) {
        marquee = { id: event.pointerId, x: event.clientX, y: event.clientY, moved: false, target: event.target };
      }
      if (event.button !== 2 && !inUI && !event.ctrlKey && !event.metaKey && selected && !selectedItems().some(item => item.node.contains(event.target))) deselect();
      if (!inUI) event.stopImmediatePropagation();
    }, true);
    listen(document, 'pointermove', event => {
      if (!marquee || event.pointerId !== marquee.id) return;
      if (Math.hypot(event.clientX - marquee.x, event.clientY - marquee.y) < 6 && !marquee.moved) return;
      marquee.moved = true; event.preventDefault(); event.stopImmediatePropagation();
      const box = $('marquee'); box.hidden = false;
      Object.assign(box.style, { left: Math.min(marquee.x, event.clientX) + 'px', top: Math.min(marquee.y, event.clientY) + 'px', width: Math.abs(event.clientX - marquee.x) + 'px', height: Math.abs(event.clientY - marquee.y) + 'px' });
    }, true);
    listen(document, 'pointerup', event => {
      if (!marquee || event.pointerId !== marquee.id) return;
      const gesture = marquee; marquee = null; $('marquee').hidden = true;
      if (!gesture.moved) return;
      event.preventDefault(); event.stopImmediatePropagation();
      const left = Math.min(gesture.x,event.clientX), right = Math.max(gesture.x,event.clientX), top = Math.min(gesture.y,event.clientY), bottom = Math.max(gesture.y,event.clientY);
      const nodes = [...document.body.querySelectorAll('*')].filter(node => { if (!eligible(node) || host.contains(node)) return false; const r = node.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.left >= left && r.right <= right && r.top >= top && r.bottom <= bottom && getComputedStyle(node).visibility !== 'hidden'; });
      chooseNodes(nodes); window.getSelection()?.removeAllRanges();
    }, true);
    listen(document, 'pointercancel', () => { marquee = null; $('marquee').hidden = true; }, true);
    listen(document, 'input', event => { if (active && inline?.node.contains(event.target)) { event.stopImmediatePropagation(); updateAvailability(); } }, true);
    listen(document, 'keydown', event => { if (active && inline?.node.contains(event.target) && !event.ctrlKey && !event.metaKey) event.stopImmediatePropagation(); }, true);
    listen(document, 'submit', event => { if (active && !isEditorUI(event)) { event.preventDefault(); event.stopImmediatePropagation(); } }, true);
    listen(document, 'click', event => {
      if (!active || isEditorUI(event)) return;
      if ((event.ctrlKey || event.metaKey) && eligible(event.target)) { const nodes = selectedItems().map(item => item.node), index = nodes.indexOf(event.target); if (index >= 0) nodes.splice(index, 1); else nodes.push(event.target); chooseNodes(nodes); }
      // Keep links, form submits and app click handlers from navigating while editing.
      if (!inline?.node.contains(event.target)) event.preventDefault();
      event.stopImmediatePropagation();
    }, true);
    function visibleTextTarget(event) {
      const root = event.target;
      if (!(root instanceof HTMLElement) || textField(root)) return root;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let text, inspected = 0;
      while ((text = walker.nextNode()) && inspected++ < 12000) {
        const parent = text.parentElement;
        if (!text.data.trim() || !parent || !eligible(parent) || parent.closest('script,style,noscript,[hidden],[data-live-layout-editor],[data-lle-review]')) continue;
        const style = getComputedStyle(parent);
        if (style.visibility !== 'visible') continue;
        let invisible = false;
        for (let ancestor = parent; ancestor; ancestor = ancestor.parentElement) if (getComputedStyle(ancestor).opacity === '0') { invisible = true; break; }
        if (invisible) continue;
        const range = document.createRange(); range.selectNodeContents(text);
        for (const rect of range.getClientRects()) if (rect.width && rect.height && event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom) return parent;
      }
      return root;
    }
    listen(document, 'dblclick', event => {
      if (!active || isEditorUI(event) || !eligible(event.target)) return;
      event.preventDefault(); event.stopImmediatePropagation(); finishInline();
      if (event.ctrlKey || event.metaKey) return;
      const target = visibleTextTarget(event);
      chooseNodes([target]); beginInline(target, event);
      pulse([captureArea(target, selected)], 'Selected element • double-click editing', 'select');
    }, true);
    function openElementMenu(node, x, y) {
      if (!active || !eligible(node)) return;
      finishInline(); if (!selectedItems().some(item => item.node === node || item.node.contains(node))) { selection = []; selected = selectorFor(node); } advanced = false; menuOpen = true; cssOpen = true;
      const r = node.getBoundingClientRect();
      menuPosition = { x: Number.isFinite(x) ? x : r.left + 12, y: Number.isFinite(y) ? y : r.top + 12 }; delete panelPositions.quickbar;
      render(); $('more').setAttribute('aria-expanded', 'false');
      $('parent').focus({ preventScroll: true });
    }
    listen(document, 'contextmenu', event => {
      if (!active || isEditorUI(event) || !eligible(event.target)) return;
      event.preventDefault(); event.stopImmediatePropagation();
      openElementMenu(event.target, event.clientX, event.clientY);
    }, true);
    listen(window, 'keydown', event => {
      if (!active || !current() || !(event.key === 'ContextMenu' || (event.shiftKey && event.key === 'F10'))) return;
      event.preventDefault(); const r = current().getBoundingClientRect(); openElementMenu(current(), r.left + 12, r.top + 12);
    });
    listen($('done'), 'click', () => { finishInline(); menuOpen = false; advanced = false; outline(); });
    listen($('more'), 'click', () => { finishInline(); advanced = !advanced; $('more').setAttribute('aria-expanded', String(advanced)); outline(); });
    listen($('parent'), 'click', () => { const node = current()?.parentElement; if (eligible(node)) { chooseNodes([node]); } });
    listen($('applyText'), 'click', () => { if (canText(current())) edit(e => { if (textField(current())) e.attrs.value = $('text').value; else e.text = $('text').value; }); });
    function imageAttr(attr) {
      if (current()?.tagName !== 'IMG') return;
      const value = $(attr).value;
      if (attr === 'src') {
        try { if (!safeURL(value)) throw new Error(); }
        catch { status('Use an http(s) image URL or a relative path.'); return; }
      }
      edit(e => { e.attrs[attr] = value; if (attr === 'src') e.attrs.srcset = ''; });
    }
    listen($('applySrc'), 'click', () => imageAttr('src')); listen($('applyAlt'), 'click', () => imageAttr('alt'));
    function freeEntry(node, entry) {
      const r = node.getBoundingClientRect(), size = getComputedStyle(node);
      entry.detached = true;
      Object.assign(entry.styles, { position: 'absolute', left: (r.left + scrollX) + 'px', top: (r.top + scrollY) + 'px',
        width: r.width + 'px', height: r.height + 'px', margin: '0', translate: '0px 0px', transform: 'none',
        'box-sizing': 'border-box', 'max-width': 'none', 'z-index': '1000' });
    }
    const canFree = node => eligible(node) && node !== document.body && node !== document.documentElement && (node instanceof HTMLElement || node instanceof SVGSVGElement) && node.getBoundingClientRect().width > 0 && node.getBoundingClientRect().height > 0;
    listen($('detach'), 'click', () => { const node = current(); if (canFree(node)) edit(entry => freeEntry(node, entry)); else status('Detach the outer SVG or a regular page element.'); });
    listen($('ungroup'), 'click', () => {
      if (!current() || !ready || blocked) return;
      const children = [...current().children].filter(canFree).map(node => ({ node, selector: selectorFor(node) }));
      if (!children.length) { status('No detachable child elements.'); return; }
      checkpoint(); db.pages[path] ||= {};
      for (const item of children) { const entry = db.pages[path][item.selector] ||= { styles: {}, attrs: {} }; freeEntry(item.node, entry); }
      changed();
    });
    const canLayer = node => !!node && node !== document.body && node !== document.documentElement &&
      (node instanceof HTMLElement || node instanceof SVGSVGElement) && !['contents', 'none'].includes(getComputedStyle(node).display);
    function changeLayer(action) {
      finishInline();
      const node = current(); if (!canLayer(node) || !ready || blocked || saving) return;
      const global = action === 'front' || action === 'back';
      const up = action === 'front' || action === 'forward';
      const branches = [node];
      // A child cannot escape its parent's stacking context. Reorder each branch
      // of the ancestor path instead of detaching nodes or changing DOM ownership.
      if (global) for (let parent = node.parentElement; parent && parent !== document.body && parent !== document.documentElement; parent = parent.parentElement) {
        if (canLayer(parent)) branches.push(parent);
      }
      const affected = new Set(), updates = new Map();
      const rank = item => { const value = parseInt(getComputedStyle(item).zIndex, 10); return Number.isFinite(value) ? value : 0; };
      const put = (item, styles) => { updates.set(item, { ...(updates.get(item) || {}), ...styles }); affected.add(item); };
      for (const branch of branches) {
        const parent = branch.parentElement;
        const peers = [...(parent?.children || [])].filter(item => item !== branch && canLayer(item) && !item.hasAttribute('data-live-layout-editor') && !item.hasAttribute('data-lle-review'));
        const values = peers.map(rank), own = rank(branch);
        let next;
        if (global) next = (up ? Math.max(0, ...values, own) + 1 : Math.min(0, ...values, own) - 1);
        else {
          // Assign distinct sibling ranks so one-step actions also work when
          // several siblings share z-index:auto/0 and rely on document order.
          const siblings = [...parent.children];
          const ordered = [...peers, branch].sort((a, b) => rank(a) - rank(b) || siblings.indexOf(a) - siblings.indexOf(b));
          const index = ordered.indexOf(branch), neighbor = index + (up ? 1 : -1);
          if (neighbor < 0 || neighbor >= ordered.length) return;
          [ordered[index], ordered[neighbor]] = [ordered[neighbor], ordered[index]];
          ordered.forEach((item, index) => put(item, { ...(getComputedStyle(item).position === 'static' ? { position: 'relative' } : {}), 'z-index': String(index * 2) }));
          next = neighbor * 2;
        }
        // Keep page content below the editor and avoid the browser's integer clamp.
        // Rebase extreme sibling ranks while preserving their relative rank order.
        if (Math.abs(next) > 1000000) {
          const ordered = [...peers, branch].sort((a, b) => rank(a) - rank(b));
          ordered.forEach((item, index) => {
            const position = getComputedStyle(item).position;
            put(item, { ...(position === 'static' ? { position: 'relative' } : {}), 'z-index': String(index * 2) });
          });
          const ownIndex = ordered.indexOf(branch) * 2;
          next = global ? (up ? ordered.length * 2 + 1 : -1) : ownIndex + (up ? 3 : -3);
        }
        const position = getComputedStyle(branch).position;
        put(branch, { ...(position === 'static' ? { position: 'relative' } : {}), 'z-index': String(next) });
        // Isolation keeps negative layers above their own parent's background.
        // Unlike DOM reparenting, this preserves event/component ownership.
        if (parent && parent !== document.documentElement) put(parent, { isolation: 'isolate' });
        if (global && up && parent && parent !== document.documentElement) {
          const style = getComputedStyle(parent), unclipped = {};
          if (style.overflowX !== 'visible' || style.overflowY !== 'visible') Object.assign(unclipped, { overflow: 'visible', 'overflow-x': 'visible', 'overflow-y': 'visible' });
          if (style.clipPath !== 'none') unclipped['clip-path'] = 'none';
          if (style.maskImage && style.maskImage !== 'none') unclipped['mask-image'] = 'none';
          if (/paint|strict|content/.test(style.contain)) unclipped.contain = 'none';
          if (Object.keys(unclipped).length) put(parent, unclipped);
        }
      }
      checkpoint(); db.pages[path] ||= {};
      for (const [item, styles] of updates) {
        const selector = selectorFor(item), entry = db.pages[path][selector] ||= { styles: {}, attrs: {} };
        if (sourceMode) { entry.source = item.getAttribute('data-lle-source'); entry.descriptor ||= config.describe?.(item); }
        Object.assign(entry.styles, styles);
      }
      changed(); pulse([...affected].map(item => captureArea(item, selectorFor(item))), 'Layer order updated', 'layout');
    }
    for (const [id, action] of [['layerFront', 'front'], ['layerBack', 'back'], ['layerForward', 'forward'], ['layerBackward', 'backward']]) listen($(id), 'click', () => changeLayer(action));
    listen($('quickColor'), 'input', () => edit(e => { e.styles[current() instanceof SVGElement ? 'fill' : 'color'] = $('quickColor').value; }));
    listen($('quickBackground'), 'input', () => edit(e => { e.styles['background-color'] = $('quickBackground').value; }));
    listen($('quickSize'), 'change', () => { const v = $('quickSize').valueAsNumber; if (v > 0) edit(e => { e.styles['font-size'] = v + 'px'; }); });
    listen($('hide'), 'click', () => { if (!current()) return; for (const item of selectedItems()) rememberHidden(item.node,item.selector); edit(e => { e.styles.display = 'none'; }); deselect(); });
    listen($('replace'), 'click', () => {
      const node = current(); if (!node) return;
      if (node.localName === 'img') { const value = prompt('Replace image URL', node.getAttribute('src') || ''); if (value !== null && safeURL(value)) edit(e => { e.attrs.src = value; e.attrs.srcset = ''; }); }
      else if (canText(node)) { const value = prompt('Replace text', textField(node) ? node.value : node.textContent); if (value !== null) edit(e => { delete e.html; if (textField(node)) e.attrs.value = value; else e.text = value; }); }
      else { advanced = true; $('inspector').hidden = false; $('html').value = node.innerHTML; $('html').closest('details').open = true; $('html').focus(); }
    });
    listen($('upload'), 'click', () => $('imageFile').click());
    listen($('imageFile'), 'change', async () => {
      const file = $('imageFile').files[0], target = selected;
      if (!file) return;
      if (!/^image\/(png|jpeg|gif|webp|avif)$/.test(file.type) || file.size > 1000000) { status('Choose a PNG/JPEG/GIF/WebP/AVIF image up to 1 MB.'); return; }
      const data = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); });
      if (selected === target) edit(e => { e.attrs.src = data; e.attrs.srcset = ''; });
      $('imageFile').value = '';
    });
    listen($('customApply'), 'click', () => {
      const prop = $('customProp').value.trim(), value = $('customValue').value.trim();
      if (!/^(?:--[a-zA-Z0-9_-]+|[a-z][a-z-]*)$/.test(prop) || (value && (!CSS.supports(prop, value) || /[;{}<>]|url\s*\(|expression\s*\(/i.test(value)))) { status('Enter a valid CSS property and value.'); return; }
      edit(e => { if (value) e.styles[prop] = value; else delete e.styles[prop]; });
    });
    listen($('applyAttr'), 'click', () => {
      const name = $('attrName').value.trim(), value = $('attrValue').value;
      if (!allowedAttrs.includes(name) || (['href', 'src', 'poster'].includes(name) && !safeURL(value, name)) || (name === 'srcset' && value)) { status('Use a supported text or URL attribute.'); return; }
      edit(e => { e.attrs[name] = value; });
    });
    listen($('applyHtml'), 'click', () => {
      const value = $('html').value;
      if (value.length > 100000) { status('HTML is too large.'); return; }
      edit(e => { e.html = value; delete e.text; });
    });
    listen($('resetElement'), 'click', () => { if (ready && !blocked) { checkpoint(); for (const item of selectedItems()) delete db.pages[path]?.[item.selector]; changed(); } });
    listen($('resetPage'), 'click', () => { if (!ready || blocked) return; checkpoint(); delete db.pages[path]; changed(); });
    function undo() { if (!undoStack.length || blocked || !ready) return; pendingActionPages = copy(db.pages); redoStack.push(copy(db.pages)); db.pages = undoStack.pop(); changed(); }
    function redo() { if (!redoStack.length || blocked || !ready) return; pendingActionPages = copy(db.pages); undoStack.push(copy(db.pages)); db.pages = redoStack.pop(); changed(); }
    listen($('undo'), 'click', undo); listen($('redo'), 'click', redo);
    listen($('export'), 'click', exportChanges); listen($('flush'), 'click', save);
    listen($('reload'), 'click', async () => {
      if (saving || (dirty && !confirm('Discard unsaved tab edits and reload project files? Export first if you need them.'))) return;
      try { db = await request('/manifest'); revision = db.revision; dirty = blocked = false; ready = true; undoStack = []; redoStack = []; $('reload').hidden = true; apply(); render(); status('Loaded saved project version.'); }
      catch (error) { status(error.message); }
    });
    for (const [id, resize] of [['move', false], ['resize', true]]) {
      listen($(id), 'pointerdown', event => {
        if (!current() || !ready || blocked) return;
        let xy; try { xy = translation(); for (const item of selectedItems()) translation(item.node, item.selector); } catch (error) { status(error.message); return; }
        event.preventDefault(); $(id).focus({ preventScroll: true }); checkpoint(); $(id).setPointerCapture(event.pointerId);
        const node = current(), size = getComputedStyle(node);
        menuOpen = false; advanced = false; outline();
        followCSS(resize ? ['width', 'height', 'max-width'] : ['translate', 'position', 'top', 'left', 'transform'], resize ? 'Resizing' : 'Moving');
        const source = sourceMode ? node.getAttribute('data-lle-source') : undefined;
        const descriptor = sourceMode ? config.describe?.(node) : undefined;
        // CSS width/height operate before transforms, unlike getBoundingClientRect.
        const items = selectedItems().map(item => ({ ...item, xy: translation(item.node,item.selector), w: parseFloat(getComputedStyle(item.node).width) || item.node.offsetWidth, h: parseFloat(getComputedStyle(item.node).height) || item.node.offsetHeight, source: item.node.getAttribute('data-lle-source'), descriptor: sourceMode ? config.describe?.(item.node) : undefined }));
        drag = { items, id: event.pointerId, sx: event.clientX, sy: event.clientY, xy,
          w: parseFloat(size.width) || node.offsetWidth, h: parseFloat(size.height) || node.offsetHeight, resize, source, descriptor, changed: false };
      });
      listen($(id), 'pointermove', event => {
        if (!drag || drag.id !== event.pointerId) return;
        db.pages[path] ||= {};
        const dx = event.clientX - drag.sx, dy = event.clientY - drag.sy;
        for (const item of drag.items) {
          const entry = db.pages[path][item.selector] ||= { styles: {}, attrs: {} };
          if (sourceMode) { entry.source ||= item.source; entry.descriptor ||= item.descriptor; }
          const style = entry.styles;
          if (drag.resize) { style.width = Math.max(8,item.w + dx) + 'px'; style.height = Math.max(8,item.h + dy) + 'px'; style['max-width'] = 'none'; }
          else style.translate = (item.xy[0] + dx) + 'px ' + (item.xy[1] + dy) + 'px';
        }
        drag.changed = true; apply(); refreshCSS(true);
        pulse([captureArea(current(), selected)], drag.resize ? 'Resize • highlighted element' : 'Move • highlighted element', 'layout');
      });
      const stop = () => { if (!drag) return; const moved = drag.changed; drag = null; if (moved) changed(); else undoStack.pop(); };
      listen($(id), 'pointerup', stop); listen($(id), 'pointercancel', stop); listen($(id), 'lostpointercapture', stop);
    }
    listen(shadow, 'click', event => {
      const button = event.target.closest?.('button');
      if (!button || button.disabled) return;
      const id = button.id, node = current(), before = copy(db.pages);
      const selectedArea = captureArea(node, selected);
      const pageAreas = captureSelectors(Object.keys(page()));
      const childAreas = node ? [...node.children].filter(eligible).map(child => captureArea(child, selectorFor(child))) : [];
      const descriptions = {
        move: ['Move • drag to reposition this element', 'layout'], resize: ['Resize • drag this element’s corner', 'layout'],
        parent: ['Parent • highlighted container is now selected', 'select'],
        detach: ['Free element • this element moves independently', 'layout'],
        ungroup: [childAreas.length ? 'Free children • highlighted children are independent' : 'Free children • no detachable child elements', 'layout'],
        hide: ['Hide • this was the element’s visible area', 'remove'],
        resetElement: ['Reset element • restore this element’s original appearance', 'remove'],
        resetPage: ['Reset page • areas whose preview edits are removed', 'remove'],
        undo: ['Undo • affected areas', 'layout'], redo: ['Redo • affected areas', 'layout'],
        more: ['More • controls belong to this highlighted element', 'select'],
        replace: ['Replace • target element or its contents', 'edit'], upload: ['Image file • replacement target', 'edit'],
        applyText: ['Apply text • preview of this element', 'edit'], applySrc: ['Replace image • preview target', 'edit'],
        applyAlt: ['Alt text • attribute of this image', 'edit'], applyAttr: ['Set attribute • preview target', 'edit'],
        applyHtml: ['Replace contents • highlighted container', 'edit'], customApply: ['Set CSS • highlighted element', 'edit'],
        done: ['Done • edit kept in page preview', 'select'], close: ['Exit edit mode • preview remains on the page', 'select'],
        launcher: ['Edit mode • double-click an element on the page', 'select'],
        flush: [dirty ? 'Apply requested • visible edited areas' : 'Apply • no pending source changes', 'save'],
        reload: ['Reload saved version • preview areas being refreshed', 'layout']
      };
      if (id === 'export') return; // export describes its download separately
      const description = descriptions[id]; if (!description) return;
      deferFeedback(() => {
        if (destroyed) return;
        let areas = selectedArea ? [selectedArea] : [];
        if (id === 'parent') areas = [captureArea(current(), selected)];
        if (id === 'ungroup') areas = childAreas.length ? childAreas : areas;
        if (['resetPage', 'flush', 'reload'].includes(id)) areas = pageAreas;
        if (['undo', 'redo'].includes(id)) {
          const selectors = changedAreas(before, db.pages);
          areas = captureSelectors(selectors);
          for (const old of pageAreas) if (selectors.includes(old.selector) && !areas.some(a => a.selector === old.selector)) areas.push(old);
        }
        pulse(areas, description[0], description[1]);
      });
    }, true);
    const fieldFeedback = event => {
      const input = event.target;
      if (!input.matches?.('input,select,textarea') || input.type === 'file') return;
      const area = captureArea(current(), selected); if (!area) return;
      const label = input.getAttribute('aria-label') || input.dataset.prop || input.closest('label')?.textContent?.trim() || 'Control';
      deferFeedback(() => pulse([area], label + ' • highlighted element', 'edit'));
    };
    listen(shadow, 'input', updateAvailability);
    listen(shadow, 'change', fieldFeedback, true);
    listen(shadow, 'input', event => { if (event.target.type === 'color') fieldFeedback(event); }, true);
    listen(window, 'resize', () => { outline(); updateFeedback(); updateHiddenHints(); }); listen(window, 'scroll', () => { outline(); updateFeedback(); updateHiddenHints(); }, true);
    listen(window, 'keydown', event => {
      if (active && !inline && ['Delete','Backspace'].includes(event.key) && current() && !event.composedPath()[0]?.matches?.('input,textarea,select,[contenteditable]')) { event.preventDefault(); $('hide').click(); return; }
      if (event.key === 'Escape') { if (menuOpen) { finishInline(); menuOpen = false; advanced = false; outline(); } else deselect(); }
      const target = event.composedPath()[0];
      if (!active || target?.matches?.('input,textarea,select,[contenteditable]')) return;
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); event.shiftKey ? redo() : undo(); }
    });
    listen(window, 'beforeunload', event => { finishInline(); if (bridge && dirty) { event.preventDefault(); event.returnValue = ''; } });
    const routeTimer = setInterval(() => {
      if (path !== location.pathname) { finishInline(); path = location.pathname; loadHiddenRecords(); selected = null; selection = []; menuOpen = false; apply(); render(); }
      if (active) { outline(); updateAvailability(); refreshCSS(); }
      updateHiddenHints();
      if (feedbackItems.length) updateFeedback();
    }, 250);
    window.LiveLayoutEditor = {
      open: () => toggle(true), close: () => toggle(false), export: exportChanges,
      getChanges: () => { finishInline(); return copy(db); }, getMode: () => bridge ? 'local' : 'preview', save, apply: save,
      destroy() { finishInline(); destroyed = true; clearTimeout(feedbackTimer); clearTimeout(feedbackJob); clearInterval(routeTimer); clearTimeout(timer); cancelAnimationFrame(applyFrame);
        observer.disconnect(); cleanups.forEach(fn => fn()); restore(); host.remove();
        if (originalPageAttribute === null) document.documentElement.removeAttribute('data-lle-page');
        else document.documentElement.setAttribute('data-lle-page', originalPageAttribute);
        delete window.LiveLayoutEditor; }
    };
    loadHiddenRecords(); apply(); updateAvailability();
    if (bridge) request('/manifest').then(data => {
      db = data; revision = data.revision; ready = true; apply(); render();
      $('mode').textContent = sourceMode ? ('SOURCE • original files • ' + (config.autoApply ? 'Auto-apply on' : 'Manual Apply with source review')) : 'LOCAL • edits stay in preview until you click Apply changes in code.';
      status(sourceMode ? 'Connected to source. Edit visually, then Apply changes in code to choose/review the original source.' : 'Connected • double-click any element. Apply changes in code writes staged changes.');
    }).catch(error => { blocked = true; $('reload').hidden = false; status('Cannot connect: ' + error.message); });
  };
