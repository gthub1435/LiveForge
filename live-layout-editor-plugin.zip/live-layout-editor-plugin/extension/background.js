'use strict';
const HOST = 'app.livelayout.companion';
const local = value => { try { const u = new URL(value); return ['http:', 'https:'].includes(u.protocol) && ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname); } catch { return false; } };
async function native(message) {
  const res = await chrome.runtime.sendNativeMessage(HOST, message);
  if (!res?.ok) throw new Error(res?.error || 'Local companion did not respond'); return res.data;
}
async function tabState(id) { return (await chrome.storage.session.get('tab-' + id))['tab-' + id]; }
chrome.tabs.onRemoved.addListener(id => chrome.storage.session.remove('tab-' + id));
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || message?.kind !== 'lle') return;
  (async () => {
    const extensionPage = sender.url?.startsWith(chrome.runtime.getURL(''));
    if (sender.tab && !extensionPage) {
      const state = await tabState(sender.tab.id);
      if (!state || !local(sender.url) || new URL(sender.url).origin !== state.origin || state.mode !== 'source') throw new Error('This tab is not connected for source editing');
      if (message.action === 'context') return state;
      if (message.action === 'resolve') return native({ action: 'resolve', session: state.session, origin: state.origin, descriptor: message.descriptor, filter: message.filter });
      if (message.action === 'plan') return native({ action: 'plan', session: state.session, origin: state.origin, changes: message.changes, allowShared: state.allowShared, allowTokenOverride: state.allowTokenOverride });
      if (message.action === 'apply') return native({ action: 'apply', session: state.session, origin: state.origin, plan: message.plan });
      throw new Error('Content script action is not allowed');
    }
    if (!sender.url?.startsWith(chrome.runtime.getURL(''))) throw new Error('Extension page required');
    if (message.action === 'ping') return native({ action: 'ping' });
    if (message.action === 'choose-folder') {
      const tab = await chrome.tabs.get(message.tab);
      if (!local(tab.url)) throw new Error('Project connections require localhost');
      const origin = new URL(tab.url).origin;
      const selected = await native({ action: 'choose-folder', origin });
      if (selected.cancelled) return selected;
      const current = await chrome.tabs.get(message.tab);
      if (!local(current.url) || new URL(current.url).origin !== origin) throw new Error('The page address changed. Reopen the extension on the intended localhost page.');
      const project = await native({ action: 'connect', root: selected.root, origin });
      return { cancelled: false, project };
    }
    if (message.action === 'connect') {
      const tab = await chrome.tabs.get(message.tab);
      if (!local(tab.url)) throw new Error('Project connections require localhost');
      return native({ action: 'connect', root: message.root, origin: new URL(tab.url).origin });
    }
    if (message.action === 'state') return tabState(message.tab);
    if (message.action === 'start') {
      const tab = await chrome.tabs.get(message.tab);
      if (!/^https?:/.test(tab.url || '')) throw new Error('Open a normal website or localhost page');
      let state = { mode: 'preview', origin: new URL(tab.url).origin };
      if (message.mode === 'source') {
        if (!local(tab.url)) throw new Error('Live websites are preview-only');
        const session = await native({ action: 'open', origin: new URL(tab.url).origin });
        state = { ...session, mode: 'source', autoApply: false, allowShared: message.allowShared === true, allowTokenOverride: message.allowTokenOverride === true };
      }
      await chrome.storage.session.set({ ['tab-' + tab.id]: state });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['editor-runtime.js'] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: value => { globalThis.__LLE_CONTEXT__ = value; }, args: [state] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      return { started: true, mode: state.mode, project: state.name };
    }
    throw new Error('Unknown extension command');
  })().then(data => reply({ ok: true, data }), error => reply({ ok: false, error: error.message }));
  return true;
});

// Refreshing an explicitly connected local tab reopens a fresh source snapshot.
// Other origins never inherit the connection, including redirects to live sites.
chrome.tabs.onUpdated.addListener((id, change, tab) => {
  if (change.status !== 'complete') return;
  (async () => {
    const state = await tabState(id);
    if (!state || state.mode !== 'source') return;
    if (!local(tab.url) || new URL(tab.url).origin !== state.origin) { await chrome.storage.session.remove('tab-' + id); return; }
    const session = await native({ action: 'open', origin: state.origin });
    const refreshed = { ...state, ...session, autoApply: false };
    await chrome.storage.session.set({ ['tab-' + id]: refreshed });
    await chrome.scripting.executeScript({ target: { tabId: id }, files: ['editor-runtime.js'] });
    await chrome.scripting.executeScript({ target: { tabId: id }, func: value => { globalThis.__LLE_CONTEXT__ = value; }, args: [refreshed] });
    await chrome.scripting.executeScript({ target: { tabId: id }, files: ['content.js'] });
  })().catch(() => {}); // A closed/restricted tab must never trigger a retry loop.
});
