'use strict';
(async () => {
  const context = globalThis.__LLE_CONTEXT__;
  if (!context) return;
  if (window.LiveLayoutEditor) window.LiveLayoutEditor.destroy();
  if (document.querySelector('[data-live-layout-editor]')) throw new Error('Reload the page without the old script-based editor before using the extension.');
  const send = async message => { const result = await chrome.runtime.sendMessage({ kind: 'lle', ...message }); if (!result?.ok) throw new Error(result?.error || 'Extension connection lost'); return result.data; };
  let revision = 0;
  const describe = node => ({ tag: node.localName, text: (node.children.length ? [...node.childNodes].filter(child => child.nodeType === Node.TEXT_NODE).map(child => child.data).join('') : node.textContent).slice(0, 2000), attrs: Object.fromEntries(['id', 'class', 'name', 'data-testid', 'data-lle-id', 'src', 'href', 'alt', 'placeholder', 'aria-label'].map(key => [key, (node.getAttribute(key) || '').slice(0, 2000)])) });
  const decode = node => { try { const encoded = node.getAttribute('data-lle-source'); const binary = atob(encoded.replace(/-/g, '+').replace(/_/g, '/')); return JSON.parse(new TextDecoder().decode(Uint8Array.from(binary, c => c.charCodeAt(0)))); } catch { return null; } };
  globalThis.__LLE_BROWSER_PLUGIN__({
    hiddenScope: context.project || 'preview', source: context.mode === 'source', origin: context.origin, autoApply: context.autoApply,
    capabilities: decode, describe,
    request: async (route, options = {}) => {
      if (route === '/manifest') return { version: 1, revision, pages: {} };
      if (route !== '/save') throw new Error('Unsupported source request');
      const db = JSON.parse(options.body), changes = [];
      for (const entries of Object.values(db.pages)) for (const [selector, entry] of Object.entries(entries)) {
        let source = entry.source || document.querySelector(selector)?.getAttribute('data-lle-source');
        if (!source) {
          if (!entry.descriptor) throw new Error('Original element description is unavailable. Reload and stage the edit again.');
          const result = await send({ action: 'resolve', descriptor: entry.descriptor });
          if (!result.automatic) throw new Error('Source mapping is not unambiguous for ' + selector + '. No files changed. Enable development source mappings for this project; the extension will not guess a file.');
          source = result.automatic;
          entry.source = source;
        }
        const instances = Math.max(1, [...document.querySelectorAll('[data-lle-source]')].filter(n => n.getAttribute('data-lle-source') === source).length);
        changes.push({ ...entry, source, instances });
      }
      const plan = await send({ action: 'plan', changes });
      // Every code write requires source review.
      const approved = await reviewPlan(plan);
      if (!approved) throw new Error('Source Apply cancelled. Preview was kept.');
      const result = await send({ action: 'apply', plan: plan.plan });
      // Static servers have no HMR. Reload after source Apply, never for previews.
      if (changes.some(change => !document.querySelector('[data-lle-source="' + CSS.escape(change.source) + '"]'))) setTimeout(() => location.reload(), 900);
      return { ...result, revision: ++revision };
    }
  });
  function reviewPlan(plan) {
    return new Promise(resolve => {
      const host = document.createElement('div'); host.dataset.lleReview = ''; host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;';
      host.dataset.lleStep = 'review';
      const shadow = host.attachShadow({ mode: 'closed' });
      shadow.innerHTML = `<style>:host{font:14px/1.5 system-ui;color:#17233d}.backdrop{position:fixed;inset:0;background:#14243b88;display:grid;place-items:center;backdrop-filter:blur(6px)}section{background:#f5f6ff;border:1px solid #fff;border-radius:20px;width:min(1050px,94vw);max-height:90vh;overflow:auto;padding:24px;box-sizing:border-box}h2{margin:0 0 8px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:white;padding:14px;border:1px solid #ccd2e5;border-radius:10px;font:12px/1.6 ui-monospace,monospace}.columns{display:grid;grid-template-columns:1fr 1fr;gap:12px}button{font:600 14px system-ui;padding:10px 18px;border-radius:10px;border:1px solid #b8b4d4;cursor:pointer;margin:8px 8px 0 0}#apply{background:#6242d7;color:white}p{color:#455570}</style><div class="backdrop"><section role="dialog" aria-modal="true" aria-label="Review source changes"><h2>Apply source changes</h2><p>These original files will change. Shared declarations can affect other component instances.</p><div id="files"></div><button id="apply">Apply these source changes</button><button id="cancel">Keep preview only</button></section></div>`;
      const list = shadow.getElementById('files');
      for (const file of plan.files) {
        const title = document.createElement('h3'); title.textContent = file.file;
        const columns = document.createElement('div'); columns.className = 'columns';
        for (const [label, text] of [['Before', file.before], ['After', file.after]]) { const col = document.createElement('div'), head = document.createElement('strong'), pre = document.createElement('pre'); head.textContent = label; pre.textContent = text; col.append(head, pre); columns.append(col); }
        list.append(title, columns);
      }
      const done = value => { host.remove(); resolve(value); };
      shadow.getElementById('apply').onclick = () => done(true); shadow.getElementById('cancel').onclick = () => done(false);
      document.documentElement.append(host);
      shadow.getElementById('cancel').focus();
    });
  }
})();
