"use strict";
const $ = id => document.getElementById(id);
const tabId = Number(new URLSearchParams(location.search).get('tab'));
async function send(message) { const result = await chrome.runtime.sendMessage({ kind: 'lle', ...message }); if (!result?.ok) throw new Error(result?.error || 'Companion connection failed'); return result.data; }
$('return').onclick = async () => { try { await chrome.tabs.update(tabId, { active: true }); } catch { $('status').textContent = 'The localhost tab was closed.'; } };
$('browse').onclick = async () => {
  $('browse').disabled = true; $('status').textContent = 'Choose a folder in the Windows folder browser…';
  try {
    const result = await send({ action: 'choose-folder', tab: tabId });
    $('status').textContent = result.cancelled ? 'Selection canceled. Your connection has not changed.' : 'Connected: ' + result.project.name;
    if (!result.cancelled) $('return').hidden = false;
  } catch (error) { $('status').textContent = error.message + '\nIf the companion is missing or outdated, run INSTALL-COMPANION.cmd from the latest extracted package. You can also enter a path manually in the extension popup.'; }
  finally { $('browse').disabled = false; }
};
(async () => {
  try {
    if (!Number.isInteger(tabId) || tabId <= 0) throw new Error('Open this page using Choose project folder in the extension popup.');
    const tab = await chrome.tabs.get(tabId), url = new URL(tab.url);
    if (!['http:', 'https:'].includes(url.protocol) || !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) throw new Error('Open the extension on a localhost page first.');
    $('origin').textContent = url.origin;
  } catch (error) { $('status').textContent = error.message; $('browse').disabled = true; }
})();
