'use strict';
const fs = require('node:fs'), path = require('node:path'), { instrument } = require('./engine.cjs');
module.exports = function (source) {
  const options = this.getOptions();
  if (!options.enabled) return source;
  const root = fs.realpathSync(options.root);
  return instrument(String(source), this.resourcePath, root, options.project);
};
