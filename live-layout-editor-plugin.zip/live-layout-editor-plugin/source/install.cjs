#!/usr/bin/env node
'use strict';
const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto'), os = require('node:os');
const ID = 'dokegogmplloinclaknicnlepmblcjfa';
function validatePackage(root) {
  for (const name of ['package.json', 'package-lock.json', 'source/native-host.cjs', 'source/engine.cjs', 'source/discovery.cjs', 'source/companion.cjs']) {
    if (!fs.existsSync(path.join(root, name))) throw new Error('The complete package is required. Use Extract All on the ZIP, then run INSTALL-COMPANION.cmd from the extracted folder. Missing: ' + name);
  }
}
function npmCLI() {
  const candidates = [process.env.npm_execpath, path.join(path.dirname(process.execPath), 'node_modules/npm/bin/npm-cli.js'), path.resolve(path.dirname(process.execPath), '../lib/node_modules/npm/bin/npm-cli.js'), '/usr/share/nodejs/npm/bin/npm-cli.js'];
  if (process.platform === 'win32') {
    try { for (const file of cp.execFileSync('where.exe', ['npm.cmd'], { encoding: 'utf8' }).trim().split(/\r?\n/)) candidates.push(path.join(path.dirname(file), 'node_modules/npm/bin/npm-cli.js')); } catch {}
  }
  const found = candidates.find(file => file && /npm-cli\.js$/.test(file) && fs.existsSync(file));
  if (!found) throw new Error('Could not locate npm. Install Node.js with npm, then run the installer again.');
  return found;
}
function install(root = path.resolve(__dirname, '..')) {
  if (Number(process.versions.node.split('.')[0]) < 20) throw new Error('Node.js 20 or newer is required.');
  validatePackage(root);
  const base = process.env.LLE_STATE_DIR || path.join(os.homedir(), '.live-layout-editor');
  fs.mkdirSync(base, { recursive: true });
  const target = path.join(base, 'companion'), stage = path.join(base, 'companion-install-' + crypto.randomBytes(6).toString('hex'));
  const backup = path.join(base, 'companion-previous-' + Date.now()), hadTarget = fs.existsSync(target);
  const saved = new Map(['native-host.json', 'native-host.cmd', 'native-host'].map(name => { const file = path.join(base, name); return [file, fs.existsSync(file) ? fs.readFileSync(file) : null]; }));
  let activated = false, backedUp = false;
  try {
    fs.mkdirSync(stage);
    fs.cpSync(path.join(root, 'source'), path.join(stage, 'source'), { recursive: true });
    for (const name of ['package.json', 'package-lock.json']) fs.copyFileSync(path.join(root, name), path.join(stage, name));
    console.log('Installing local source companion to a permanent user folder…');
    // Run npm's JavaScript entry point with Node directly. No shell, CMD
    // quoting, execution-policy changes or script associations are involved.
    const result = cp.spawnSync(process.execPath, [npmCLI(), 'ci', '--omit=dev', '--ignore-scripts', '--no-audit', '--no-fund'], { cwd: stage, stdio: 'inherit' });
    if (result.error || result.status !== 0) throw new Error('Could not install companion dependencies. Check Node.js/npm and your connection, then retry. ' + (result.error?.message || ''));
    if (hadTarget) { fs.renameSync(target, backup); backedUp = true; }
    fs.renameSync(stage, target); activated = true;
    const { register } = require(path.join(target, 'source/companion.cjs'));
    const registration = register(ID);
    console.log('Companion installed. Open your localhost page, connect its project folder in the extension popup, and choose Start local project editing.');
    return { installed: true, directory: target, ...registration };
  } catch (error) {
    if (activated) fs.rmSync(target, { recursive: true, force: true });
    if (backedUp) fs.renameSync(backup, target);
    for (const [file, value] of saved) { if (value === null) fs.rmSync(file, { force: true }); else fs.writeFileSync(file, value); }
    throw error;
  } finally { fs.rmSync(stage, { recursive: true, force: true }); }
}
if (require.main === module) try { console.log(JSON.stringify(install(), null, 2)); } catch (error) { console.error(error.message); process.exitCode = 1; }
module.exports = { validatePackage, install };
