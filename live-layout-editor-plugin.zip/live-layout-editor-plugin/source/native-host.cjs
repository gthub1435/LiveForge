#!/usr/bin/env node
'use strict';
const { dispatch, stateDir } = require('./store.cjs'), fs = require('node:fs'), path = require('node:path');
// Chrome verifies allowed_origins; the host additionally checks its caller argument.
const caller = process.argv.find(a => /^chrome-extension:\/\/[a-p]{32}\/$/.test(a));
try { const allowed = JSON.parse(fs.readFileSync(path.join(stateDir(), 'native-host.json'), 'utf8')).allowed_origins; if (!caller || !allowed.includes(caller)) throw new Error(); }
catch { process.stderr.write('Unregistered extension caller\n'); process.exit(1); }
let buffer = Buffer.alloc(0);
function send(data) { const body = Buffer.from(JSON.stringify(data)); if (body.length > 1000000) return send({ ok: false, error: 'Companion response exceeds native message limit' }); const head = Buffer.alloc(4); head.writeUInt32LE(body.length); process.stdout.write(Buffer.concat([head, body])); }
process.stdin.on('data', chunk => {
  buffer = Buffer.concat([buffer, chunk]);
  while (buffer.length >= 4) {
    const size = buffer.readUInt32LE(); if (size > 8 * 1024 * 1024) { process.exitCode = 1; process.stdin.destroy(); return; }
    if (buffer.length < size + 4) break;
    const payload = buffer.subarray(4, size + 4); buffer = buffer.subarray(size + 4);
    try { send({ ok: true, data: dispatch(JSON.parse(payload)) }); } catch (e) { send({ ok: false, error: e.message, code: e.code || 'COMPANION' }); }
  }
});
