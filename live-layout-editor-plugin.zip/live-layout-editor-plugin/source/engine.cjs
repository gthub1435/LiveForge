'use strict';
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const parser = require('@babel/parser'), postcss = require('postcss');
const hash = text => crypto.createHash('sha256').update(text).digest('hex');
const fail = (code, message) => { const e = new Error(message); e.code = code; throw e; };
function parse(text, file) { return parser.parse(text, { sourceType: 'unambiguous', plugins: [...(/\.[cm]?tsx?$/.test(file) ? ['typescript'] : []), 'jsx', 'decorators-legacy'], errorRecovery: false }); }
function walk(node, fn) { if (!node || typeof node !== 'object') return; if (typeof node.type === 'string') fn(node); for (const [key, value] of Object.entries(node)) if (!['loc', 'tokens', 'comments', 'errors'].includes(key)) { if (Array.isArray(value)) value.forEach(n => walk(n, fn)); else if (value && typeof value === 'object') walk(value, fn); } }
function inside(root, file) { const rel = path.relative(root, file); return rel && !rel.startsWith('..' + path.sep) && !path.isAbsolute(rel) && rel !== '..'; }
function checkedFile(root, relative) {
  if (typeof relative !== 'string' || relative.includes('\0') || relative.split(/[\\/]/).some(p => ['node_modules', '.git', '.next', '..'].includes(p))) fail('PATH', 'Source path is not permitted');
  const absolute = fs.realpathSync(path.resolve(root, relative));
  if (!inside(root, absolute) || !/\.(?:jsx?|tsx?|css|html?|vue|svelte|astro)$/.test(absolute)) fail('PATH', 'Only source files inside the connected project may be edited');
  return absolute;
}
function read(root, relative) { const file = checkedFile(root, relative); if (fs.statSync(file).size > 500000) fail('SIZE', 'Source file is too large'); return { file, text: fs.readFileSync(file, 'utf8') }; }
function sourceElements(ast) { const out = []; walk(ast, n => { if (n.type === 'JSXElement') out.push(n); }); return out; }
function jsxName(name) { if (name.type === 'JSXIdentifier') return name.name; if (name.type === 'JSXMemberExpression') return jsxName(name.object) + '.' + jsxName(name.property); return ''; }
function moduleInfo(text, file) {
  const ast = parse(text, file), imports = new Map(), variables = new Map();
  for (const statement of ast.program.body) {
    const item = statement.type.startsWith('Export') && statement.declaration ? statement.declaration : statement;
    if (item.type === 'ImportDeclaration') for (const spec of item.specifiers) imports.set(spec.local.name, { from: item.source.value, imported: spec.imported?.name || 'default' });
    if (item.type === 'VariableDeclaration') for (const decl of item.declarations) if (decl.id.type === 'Identifier') variables.set(decl.id.name, decl.init);
  }
  return { ast, imports, variables };
}
function resolveImport(root, current, spec) {
  let bases = [];
  if (spec.startsWith('.')) bases = [path.resolve(path.dirname(current), spec)];
  else {
    // Next's common baseUrl aliases. Only resolve within the connected source root.
    bases = [path.join(root, spec), path.join(root, 'app', spec), path.join(root, 'src', spec)];
    const cfgFile = path.join(root, 'tsconfig.json');
    if (fs.existsSync(cfgFile)) {
      try {
        const raw = fs.readFileSync(cfgFile, 'utf8');
        const cfg = parser.parseExpression('(' + raw.replace(/^\uFEFF/, '') + ')');
        const literal = n => n?.type === 'StringLiteral' ? n.value : null;
        const options = cfg.properties?.find(p => (p.key.name || p.key.value) === 'compilerOptions')?.value;
        const base = literal(options?.properties?.find(p => (p.key.name || p.key.value) === 'baseUrl')?.value) || '.';
        const aliases = options?.properties?.find(p => (p.key.name || p.key.value) === 'paths')?.value;
        for (const prop of aliases?.properties || []) {
          const key = prop.key.value || prop.key.name, star = key.indexOf('*');
          const match = star < 0 ? (spec === key ? '' : null) : (spec.startsWith(key.slice(0, star)) && spec.endsWith(key.slice(star + 1)) ? spec.slice(star, spec.length - (key.length - star - 1)) : null);
          if (match !== null) for (const value of prop.value.elements || []) { const route = literal(value); if (route) bases.unshift(path.resolve(root, base, route.replace('*', match))); }
        }
      } catch {} // unresolved aliases fail closed below; never execute configuration
    }
  }
  for (const base of bases) for (const suffix of ['', '.tsx', '.ts', '.jsx', '.js', '/index.tsx', '/index.ts', '/index.jsx', '/index.js']) {
    const file = base + suffix;
    if (inside(root, file) && fs.existsSync(file) && fs.statSync(file).isFile()) return checkedFile(root, path.relative(root, file));
  }
  fail('IMPORT', 'Cannot resolve source import: ' + spec);
}
function styledOwner(root, current, info, name, depth = 0, allowDynamic = false) {
  if (depth > 5) fail('IMPORT', 'Styled component import chain is too deep');
  const value = info.variables.get(name);
  if (value?.type === 'TaggedTemplateExpression') {
    let base = value.tag; while (['CallExpression', 'TSInstantiationExpression'].includes(base.type)) base = base.callee || base.expression;
    const local = base.type === 'MemberExpression' ? base.object.name : base.type === 'Identifier' ? base.name : null;
    if (info.imports.get(local)?.from === 'styled-components') {
      if (value.quasi.expressions.length && !allowDynamic) fail('DYNAMIC_STYLE', 'This styled template contains expressions. Edit it in your code editor; no source write was attempted.');
      return { kind: 'styled', file: current, template: value.quasi, info, tag: base.type === 'MemberExpression' && !base.computed ? base.property.name : null };
    }
  }
  const imported = info.imports.get(name);
  if (imported && imported.from !== 'styled-components') {
    const file = resolveImport(root, current, imported.from), text = fs.readFileSync(file, 'utf8'), next = moduleInfo(text, file);
    return styledOwner(root, file, next, imported.imported, depth + 1, allowDynamic);
  }
  return null;
}
function cssOwners(root, file, info, node) {
  const attr = node.openingElement.attributes.find(a => a.name?.name === 'className');
  if (!attr) return null;
  let classes = [], importedCSS = [];
  if (attr.value?.type === 'StringLiteral') {
    classes = attr.value.value.split(/\s+/).filter(Boolean);
    importedCSS = info.ast.program.body.filter(n => n.type === 'ImportDeclaration' && /\.css$/.test(n.source.value)).map(n => n.source.value);
  } else if (attr.value?.expression?.type === 'MemberExpression' && !attr.value.expression.computed) {
    const expr = attr.value.expression, imported = info.imports.get(expr.object.name);
    if (imported && /\.css$/.test(imported.from)) { classes = [expr.property.name]; importedCSS = [imported.from]; }
  }
  if (!classes.length || !importedCSS.length) fail('CSS_MAPPING', 'Class styles cannot be mapped unambiguously. CSS-in-JS expressions, global layout imports and Tailwind need their own adapter.');
  const candidates = [];
  for (const spec of importedCSS) {
    const cssFile = resolveImport(root, file, spec), text = fs.readFileSync(cssFile, 'utf8'), ast = postcss.parse(text);
    for (const rule of ast.nodes.filter(n => n.type === 'rule')) if (classes.some(name => rule.selector.trim() === '.' + name)) candidates.push({ file: cssFile, rule });
  }
  if (!candidates.length) fail('CSS_MAPPING', 'No unique top-level class rule is available for this element');
  return candidates;
}
function encodeMarker(data) { return Buffer.from(JSON.stringify(data)).toString('base64url'); }
function decodeMarker(id) {
  try { const data = JSON.parse(Buffer.from(id, 'base64url').toString('utf8')); if (typeof data.file !== 'string' || !Number.isInteger(data.index) || data.index < 0 || !/^[a-f0-9]{64}$/.test(data.hash) || typeof data.project !== 'string') throw 0; return data; }
  catch { fail('MAPPING', 'Missing or invalid development source mapping'); }
}
function instrument(text, filename, root, project) {
  root = fs.realpathSync(root); const relative = path.relative(root, filename).split(path.sep).join('/');
  if (!inside(root, filename) || /(?:^|\/)(?:node_modules|\.next|\.git)\//.test(relative) || !/\.[jt]sx?$/.test(filename)) return text;
  const info = moduleInfo(text, filename), edits = [], digest = hash(text);
  sourceElements(info.ast).forEach((node, index) => {
    const name = jsxName(node.openingElement.name);
    let mapped = /^[a-z]/.test(name);
    if (!mapped && !name.includes('.')) { try { mapped = !!styledOwner(root, filename, info, name); } catch { mapped = true; } }
    if (!mapped || node.openingElement.attributes.some(a => a.name?.name === 'data-lle-source')) return;
    const meaningful = node.children.filter(child => child.type !== 'JSXText' || child.value.trim());
    const textLiteral = !node.openingElement.selfClosing && meaningful.length <= 1 && meaningful.every(child => child.type === 'JSXText' || (child.type === 'JSXExpressionContainer' && child.expression.type === 'StringLiteral'));
    const marker = encodeMarker({ file: relative, index, hash: digest, project, text: textLiteral });
    edits.push({ start: node.openingElement.name.end, end: node.openingElement.name.end, text: ' data-lle-source="' + marker + '"' });
  });
  return patch(text, edits);
}
function patch(text, edits) {
  const unique = [...new Map(edits.map(e => [e.start + ':' + e.end, e])).values()].sort((a, b) => b.start - a.start);
  let limit = text.length + 1;
  for (const edit of unique) { if (edit.end > limit) fail('OVERLAP', 'Overlapping source edits need manual resolution'); text = text.slice(0, edit.start) + edit.text + text.slice(edit.end); limit = edit.start; }
  return text;
}
function staticValue(node) { if (['StringLiteral', 'NumericLiteral', 'BooleanLiteral'].includes(node?.type)) return true; return node?.type === 'UnaryExpression' && ['+', '-'].includes(node.operator) && node.argument.type === 'NumericLiteral'; }
function cssValue(prop, value) {
  if (!/^(?:--[a-zA-Z0-9_-]+|[a-z][a-z-]*)$/.test(prop) || typeof value !== 'string' || !value || value.length > 2000 || /[;{}<>\x00-\x1f]|!important|url\s*\(|expression\s*\(/i.test(value)) fail('VALUE', 'Invalid CSS source change');
  return value;
}
const jsProp = p => p.startsWith('--') ? p : p.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
function makePlan(root, project, changes, options = {}) {
  root = fs.realpathSync(root);
  if (!Array.isArray(changes) || changes.length < 1 || changes.length > 100) fail('CHANGES', 'Apply requires 1–100 mapped changes');
  const files = new Map(), edits = new Map(), notices = [], seen = new Set();
  function load(file) { if (!files.has(file)) { const text = read(root, path.relative(root, file)).text; if (options.baseline && options.baseline[path.relative(root, file).split(path.sep).join('/')] !== hash(text)) fail('CONFLICT', 'A source file changed on disk since this editing session started: ' + path.relative(root, file)); files.set(file, text); } return files.get(file); }
  function add(file, edit) { const list = edits.get(file) || []; if (list.some(e => e.start === edit.start && e.end === edit.end && e.start !== e.end && e.text !== edit.text)) fail('AMBIGUOUS', 'Two selected instances request different changes to the same source declaration'); list.push(edit); edits.set(file, list); }
  for (const change of changes) {
    const marker = decodeMarker(change.source);
    const identity = marker.file + ':' + (marker.kind || 'jsx') + ':' + marker.index;
    if (seen.has(identity)) fail('AMBIGUOUS', 'Multiple preview elements target the same source element. Apply one instance at a time.');
    seen.add(identity);
    if (marker.project !== project) fail('PROJECT', 'Element belongs to a different project');
    const { file } = read(root, marker.file), text = load(file);
    if (hash(text) !== marker.hash) fail('CONFLICT', 'Source changed since this page was compiled. Refresh the page before editing again: ' + marker.file);
    if (marker.kind === 'markup') {
      require('./discovery.cjs').editMarkup(text, marker, change, { add: edit => add(file, edit), cssValue });
      continue;
    }
    if (change.textRuns !== undefined) fail('TEXT_SEGMENTS', 'Text-segment source saving currently requires static HTML; keep this edit as preview for this framework.');
    const info = moduleInfo(text, file), node = sourceElements(info.ast)[marker.index];
    if (!node) fail('MAPPING', 'Mapped JSX element no longer exists');
    if (change.instances > 1 && !options.allowShared) fail('SHARED', 'Multiple elements use this source declaration. Enable shared edits deliberately, or edit an instance-specific source instead.');
    if (change.detached || change.html !== undefined) fail('STRUCTURE', 'Detaching/HTML replacement remains preview-only in the first source adapter. No files were written.');
    const attributes = node.openingElement.attributes;
    if (attributes.some(a => a.type === 'JSXSpreadAttribute')) fail('DYNAMIC_PROPS', 'A props spread may override this element. Source changes require manual resolution.');
    if (change.text !== undefined) {
      if (attributes.some(a => a.name?.name === 'dangerouslySetInnerHTML')) fail('DYNAMIC_TEXT', 'HTML is generated by an expression; edit its data source.');
      if (typeof change.text !== 'string' || change.text.length > 100000) fail('TEXT', 'Invalid text');
      const meaningful = node.children.filter(n => n.type !== 'JSXText' || n.value.trim());
      if (node.openingElement.selfClosing || meaningful.some(n => n.type !== 'JSXText' && !(n.type === 'JSXExpressionContainer' && n.expression.type === 'StringLiteral')) || meaningful.length > 1) fail('DYNAMIC_TEXT', 'Only a single literal text child can be source-edited. Dynamic/database content is preview-only.');
      add(file, { start: node.openingElement.end, end: node.closingElement.start, text: '{' + JSON.stringify(change.text) + '}' });
    }
    for (const [key, value] of Object.entries(change.attrs || {})) {
      if (!['src', 'alt', 'href', 'title', 'placeholder', 'value', 'aria-label', 'poster', 'srcset'].includes(key) || typeof value !== 'string' || value.length > 1400000) fail('ATTRIBUTE', 'Unsupported source attribute');
      if (['src', 'href', 'poster'].includes(key) && !/^data:image\/(png|jpeg|gif|webp|avif);base64,[a-z0-9+/=]+$/i.test(value) && !['http:', 'https:', ...(key === 'href' ? ['mailto:', 'tel:'] : [])].includes(new URL(value, 'http://localhost').protocol)) fail('URL', 'Unsafe URL');
      const name = key === 'srcset' ? 'srcSet' : key;
      const existing = attributes.find(a => a.name?.name === name);
      if (existing && existing.value?.type !== 'StringLiteral' && !(existing.value?.type === 'JSXExpressionContainer' && staticValue(existing.value.expression))) fail('DYNAMIC_ATTRIBUTE', 'Attribute is an expression/import. No source write was attempted: ' + name);
      const replacement = name + '={' + JSON.stringify(value) + '}';
      if (existing) add(file, { start: existing.start, end: existing.end, text: replacement });
      else add(file, { start: node.openingElement.name.end, end: node.openingElement.name.end, text: ' ' + replacement + ' ' });
    }
    const styles = change.styles || {};
    if (!Object.keys(styles).length) continue;
    const styleAttr = attributes.find(a => a.name?.name === 'style');
    if (styleAttr) {
      const object = styleAttr.value?.expression;
      if (object?.type !== 'ObjectExpression' || object.properties.some(p => p.type !== 'ObjectProperty' || p.computed)) fail('DYNAMIC_STYLE', 'Inline style uses an expression or spread');
      const next = [];
      for (const prop of object.properties) {
        const name = prop.key.name || prop.key.value, css = name.startsWith('--') ? name : name.replace(/[A-Z]/g, c => '-' + c.toLowerCase());
        if (Object.hasOwn(styles, css)) { if (!staticValue(prop.value)) fail('DYNAMIC_STYLE', 'Style value is dynamic: ' + css); next.push(JSON.stringify(name) + ': ' + JSON.stringify(cssValue(css, styles[css]))); }
        else next.push(text.slice(prop.start, prop.end));
      }
      for (const [prop, value] of Object.entries(styles)) if (!object.properties.some(p => (p.key.name || p.key.value) === jsProp(prop))) next.push(JSON.stringify(jsProp(prop)) + ': ' + JSON.stringify(cssValue(prop, value)));
      add(file, { start: object.start, end: object.end, text: '{ ' + next.join(', ') + ' }' });
      continue;
    }
    let owner = null;
    const name = jsxName(node.openingElement.name);
    if (!/^[a-z]/.test(name)) owner = styledOwner(root, file, info, name, 0, marker.elementStyles === true);
    const styledInline = !!owner?.tag && marker.elementStyles === true;
    if (styledInline) owner = null;
    if (owner) {
      if (!options.allowShared) fail('SHARED', 'This styled-component declaration can affect every instance. Enable shared style edits before applying.');
      const source = load(owner.file), template = owner.template;
      const start = template.start + 1, body = source.slice(start, template.end - 1), css = postcss.parse(body);
      const topDeclarations = css.nodes.filter(n => n.type === 'decl');
      const additions = [];
      for (const [prop, value] of Object.entries(styles)) {
        cssValue(prop, value);
        const found = topDeclarations.filter(d => d.prop === prop);
        if (found.length > 1) fail('CASCADE', 'Multiple top-level declarations for ' + prop);
        if (found.length) {
          const decl = found[0]; if (/var\s*\(/.test(decl.value) && !options.allowTokenOverride) fail('TOKEN', 'This declaration uses a design token. Enable token-use replacement or edit the token manually.');
          const from = decl.source.start.offset, end = decl.source.end.offset + 1;
          add(owner.file, { start: start + from, end: start + end, text: prop + ': ' + value + (decl.important ? ' !important' : '') + ';' });
        } else additions.push('  ' + prop + ': ' + value + ';');
      }
      if (additions.length) add(owner.file, { start: template.end - 1, end: template.end - 1, text: '\n' + additions.join('\n') + '\n' });
      notices.push('Shared styled component: ' + path.relative(root, owner.file));
    } else if (!marker.elementStyles && attributes.some(a => a.name?.name === 'className')) {
      const owners = cssOwners(root, file, info, node);
      if (!options.allowShared) fail('SHARED', 'CSS class declarations are shared. Enable shared style edits to apply them.');
      for (const [prop, value] of Object.entries(styles)) {
        cssValue(prop, value);
        const declarations = owners.flatMap(owner => owner.rule.nodes.filter(n => n.type === 'decl' && n.prop === prop).map(decl => ({ ...owner, decl })));
        if (declarations.length > 1) fail('CASCADE', 'More than one class declaration can control ' + prop);
        if (declarations.length === 1) {
          const { file: cssFile, decl } = declarations[0]; load(cssFile);
          if (/var\s*\(/.test(decl.value) && !options.allowTokenOverride) fail('TOKEN', 'CSS uses a design token. Enable replacing the token usage deliberately.');
          add(cssFile, { start: decl.source.start.offset, end: decl.source.end.offset + 1, text: prop + ': ' + value + (decl.important ? ' !important' : '') + ';' });
        } else {
          if (owners.length !== 1) fail('CASCADE', 'Cannot choose which class should own a new declaration');
          const owner = owners[0]; load(owner.file);
          add(owner.file, { start: owner.rule.source.end.offset, end: owner.rule.source.end.offset, text: '\n  ' + prop + ': ' + value + ';\n' });
        }
      }
      notices.push('Shared CSS class declaration');
    } else {
      // A source inline style is the native React representation, not a runtime override file.
      if (!/^[a-z]/.test(name) && !styledInline) fail('COMPONENT', 'Cannot determine how this custom component forwards style props');
      const value = Object.entries(styles).map(([prop, val]) => JSON.stringify(jsProp(prop)) + ': ' + JSON.stringify(cssValue(prop, val))).join(', ');
      add(file, { start: node.openingElement.name.end, end: node.openingElement.name.end, text: ' style={{ ' + value + ' }} ' });
      notices.push('Native JSX style attribute: ' + marker.file);
    }
  }
  const output = [];
  for (const [file, list] of edits) {
    // Merge different zero-width insertions at the same location; reject conflicting replacements.
    const merged = new Map();
    for (const e of list) { const key = e.start + ':' + e.end; if (!merged.has(key)) merged.set(key, { ...e }); else if (merged.get(key).text !== e.text) { if (e.start === e.end) merged.get(key).text += e.text; else fail('AMBIGUOUS', 'Conflicting edits to one source range'); } }
    const before = files.get(file), after = patch(before, [...merged.values()]);
    if (/\.css$/.test(file)) postcss.parse(after); else if (/\.(?:html?|vue|svelte|astro)$/.test(file)) require('./discovery.cjs').elements(after, file); else parse(after, file);
    if (before !== after) output.push({ file: path.relative(root, file).split(path.sep).join('/'), beforeHash: hash(before), afterHash: hash(after), before, after });
  }
  if (!output.length) fail('EMPTY', 'No source changes to apply');
  if (Buffer.byteLength(JSON.stringify(output)) > 700000) fail('SIZE', 'Source transaction is too large');
  return { version: 1, project, createdAt: Date.now(), files: output, notices: [...new Set(notices)] };
}
module.exports = { hash, parse, walk, sourceElements, instrument, decodeMarker, makePlan, checkedFile, inside, patch, moduleInfo, styledOwner, jsxName };
