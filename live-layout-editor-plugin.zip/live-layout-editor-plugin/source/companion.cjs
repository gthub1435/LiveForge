#!/usr/bin/env node
'use strict';
const fs = require('node:fs'), path = require('node:path'), os = require('node:os'), cp = require('node:child_process');
const store = require('./store.cjs');
function register(id) {
  if (!/^[a-p]{32}$/.test(id || '')) throw new Error('Copy the 32-letter extension ID from chrome://extensions');
  const dir = store.stateDir(); fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const hostScript = path.join(__dirname, 'native-host.cjs'), windows = process.platform === 'win32';
  const launcher = path.join(dir, windows ? 'native-host.cmd' : 'native-host');
  if (windows) fs.writeFileSync(launcher, '@echo off\r\n"' + process.execPath + '" "' + hostScript + '" %*\r\n');
  else { const quote = s => "'" + s.replace(/'/g, "'\\''") + "'"; fs.writeFileSync(launcher, '#!/bin/sh\nexec ' + quote(process.execPath) + ' ' + quote(hostScript) + ' "$@"\n', { mode: 0o700 }); }
  const manifest = { name: 'app.livelayout.companion', description: 'Live Layout Editor local source companion', path: launcher, type: 'stdio', allowed_origins: ['chrome-extension://' + id + '/'] };
  const file = path.join(dir, 'native-host.json'); fs.writeFileSync(file, JSON.stringify(manifest, null, 2));
  if (windows) cp.execFileSync('reg.exe', ['ADD', 'HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\app.livelayout.companion', '/ve', '/t', 'REG_SZ', '/d', file, '/f'], { stdio: 'pipe' });
  else {
    const destination = process.platform === 'darwin' ? path.join(os.homedir(), 'Library/Application Support/Google/Chrome/NativeMessagingHosts') : path.join(os.homedir(), '.config/google-chrome/NativeMessagingHosts');
    fs.mkdirSync(destination, { recursive: true }); fs.copyFileSync(file, path.join(destination, manifest.name + '.json'));
  }
  return { registered: true, extension: id, manifest: file };
}
if (require.main === module) try {
  const [command, ...args] = process.argv.slice(2), option = name => args[args.indexOf(name) + 1];
  if (command === 'connect') { if (!args.includes('--root') || !args.includes('--origin')) throw new Error('--root and --origin are required'); console.log(JSON.stringify(store.connect(option('--root'), option('--origin')), null, 2)); }
  else if (command === 'register') console.log(JSON.stringify(register(option('--extension-id')), null, 2));
  else if (command === 'list') console.log(JSON.stringify(store.config().projects, null, 2));
  else if (command === 'restore') console.log(JSON.stringify(store.restore(option('--transaction'), option('--origin')), null, 2));
  else console.log('Commands:\n  connect --root PROJECT --origin http://localhost:3000\n  register --extension-id ID\n  list\n  restore --transaction ID --origin http://localhost:3000');
} catch (e) { console.error(e.message); process.exitCode = 1; }
module.exports = { register };
