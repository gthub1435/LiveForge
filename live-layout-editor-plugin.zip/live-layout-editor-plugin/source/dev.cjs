#!/usr/bin/env node
'use strict';
const fs = require('node:fs'), cp = require('node:child_process');
try {
  const args = process.argv.slice(2), at = args.indexOf('--root');
  if (at < 0 || !args[at + 1]) throw new Error('Usage: node source/dev.cjs --root PROJECT [--port 3000]');
  const root = fs.realpathSync(args[at + 1]), port = args.includes('--port') ? args[args.indexOf('--port') + 1] : '3000';
  const next = require.resolve('next/dist/bin/next', { paths: [root] });
  const child = cp.spawn(process.execPath, [next, 'dev', '--port', port], { cwd: root, env: { ...process.env, LIVE_LAYOUT_EDITOR: '1', NODE_ENV: 'development' }, stdio: 'inherit' });
  child.on('exit', code => { process.exitCode = code || 0; });
} catch (e) { console.error(e.message); process.exitCode = 1; }
