"use strict";
const { spawnSync } = require('node:child_process');
function chooseFolder({ platform = process.platform, run = spawnSync } = {}) {
  if (platform !== 'win32') throw new Error('Folder browsing currently requires Windows. Enter the project path manually instead.');
  const script = `Add-Type -AssemblyName System.Windows.Forms
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Choose the project folder serving your localhost page'
$dialog.ShowNewFolderButton = $false
try {
  if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
    @{ root = $dialog.SelectedPath; cancelled = $false } | ConvertTo-Json -Compress
  } else { @{ cancelled = $true } | ConvertTo-Json -Compress }
} finally { $dialog.Dispose() }`;
  const result = run('powershell.exe', ['-NoProfile', '-STA', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], { encoding: 'utf8', windowsHide: true, timeout: 300000, maxBuffer: 65536 });
  if (result.error || result.status !== 0) throw new Error('Could not open the folder browser. Try again or enter the path manually.');
  let value;
  try { value = JSON.parse(result.stdout.replace(/^\uFEFF/, '').trim()); } catch { throw new Error('Folder browser returned an invalid response.'); }
  if (value.cancelled === true) return { cancelled: true };
  if (typeof value.root !== 'string' || !value.root.trim()) throw new Error('No project folder was selected.');
  return { cancelled: false, root: value.root };
}
module.exports = { chooseFolder };
