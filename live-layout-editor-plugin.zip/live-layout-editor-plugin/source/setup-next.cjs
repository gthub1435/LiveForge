#!/usr/bin/env node
'use strict';
const fs = require('node:fs'), path = require('node:path'), { parse } = require('./engine.cjs');
const rootArg = process.argv.indexOf('--root');
try {
  if (rootArg < 0 || !process.argv[rootArg + 1]) throw new Error('Usage: node source/setup-next.cjs --root PROJECT');
  const root = fs.realpathSync(process.argv[rootArg + 1]);
  const file = path.join(root, 'next.config.mjs');
  if (!fs.existsSync(file)) throw new Error('Automatic setup currently supports next.config.mjs. Use SOURCE-HOW-TO-USE.txt for other config formats.');
  const before = fs.readFileSync(file, 'utf8');
  if (before.includes('LLE_SOURCE_ADAPTER_BEGIN')) { console.log('Source adapter is already configured.'); process.exit(0); }
  const ast = parse(before, file), exp = ast.program.body.find(n => n.type === 'ExportDefaultDeclaration');
  if (!exp || !['Identifier', 'ObjectExpression'].includes(exp.declaration.type)) throw new Error('Config default export is composed/dynamic. Integrate withLiveLayout manually.');
  const adapter = path.relative(root, path.join(__dirname, 'next-adapter.cjs')).split(path.sep).join('/');
  const spec = adapter.startsWith('.') ? adapter : './' + adapter;
  const header = '// LLE_SOURCE_ADAPTER_BEGIN — development opt-in only\nimport { createRequire as __lleCreateRequire } from "node:module";\nconst __lleRequire = __lleCreateRequire(import.meta.url);\n// LLE_SOURCE_ADAPTER_END\n';
  const expression = before.slice(exp.declaration.start, exp.declaration.end);
  const replacement = 'export default process.env.LIVE_LAYOUT_EDITOR === "1"\n  ? __lleRequire(' + JSON.stringify(spec) + ').withLiveLayout(' + expression + ', { root: ' + JSON.stringify(root) + ' })\n  : ' + expression + ';';
  const after = header + before.slice(0, exp.start) + replacement + before.slice(exp.end); parse(after, file);
  const backup = path.join(root, 'next.config.mjs.before-live-layout');
  if (fs.existsSync(backup)) throw new Error('Backup already exists. Inspect it before setup.');
  const packageFile = path.join(root, 'package.json'), packageBefore = fs.readFileSync(packageFile, 'utf8'), pkg = JSON.parse(packageBefore);
  pkg.scripts ||= {};
  if (pkg.scripts['dev:visual']) throw new Error('dev:visual script already exists; integrate the adapter manually.');
  const runner = path.relative(root, path.join(__dirname, 'dev.cjs')).split(path.sep).join('/');
  pkg.scripts['dev:visual'] = 'node ' + JSON.stringify(runner) + ' --root .';
  const packageBackup = path.join(root, 'package.json.before-live-layout');
  if (fs.existsSync(packageBackup)) throw new Error('Package backup already exists. Inspect it before setup.');
  fs.writeFileSync(backup, before, { flag: 'wx' }); fs.writeFileSync(packageBackup, packageBefore, { flag: 'wx' });
  fs.writeFileSync(file, after); fs.writeFileSync(packageFile, JSON.stringify(pkg, null, 2) + '\n');
  console.log('Configured development adapter. Original config saved to ' + backup + '\nUse source/dev.cjs to start with LIVE_LAYOUT_EDITOR=1. Production remains unchanged.');
} catch (e) { console.error(e.message); process.exitCode = 1; }
