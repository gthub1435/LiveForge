'use strict';
// Compiler markers provide source provenance. Uninstrumented elements may
// resolve from a unique strong literal signature; ambiguous matches block Apply.
const fs = require('node:fs'), path = require('node:path');
const html = require('parse5'), postcss = require('postcss');
const engine = require('./engine.cjs');
const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();
const literal = value => typeof value === 'string' && !/[{}]|<%|\{%|\$\{/.test(value);
const escapeText = value => value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escapeAttr = value => escapeText(value).replace(/"/g, '&quot;').replace(/\{/g, '&#123;').replace(/\}/g, '&#125;');
function mask(text, file) {
  // Preserve original offsets. Do not parse script/style/frontmatter as markup.
  const blank = value => value.replace(/[^\r\n]/g, ' ');
  let input = text.replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, blank);
  if (/\.astro$/.test(file)) input = input.replace(/^---[^\n]*\n[\s\S]*?\n---[^\n]*(?:\n|$)/, blank);
  return input;
}
function elements(text, file, root) {
  const out = [], markup = /\.(?:html?|vue|svelte|astro)$/.test(file);
  if (markup) {
    const document = html.parse(mask(text, file), { sourceCodeLocationInfo: true });
    function visit(node) {
      const loc = node.sourceCodeLocation;
      if (loc?.startTag && node.tagName && !['script', 'style', 'template', 'head', 'meta', 'link', 'title'].includes(node.tagName)) {
        const actualName = /^<([^\s/>]+)/.exec(text.slice(loc.startTag.startOffset, loc.startTag.endOffset))?.[1];
        if (actualName && actualName === actualName.toLowerCase()) {
          const attrs = Object.fromEntries((node.attrs || []).map(a => [a.name, a.value]));
          const raw = loc.endTag ? text.slice(loc.startTag.endOffset, loc.endTag.startOffset) : '';
          const childElements = (node.childNodes || []).some(n => n.tagName);
          const staticText = !!loc.endTag && !childElements && literal(raw) && !/[<>]/.test(raw) && !('v-text' in attrs) && !('v-html' in attrs) && !('set:html' in attrs);
          const nodeText = (node.childNodes || []).filter(n => n.nodeName === '#text').map(n => n.value).join('');
          const directTextNodes = (node.childNodes || []).filter(n => n.nodeName === '#text');
          const signatureText = /\.html?$/.test(file) && directTextNodes.every(n => literal(n.value)) ? normalize(nodeText) : null;
          out.push({ directTextNodes, signatureText, tag: actualName, attrs, text: staticText ? normalize(nodeText) : null, textEditable: staticText, loc, kind: 'markup' });
        }
      }
      for (const child of node.childNodes || []) visit(child);
      if (node.content) visit(node.content);
    }
    visit(document);
  } else {
    const info = engine.moduleInfo(text, file);
    engine.sourceElements(info.ast).forEach((node, index) => {
      const opening = node.openingElement, name = opening.name;
      if (name.type !== 'JSXIdentifier') return;
      let tag = name.name, ownerFile = null;
      if (!/^[a-z]/.test(tag)) { try { const owner = root && engine.styledOwner(root, file, info, tag, 0, true); tag = owner?.tag; ownerFile = owner?.file; } catch { tag = null; } }
      if (!tag || !/^[a-z]/.test(tag)) return;
      const attrs = {};
      for (const a of opening.attributes) if (a.type === 'JSXAttribute') {
        const name = a.name.name === 'className' ? 'class' : a.name.name;
        if (a.value?.type === 'StringLiteral') attrs[name] = a.value.value;
        else if (a.value?.type === 'JSXExpressionContainer' && a.value.expression.type === 'StringLiteral') attrs[name] = a.value.expression.value;
      }
      const children = node.children.filter(n => n.type !== 'JSXText' || n.value.trim());
      const staticText = !opening.selfClosing && children.length <= 1 && children.every(n => n.type === 'JSXText' || (n.type === 'JSXExpressionContainer' && n.expression.type === 'StringLiteral'));
      const value = staticText ? children.map(n => n.type === 'JSXText' ? n.value : n.expression.value).join('') : null;
      out.push({ tag, ownerFile, attrs, text: staticText ? normalize(value) : null, textEditable: staticText, index, kind: 'jsx', loc: { startTag: { startOffset: opening.start, endOffset: opening.end } } });
    });
  }
  return out;
}
function resolve(project, session, descriptor, filter = '') {
  if (!descriptor || typeof descriptor.tag !== 'string' || !/^[a-z][\w:-]*$/i.test(descriptor.tag) || JSON.stringify(descriptor).length > 20000 || typeof filter !== 'string' || filter.length > 200) throw new Error('Invalid element description');
  const candidates = []; let skipped = 0;
  for (const relative of Object.keys(session.baseline)) {
    if (!/\.(?:jsx?|tsx?|html?|vue|svelte|astro)$/.test(relative) || (filter && !relative.toLowerCase().includes(filter.toLowerCase()))) continue;
    const file = engine.checkedFile(project.root, relative), text = fs.readFileSync(file, 'utf8');
    if (engine.hash(text) !== session.baseline[relative]) { skipped++; continue; }
    let nodes; try { nodes = elements(text, file, project.root); } catch { skipped++; continue; }
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i]; if (node.tag !== descriptor.tag) continue;
      if (node.ownerFile && session.baseline[path.relative(project.root, node.ownerFile).split(path.sep).join('/')] !== engine.hash(fs.readFileSync(node.ownerFile))) continue;
      const attrs = descriptor.attrs || {}; let score = 1;
      if (attrs.id && node.attrs.id) { if (attrs.id !== node.attrs.id) continue; score += 100; }
      for (const key of ['data-testid', 'data-lle-id', 'name', 'src', 'href', 'alt', 'placeholder', 'aria-label']) if (attrs[key] && node.attrs[key] === attrs[key]) score += 25;
      const candidateText = node.text ?? node.signatureText;
      if (descriptor.text && candidateText != null && candidateText !== normalize(descriptor.text)) continue;
      if (descriptor.text && candidateText === normalize(descriptor.text)) score += 60;
      if (attrs.class && node.attrs.class && normalize(attrs.class) === normalize(node.attrs.class)) score += 15;
      const offset = node.loc.startTag.startOffset;
      const marker = { file: relative, index: node.kind === 'jsx' ? node.index : i, hash: session.baseline[relative], project: project.id, text: node.textEditable, kind: node.kind, elementStyles: true };
      candidates.push({ source: Buffer.from(JSON.stringify(marker)).toString('base64url'), file: relative, line: text.slice(0, offset).split('\n').length, snippet: text.slice(offset, Math.min(text.length, offset + 350)), score, text: node.textEditable });
    }
  }
  candidates.sort((a, b) => b.score - a.score || a.file.localeCompare(b.file) || a.line - b.line);
  const best = candidates[0], runner = candidates[1];
  const automatic = best && best.score >= 60 && (!runner || best.score > runner.score) ? best.source : null;
  return { automatic, match: automatic ? { file: best.file, line: best.line, method: 'unique-literal-signature' } : null, candidates: candidates.slice(0, 30), total: candidates.length, skipped, notice: 'Unique literal matches are inferred, not compiler provenance. Ambiguous matches block Apply. Repeated components may affect multiple instances.' };
}
function editMarkup(text, marker, change, { add, cssValue }) {
  const node = elements(text, marker.file)[marker.index];
  if (!node) throw new Error('Mapped markup element no longer exists');
  if (change.detached || change.html !== undefined) throw new Error('Structural edits cannot be applied to original templates safely; keep this change as preview or edit the structure in your editor.');
  const attrs = node.attrs, loc = node.loc, replacements = new Map(), additions = [];
  const dynamic = key => Object.keys(attrs).some(a => a.includes('{...') || a.startsWith('v-bind:[') || a.startsWith(':[') || a === 'x-model' || a === ':' + key || a === 'v-bind:' + key || a === '[' + key + ']' || a === 'bind:' + key || a.startsWith('style:') || a === 'v-bind' || a === 'x-bind:' + key || a === 'v-text' || a === 'v-html') || Object.values(attrs).some(v => /\{\.\.\./.test(v));
  function setAttr(key, value) {
    if (dynamic(key) || (attrs[key] !== undefined && !literal(attrs[key]))) throw new Error('Dynamic attribute needs its framework/data adapter: ' + key);
    const valueText = key + '="' + escapeAttr(value) + '"', range = loc.attrs?.[key];
    if (range) replacements.set(key, { start: range.startOffset, end: range.endOffset, text: valueText });
    else additions.push(' ' + valueText);
  }
  if (change.textRuns !== undefined) {
    if (!/\.html?$/.test(marker.file) || change.text !== undefined || !Array.isArray(change.textRuns) || change.textRuns.length > 100 || dynamic('text')) throw new Error('Text-segment source saving currently requires static HTML. Dynamic/template content needs its adapter.');
    const used = new Set();
    for (const run of change.textRuns) {
      const target = node.directTextNodes[run.index], range = target?.sourceCodeLocation;
      if (!Number.isInteger(run.index) || run.index < 0 || used.has(run.index) || !range || typeof run.before !== 'string' || typeof run.after !== 'string' || run.after.length > 100000 || target.value !== run.before || !literal(run.before)) throw new Error('Text segment no longer matches its original static HTML. No files changed.');
      used.add(run.index); add({ start: range.startOffset, end: range.endOffset, text: escapeText(run.after).replace(/\{/g,'&#123;').replace(/\}/g,'&#125;') });
    }
  }
  if (change.text !== undefined) {
    if (!node.textEditable || typeof change.text !== 'string' || change.text.length > 100000) throw new Error('Only literal text can be saved here. Dynamic content requires its data source.');
    if (node.tag === 'textarea' && change.attrs?.value !== undefined) throw new Error('Conflicting textarea edits');
    if (node.tag === 'textarea' || !['script', 'style'].includes(node.tag)) add({ start: loc.startTag.endOffset, end: loc.endTag.startOffset, text: escapeText(change.text).replace(/\{/g, '&#123;').replace(/\}/g, '&#125;') });
  }
  for (const [key, value] of Object.entries(change.attrs || {})) {
    if (!['src', 'alt', 'href', 'title', 'placeholder', 'value', 'aria-label', 'poster', 'srcset'].includes(key) || typeof value !== 'string' || value.length > 100000) throw new Error('Unsupported attribute');
    if (['src', 'href', 'poster'].includes(key) && !/^data:image\/(png|jpeg|gif|webp|avif);base64,[a-z0-9+/=]+$/i.test(value) && !['http:', 'https:', ...(key === 'href' ? ['mailto:', 'tel:'] : [])].includes(new URL(value, 'http://localhost').protocol)) throw new Error('Unsafe URL');
    if (key === 'value' && node.tag === 'textarea') { if (!node.textEditable || dynamic(key)) throw new Error('Dynamic textarea'); add({ start: loc.startTag.endOffset, end: loc.endTag.startOffset, text: escapeText(value).replace(/\{/g, '&#123;').replace(/\}/g, '&#125;') }); }
    else setAttr(key, value);
  }
  if (Object.keys(change.styles || {}).length) {
    if (dynamic('style')) throw new Error('Dynamic styles need their framework adapter');
    const css = postcss.parse('x{' + (attrs.style || '') + '}');
    const rule = css.first;
    if (!rule || css.nodes.length !== 1 || rule.nodes.some(n => !['decl', 'comment'].includes(n.type))) throw new Error('Unsupported inline style');
    for (const [key, value] of Object.entries(change.styles)) {
      cssValue(key, value);
      const existing = rule.nodes.filter(n => n.type === 'decl' && n.prop === key);
      existing.forEach(n => n.remove());
      rule.append({ prop: key, value, important: true });
    }
    setAttr('style', rule.nodes.map(n => n.toString().replace(/;$/, '') + ';').join(' '));
  }
  for (const replacement of replacements.values()) add(replacement);
  if (additions.length) {
    const sourceTag = text.slice(loc.startTag.startOffset, loc.startTag.endOffset), closing = /\/\s*>$/.test(sourceTag) ? sourceTag.lastIndexOf('/') : sourceTag.length - 1;
    add({ start: loc.startTag.startOffset + closing, end: loc.startTag.startOffset + closing, text: additions.join('') });
  }
}
module.exports = { elements, resolve, editMarkup };
