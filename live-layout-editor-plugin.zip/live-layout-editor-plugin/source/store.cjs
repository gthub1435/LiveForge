'use strict';
const fs = require('node:fs'), path = require('node:path'), os = require('node:os'), crypto = require('node:crypto');
const { hash, makePlan, checkedFile } = require('./engine.cjs');
const stateDir = () => process.env.LLE_STATE_DIR || path.join(os.homedir(), '.live-layout-editor');
function ensure() { fs.mkdirSync(stateDir(), { recursive: true, mode: 0o700 }); }
function atomic(file, value) { const temp = file + '.' + crypto.randomBytes(8).toString('hex') + '.tmp'; fs.writeFileSync(temp, JSON.stringify(value, null, 2), { mode: 0o600, flag: 'wx' }); fs.renameSync(temp, file); }
function config() { ensure(); const file = path.join(stateDir(), 'projects.json'); return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : { projects: [] }; }
function localOrigin(value) { const u = new URL(value); if (!['http:', 'https:'].includes(u.protocol) || !['localhost', '127.0.0.1', '[::1]'].includes(u.hostname) || value !== u.origin) throw new Error('An exact localhost origin is required'); return value; }
function connect(root, origin) {
  if (typeof root !== 'string' || !path.isAbsolute(root)) throw new Error('Choose an absolute project folder path');
  root = fs.realpathSync(root); if (!fs.statSync(root).isDirectory()) throw new Error('Project path must be a folder'); localOrigin(origin); const cfg = config();
  const id = hash(root).slice(0, 20); cfg.projects = cfg.projects.filter(p => p.id !== id && p.origin !== origin);
  cfg.projects.push({ id, root, origin, name: path.basename(root) }); atomic(path.join(stateDir(), 'projects.json'), cfg); return cfg.projects.at(-1);
}
function projectFor(origin, id) { localOrigin(origin); const project = config().projects.find(p => p.origin === origin && (!id || p.id === id)); if (!project) throw new Error('This localhost address is not connected to a project. Use the companion connect command first.'); return project; }
function snapshot(root) {
  const files = {}; let count = 0;
  function visit(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.name.startsWith('.') || ['node_modules', 'dist', 'build', 'coverage', 'live-layout-changes'].includes(entry.name) || entry.isSymbolicLink()) continue;
      const file = path.join(dir, entry.name);
      if (entry.isDirectory()) visit(file);
      else if (/\.(?:jsx?|tsx?|css|html?|vue|svelte|astro)$/.test(file) && fs.statSync(file).size <= 500000) { if (++count > 5000) throw new Error('Project has too many source files'); files[path.relative(root, file).split(path.sep).join('/')] = hash(fs.readFileSync(file)); }
    }
  }
  visit(root); return files;
}
function sessionFile(id) { if (!/^[a-f0-9]{40}$/.test(id || '')) throw new Error('Invalid session'); return path.join(stateDir(), 'session-' + id + '.json'); }
function openSession(origin) {
  const project = projectFor(origin), id = crypto.randomBytes(20).toString('hex');
  const session = { id, project: project.id, origin, created: Date.now(), baseline: snapshot(project.root) }; atomic(sessionFile(id), session);
  return { session: id, project: project.id, name: project.name, origin };
}
function getSession(id, origin) { const session = JSON.parse(fs.readFileSync(sessionFile(id), 'utf8')); if (session.origin !== origin || Date.now() - session.created > 3600000) throw new Error('Editing session expired. Reopen the extension.'); return session; }
function planFile(id) { if (!/^[a-f0-9]{40}$/.test(id || '')) throw new Error('Invalid plan'); return path.join(stateDir(), 'plan-' + id + '.json'); }
function planChanges(message) {
  const session = getSession(message.session, message.origin), project = projectFor(message.origin, session.project);
  const plan = makePlan(project.root, project.id, message.changes, { baseline: session.baseline, allowShared: message.allowShared === true, allowTokenOverride: message.allowTokenOverride === true });
  const id = crypto.randomBytes(20).toString('hex'); plan.id = id; plan.session = session.id; plan.origin = message.origin;
  atomic(planFile(id), plan);
  return { plan: id, files: plan.files.map(f => ({ file: f.file, beforeHash: f.beforeHash, afterHash: f.afterHash, before: f.before.slice(0, 45000), after: f.after.slice(0, 45000), truncated: f.before.length > 45000 || f.after.length > 45000 })), notices: plan.notices };
}
function applyPlan(message) {
  const session = getSession(message.session, message.origin), project = projectFor(message.origin, session.project);
  const savedPlanFile = planFile(message.plan), plan = JSON.parse(fs.readFileSync(savedPlanFile, 'utf8'));
  if (plan.session !== session.id || plan.project !== project.id || plan.origin !== message.origin || Date.now() - plan.createdAt > 120000) throw new Error('Plan expired or belongs to another session');
  const lock = path.join(stateDir(), 'lock-' + project.id);
  try { fs.mkdirSync(lock); } catch { throw new Error('Another source transaction is running. Retry after it completes.'); }
  const backup = path.join(stateDir(), 'history', Date.now() + '-' + plan.id), written = [];
  try {
    // Check every file before the first write, including changes made after preview.
    for (const f of plan.files) if (hash(fs.readFileSync(checkedFile(project.root, f.file))) !== f.beforeHash) throw new Error('CONFLICT: Source changed after planning: ' + f.file);
    fs.mkdirSync(backup, { recursive: true, mode: 0o700 }); atomic(path.join(backup, 'transaction.json'), { ...plan, status: 'prepared' });
    for (const f of plan.files) {
      const file = checkedFile(project.root, f.file), tmp = file + '.lle-' + crypto.randomBytes(6).toString('hex') + '.tmp';
      fs.writeFileSync(tmp, f.after, { flag: 'wx', mode: fs.statSync(file).mode });
      if (hash(fs.readFileSync(file)) !== f.beforeHash) { fs.unlinkSync(tmp); throw new Error('CONFLICT: File changed during source transaction: ' + f.file); }
      fs.renameSync(tmp, file); written.push(f);
    }
    for (const f of plan.files) session.baseline[f.file] = f.afterHash;
    atomic(sessionFile(session.id), session); atomic(path.join(backup, 'transaction.json'), { ...plan, status: 'applied' }); fs.unlinkSync(savedPlanFile);
    return { applied: true, transaction: path.basename(backup), hashes: Object.fromEntries(plan.files.map(f => [f.file, f.afterHash])), files: plan.files.map(f => f.file) };
  } catch (error) {
    // Preserve concurrent edits; only roll back files that still have our exact output.
    for (const f of written.reverse()) { const file = checkedFile(project.root, f.file); if (hash(fs.readFileSync(file)) === f.afterHash) fs.writeFileSync(file, f.before); }
    throw error;
  } finally { fs.rmdirSync(lock); }
}
function restore(transaction, origin) {
  if (!/^[0-9]+-[a-f0-9]{40}$/.test(transaction)) throw new Error('Invalid transaction');
  const file = path.join(stateDir(), 'history', transaction, 'transaction.json'), plan = JSON.parse(fs.readFileSync(file, 'utf8'));
  const project = projectFor(origin, plan.project);
  if (!['applied', 'prepared'].includes(plan.status)) throw new Error('Transaction is not restorable');
  for (const f of plan.files) { const current = hash(fs.readFileSync(checkedFile(project.root, f.file))); if (current !== f.afterHash && !(plan.status === 'prepared' && current === f.beforeHash)) throw new Error('Cannot restore: a file has newer edits: ' + f.file); }
  for (const f of plan.files) fs.writeFileSync(checkedFile(project.root, f.file), f.before);
  atomic(file, { ...plan, status: 'restored' }); return { restored: true, files: plan.files.map(f => f.file) };
}
function dispatch(message) {
  if (!message || typeof message !== 'object') throw new Error('Invalid message');
  if (message.action === 'choose-folder') { localOrigin(message.origin); return require('./folder-picker.cjs').chooseFolder(); }
  if (message.action === 'connect') return connect(message.root, message.origin);
  if (message.action === 'resolve') { const session = getSession(message.session, message.origin), project = projectFor(message.origin, session.project); return require('./discovery.cjs').resolve(project, session, message.descriptor, message.filter); }
  if (message.action === 'open') return openSession(message.origin);
  if (message.action === 'plan') return planChanges(message);
  if (message.action === 'apply') return applyPlan(message);
  if (message.action === 'ping') return { version: '3.11.0', projects: config().projects.map(({ id, origin, name }) => ({ id, origin, name })) };
  throw new Error('Unsupported companion action');
}
module.exports = { config, connect, stateDir, dispatch, projectFor, snapshot, openSession, planChanges, applyPlan, restore };
