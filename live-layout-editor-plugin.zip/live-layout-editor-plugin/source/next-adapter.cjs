'use strict';
const fs = require('node:fs'), path = require('node:path'), { hash } = require('./engine.cjs');
// Transform development modules only. Original files stay free of mapping attributes.
function withLiveLayout(config = {}, options = {}) {
  if (process.env.NODE_ENV !== 'development') return config;
  const root = fs.realpathSync(options.root || process.cwd()), project = hash(root).slice(0, 20);
  const loader = { loader: require.resolve('./loader.cjs'), options: { root, project, enabled: true } };
  let common = root;
  while (path.relative(common, __dirname).startsWith('..') || path.isAbsolute(path.relative(common, __dirname))) {
    const parent = path.dirname(common);
    if (parent === common) throw new Error('For Turbopack, place the plugin and project on the same drive.');
    common = parent;
  }
  const rules = { ...(config.turbopack?.rules || {}) };
  for (const glob of ['*.tsx', '*.jsx', '*.ts', '*.js']) {
    const rule = { condition: { all: ['development', { not: 'foreign' }] }, loaders: [loader] };
    rules[glob] = rules[glob] ? [rules[glob], rule].flat() : rule;
  }
  const originalWebpack = config.webpack;
  return { ...config, turbopack: { root: common, ...(config.turbopack || {}), rules }, webpack(webpackConfig, context) {
    if (context.dev) webpackConfig.module.rules.push({ test: /\.[jt]sx?$/, exclude: /node_modules/, enforce: 'pre', use: [loader] });
    return originalWebpack ? originalWebpack(webpackConfig, context) : webpackConfig;
  } };
}
module.exports = { withLiveLayout };
