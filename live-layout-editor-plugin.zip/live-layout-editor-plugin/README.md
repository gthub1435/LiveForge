# Live Layout Editor

A Chrome visual editor with a local source companion. Double-click elements to select/edit them, then right-click for the options menu. Advanced controls expand inside the menu. Minimize, maximize or restore the main panel and move the glass panels freely, reorder layers with front/back and one-step controls, preview changes, and use **Apply changes in code** to select and review original-source edits for a connected localhost project.

Start with **[HOW-TO-USE.txt](HOW-TO-USE.txt)**. Installation and usage are separate from this README. Windows users can run `INSTALL-COMPANION.cmd` once to install dependencies and register the source companion.

The extension contains no project-specific paths. Use your normal development/static server, connect its folder from the popup, and edit with any code editor. No special npm script is required. Live websites need no companion or source project; their changes remain temporary.

## Source coverage

| Source | Available changes |
| --- | --- |
| HTML/HTM | Literal text, supported attributes, original inline style |
| JSX/TSX | Literal DOM elements, supported attributes, original React inline style |
| Vue/Svelte/Astro | Conservative literal markup subset; scripts and expressions preserved |
| Optional mapped Next adapter | Static styled-components and imported CSS-module declarations |

Portable style edits are element-level source edits. They do not rewrite Tailwind utilities or shared design tokens. Source markers resolve directly; unique strong literal matches can resolve automatically. Ambiguous matches block Apply, and users review before/after code. The live CSS inspector exposes computed properties plus read-only matched-rule and pseudo-element views, with its own window controls. Ambiguous or dynamic changes are never silently substituted with an override file.

This release is **not guaranteed universal source support**. Database content, generated elements, unsupported syntax, structural rewrites, cross-origin frames, closed shadow roots, canvas and browser-protected pages have limits. See **[SOURCE-HOW-TO-USE.txt](SOURCE-HOW-TO-USE.txt)** for exact capabilities, conflicts, recovery and optional mappings.

## Development checks

```sh
npm ci
npm test
npm run test:source
npm run test:discovery
npm run build:extension
```

Browser checks require Playwright and a Chromium installation. `npm run test:portable` runs Native Messaging integration using temporary projects, a temporary Chrome profile and temporary host registration. It restores the host registration afterward. `test/browser.test.cjs` covers the older standalone editor UI. The standalone legacy override workflow is documented separately in `LEGACY-HOW-TO-USE.txt`; it does not perform original-source edits.

Hide now leaves a named Show marker and a Hidden elements list. Restore individual elements without undoing unrelated edits. Saved local-source markers persist across refresh within the same tab when session storage is available.
