'use strict';
const { test } = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const engine = require('../source/engine.cjs'), store = require('../source/store.cjs');
function setup(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'lle-source-')), state = fs.mkdtempSync(path.join(os.tmpdir(), 'lle-state-'));
  process.env.LLE_STATE_DIR = state;
  const page = 'import { Box } from "./styles";\nexport default function Page({name}) { return <Box><h1 style={{ color: "blue", fontSize: 20 }}>Hello</h1><img src="/old.png" alt="Old" /><p>{name}</p><span className="label">Label</span></Box>; }\n';
  const styles = 'import styled from "styled-components";\nexport const Box = styled.div`\n  color: blue;\n  padding: 12px;\n  @media (max-width: 600px) { color: green; }\n`;\n';
  fs.writeFileSync(path.join(root, 'Page.tsx'), page); fs.writeFileSync(path.join(root, 'styles.tsx'), styles);
  const project = store.connect(root, 'http://localhost:3000'), session = store.openSession(project.origin);
  function marker(index) { const instrumented = engine.instrument(fs.readFileSync(path.join(root, 'Page.tsx'), 'utf8'), path.join(root, 'Page.tsx'), root, project.id); return [...instrumented.matchAll(/data-lle-source="([^"]+)"/g)].map(m => m[1]).find(m => engine.decodeMarker(m).index === index); }
  t.after(() => { delete process.env.LLE_STATE_DIR; fs.rmSync(root, { recursive: true, force: true }); fs.rmSync(state, { recursive: true, force: true }); });
  return { root, state, project, session, marker, page, styles, plan: changes => store.planChanges({ origin: project.origin, session: session.session, changes, allowShared: true }), apply: plan => store.applyPlan({ origin: project.origin, session: session.session, plan: plan.plan }) };
}
test('development mappings point to JSX nodes without modifying files', t => {
  const f = setup(t), decoded = engine.decodeMarker(f.marker(1));
  assert.equal(decoded.file, 'Page.tsx'); assert.equal(decoded.index, 1); assert.equal(decoded.hash, engine.hash(f.page));
  assert.equal(fs.readFileSync(path.join(f.root, 'Page.tsx'), 'utf8'), f.page);
});
test('edits literal text, original inline styles and attributes; preserves unrelated code', t => {
  const f = setup(t), plan = f.plan([{ source: f.marker(1), styles: { color: 'red', 'font-size': '24px' }, attrs: {}, text: 'Source edited' }, { source: f.marker(2), styles: { width: '80px' }, attrs: { src: '/new.png', alt: 'New' } }]);
  assert.equal(fs.readFileSync(path.join(f.root, 'Page.tsx'), 'utf8'), f.page); // preview has no writes
  const applied = f.apply(plan); assert.equal(applied.applied, true);
  const actual = fs.readFileSync(path.join(f.root, 'Page.tsx'), 'utf8');
  assert.match(actual, /"color": "red"/); assert.match(actual, /"fontSize": "24px"/); assert.match(actual, /\{"Source edited"\}/); assert.match(actual, /src=\{"\/new.png"\}/);
  assert.match(actual, /<p>\{name\}<\/p>/); assert.equal(fs.existsSync(path.join(f.root, 'live-layout-changes')), false);
  assert.equal(store.restore(applied.transaction, f.project.origin).restored, true); assert.equal(fs.readFileSync(path.join(f.root, 'Page.tsx'), 'utf8'), f.page);
});
test('edits the original styled template and leaves media-query declarations intact', t => {
  const f = setup(t), plan = f.plan([{ source: f.marker(0), styles: { color: 'red', width: '300px' }, attrs: {} }]);
  f.apply(plan); const actual = fs.readFileSync(path.join(f.root, 'styles.tsx'), 'utf8');
  assert.match(actual, /color: red;/); assert.match(actual, /width: 300px;/); assert.match(actual, /@media \(max-width: 600px\) \{ color: green; \}/);
  assert.equal(fs.readFileSync(path.join(f.root, 'Page.tsx'), 'utf8'), f.page);
});
test('rejects dynamic text, shared styles without opt-in, tokens and structural edits', t => {
  const f = setup(t);
  assert.throws(() => f.plan([{ source: f.marker(3), styles: {}, attrs: {}, text: 'Wrong' }]), /literal text/);
  assert.throws(() => engine.makePlan(f.root, f.project.id, [{ source: f.marker(0), styles: { color: 'red' }, attrs: {} }]), /every instance/);
  assert.throws(() => f.plan([{ source: f.marker(1), styles: {}, attrs: {}, detached: true }]), /preview-only/);
  assert.throws(() => engine.makePlan(f.root, f.project.id, [{ source: f.marker(1), instances: 2, styles: { color: 'red' }, attrs: {} }]), /Multiple elements/);
});
test('rejects disk changes after session start and after planning; no partial writes', t => {
  const f = setup(t), marker = f.marker(1), plan = f.plan([{ source: marker, styles: { color: 'red' }, attrs: {} }]);
  fs.appendFileSync(path.join(f.root, 'Page.tsx'), '// editor changed file\n');
  assert.throws(() => f.apply(plan), /CONFLICT/); assert.match(fs.readFileSync(path.join(f.root, 'Page.tsx'), 'utf8'), /editor changed file/);
  assert.throws(() => f.plan([{ source: marker, styles: { color: 'red' }, attrs: {} }]), /changed/);
});
test('rejects external style changes and cross-project/nonlocal source writes', t => {
  const f = setup(t), source = f.marker(0); fs.appendFileSync(path.join(f.root, 'styles.tsx'), '// external\n');
  assert.throws(() => f.plan([{ source, styles: { color: 'red' }, attrs: {} }]), /changed on disk/);
  assert.throws(() => store.openSession('https://example.com'), /localhost/);
  const marker = engine.decodeMarker(f.marker(1)); marker.project = 'other';
  assert.throws(() => f.plan([{ source: Buffer.from(JSON.stringify(marker)).toString('base64url'), styles: {}, attrs: {}, text: 'Oops' }]), /different project/);
  assert.throws(() => engine.checkedFile(f.root, '../outside.tsx'), /permitted/);
});
test('next adapter is inactive in production and retains existing hooks in development', t => {
  const { withLiveLayout } = require('../source/next-adapter.cjs'), f = setup(t), original = process.env.NODE_ENV;
  t.after(() => { if (original === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = original; });
  const base = { compiler: { styledComponents: true }, webpack: cfg => ({ ...cfg, retained: true }) };
  process.env.NODE_ENV = 'production'; assert.equal(withLiveLayout(base, { root: f.root }), base);
  process.env.NODE_ENV = 'development'; const devRoot = path.parse(f.root).root.toLowerCase() === path.parse(__dirname).root.toLowerCase() ? f.root : path.resolve(__dirname, '..');
  const configured = withLiveLayout(base, { root: devRoot });
  assert.equal(configured.turbopack.rules['*.tsx'].loaders.length, 1);
  assert.equal(configured.webpack({ module: { rules: [] } }, { dev: true }).retained, true);
});
test('edits an imported CSS module declaration instead of adding an inline override', t => {
  const f = setup(t), source = 'import styles from "./page.module.css"; export default function Page(){ return <h1 className={styles.title}>Hello</h1>; }';
  fs.writeFileSync(path.join(f.root, 'Page.tsx'), source); fs.writeFileSync(path.join(f.root, 'page.module.css'), '.title { color: blue; padding: 10px; }\n');
  const session = store.openSession(f.project.origin);
  const plan = store.planChanges({ origin: f.project.origin, session: session.session, allowShared: true, changes: [{ source: f.marker(0), styles: { color: 'red', width: '250px' }, attrs: {} }] });
  store.applyPlan({ origin: f.project.origin, session: session.session, plan: plan.plan });
  const css = fs.readFileSync(path.join(f.root, 'page.module.css'), 'utf8'); assert.match(css, /color: red;/); assert.match(css, /width: 250px;/);
  assert.equal(fs.readFileSync(path.join(f.root, 'Page.tsx'), 'utf8'), source);
});
