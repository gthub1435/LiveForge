'use strict';
const assert = require('node:assert/strict'), http = require('node:http');
const { chromium } = require('playwright'), { browserPlugin } = require('../live-layout-editor.cjs');
(async () => {
  const html = `<!doctype html><html><head><style>body{margin:0;font:16px system-ui}#low{position:absolute;left:40px;top:100px;width:100px;height:140px;z-index:1;transform:translateZ(0);overflow:hidden;background:#aaa}#layerTarget{position:absolute;left:20px;top:20px;width:160px;height:80px;background:red;z-index:1}#high{position:absolute;left:40px;top:100px;width:220px;height:140px;z-index:50;background:blue}#steps{position:absolute;left:400px;top:100px;width:200px;height:100px}#steps>div{position:absolute;inset:0}#one{z-index:10;background:red}#two{z-index:20;background:blue}#three{z-index:30;background:green}</style></head><body><div id="low" data-stack-test><div id="layerTarget" data-stack-test>Target</div></div><div id="high" data-stack-test>Higher parent layer</div><div id="steps"><div id="one" data-stack-test>One</div><div id="two" data-stack-test>Two</div><div id="three" data-stack-test>Three</div></div></body></html>`;
  const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(html); }); await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  let browser;
  try {
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] }); const page = await browser.newPage({ viewport: { width: 1600, height: 1100 } }), errors = [];
    page.on('pageerror', error => errors.push(error.message)); await page.goto('http://127.0.0.1:' + server.address().port);
    await page.addScriptTag({ content: '(' + browserPlugin.toString() + ')({});' });
    const ui = page.locator('[data-live-layout-editor]');
    const select = async id => page.locator('#' + id).dispatchEvent('contextmenu', { bubbles: true, composed: true, clientX: 700, clientY: 200 });
    const order = (x, y) => page.evaluate(({ x, y }) => document.elementsFromPoint(x, y).filter(n => n.hasAttribute('data-stack-test')).map(n => n.id), { x, y });
    assert.equal((await order(80, 140))[0], 'high');
    await select('layerTarget'); await ui.getByRole('button', { name: 'Bring to front', exact: true }).click();
    assert.equal((await order(80, 140))[0], 'layerTarget', 'selected child crosses a higher ancestor stacking context');
    assert.equal((await order(180, 140))[0], 'layerTarget', 'clipping ancestor was overridden');
    assert.equal(await page.locator('#layerTarget').evaluate(n => n.parentElement.id), 'low', 'DOM/component ownership is preserved');
    await ui.getByRole('button', { name: 'Undo', exact: true }).click();
    assert.equal((await order(80, 140))[0], 'high'); assert.equal(await page.locator('#low').evaluate(n => getComputedStyle(n).overflow), 'hidden');
    await ui.getByRole('button', { name: 'Redo', exact: true }).click(); assert.equal((await order(80, 140))[0], 'layerTarget');
    await select('layerTarget'); await ui.getByRole('button', { name: 'Send to back', exact: true }).click(); assert.equal((await order(80, 140))[0], 'high');
    console.log('PASS global front/back crosses nested stacking contexts, escapes clipping, preserves DOM, supports Undo/Redo');
    await select('two'); await ui.getByRole('button', { name: 'Bring forward', exact: true }).click(); assert.equal((await order(450, 140))[0], 'two');
    await ui.getByRole('button', { name: 'Send backward', exact: true }).click(); assert.equal((await order(450, 140))[0], 'three');
    await page.evaluate(() => { window.LiveLayoutEditor.destroy(); for (const id of ['one', 'two', 'three']) document.getElementById(id).style.zIndex = '0'; });
    await page.addScriptTag({ content: '(' + browserPlugin.toString() + ')({});' });
    await select('one'); await ui.getByRole('button', { name: 'Bring forward', exact: true }).click();
    assert.deepEqual((await order(450, 140)).slice(0, 3), ['three', 'one', 'two'], 'one step crosses exactly one sibling when all ranks tie');
    const changes = await page.evaluate(() => window.LiveLayoutEditor.getChanges());
    assert.ok(Object.values(changes.pages['/']).some(e => e.styles['z-index']));
    // The editor itself remains operable even after rebasing huge page z-indexes.
    await page.locator('#high').evaluate(n => { n.style.zIndex = '2147483647'; });
    await select('layerTarget'); await ui.getByRole('button', { name: 'Bring to front', exact: true }).click(); assert.equal((await order(80, 140))[0], 'layerTarget');
    assert.equal(await ui.getByRole('button', { name: 'Done', exact: true }).isEnabled(), true);
    console.log('PASS forward/backward, extreme z-index rebasing, staged source styles and operable editor');
    assert.deepEqual(errors, []);
  } finally { if (browser) await browser.close(); server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
})().catch(error => { console.error(error); process.exitCode = 1; });
