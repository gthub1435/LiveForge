'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer, validate } = require('../live-layout-editor.cjs');
const origin = 'http://localhost:3000';
const manifest = () => ({ version: 1, revision: 0, pages: { '/': { '[data-lle-id="headline"]': {
  styles: { color: 'red', translate: '12px 18px' }, attrs: {}, text: '<hello> "there"' } } } });
async function setup(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'lle-test-'));
  const app = createServer({ root, origin, port: 0 });
  await new Promise(resolve => app.listen(resolve));
  t.after(async () => { await new Promise(resolve => app.server.close(resolve)); fs.rmSync(root, { recursive: true, force: true }); });
  return { app, root, base: 'http://127.0.0.1:' + app.server.address().port };
}
const headers = app => ({ Origin: origin, 'X-LLE-Token': app.token, 'Content-Type': 'application/json' });
test('writes CSS, JSON and safe JS, keeps history, survives restarting', async t => {
  const { app, root, base } = await setup(t);
  const res = await fetch(base + '/save', { method: 'POST', headers: headers(app), body: JSON.stringify(manifest()) });
  assert.equal(res.status, 200); assert.equal((await res.json()).revision, 1);
  const out = path.join(root, 'live-layout-changes');
  assert.match(fs.readFileSync(path.join(out, 'overrides.css'), 'utf8'), /color: red !important/);
  assert.equal(JSON.parse(fs.readFileSync(path.join(out, 'overrides.json'))).revision, 1);
  assert.match(fs.readFileSync(path.join(out, 'overrides.js'), 'utf8'), /\\u003chello>/);
  assert.equal(fs.readdirSync(path.join(out, 'history')).length, 1);
  const restored = createServer({ root, origin, port: 0 });
  await new Promise(resolve => restored.listen(resolve));
  const saved = await fetch('http://127.0.0.1:' + restored.server.address().port + '/manifest', { headers: { 'X-LLE-Token': restored.token } }).then(r => r.json());
  assert.equal(saved.revision, 1); await new Promise(resolve => restored.server.close(resolve));
});
test('blocks unauthorized origins, tokens, Host, and stale revisions', async t => {
  const { app, base } = await setup(t);
  assert.equal((await fetch(base + '/manifest')).status, 401);
  assert.equal((await fetch(base + '/manifest', { headers: { Origin: 'https://evil.test', 'X-LLE-Token': app.token } })).status, 403);
  const wrongHost = await new Promise(resolve => { require('node:http').get(base + '/manifest', { headers: { Host: 'evil.test', 'X-LLE-Token': app.token } }, res => { res.resume(); resolve(res.statusCode); }); });
  assert.equal(wrongHost, 403);
  assert.equal((await fetch(base + '/save', { method: 'POST', headers: { 'X-LLE-Token': app.token, 'Content-Type': 'application/json' }, body: JSON.stringify(manifest()) })).status, 403);
  assert.equal((await fetch(base + '/save', { method: 'POST', headers: headers(app), body: JSON.stringify(manifest()) })).status, 200);
  assert.equal((await fetch(base + '/save', { method: 'POST', headers: headers(app), body: JSON.stringify(manifest()) })).status, 409);
  assert.equal((await fetch(base + '/../../package.json?token=' + app.token)).status, 404);
});
test('rejects unsafe manifests, selectors, attributes and non-local origins', async t => {
  assert.throws(() => validate(JSON.parse('{"version":1,"revision":0,"pages":{"__proto__":{}}}')));
  for (const value of ['red; } body { display:none', 'url(https://evil.test)', 'red !important']) {
    const data = manifest(); data.pages['/']['[data-lle-id="headline"]'].styles.color = value; assert.throws(() => validate(data));
  }
  const data = manifest(); data.pages['/']['[data-lle-id="headline"]'].attrs.src = 'javascript:alert(1)'; assert.throws(() => validate(data));
  const { root } = await setup(t);
  assert.throws(() => createServer({ root, origin: 'https://example.com', port: 0 }));
  assert.throws(() => createServer({ root, origin: 'http://localhost:3000/path', port: 0 }));
});
test('refuses symlinked output directories', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'lle-link-'));
  const outside = fs.mkdtempSync(path.join(os.tmpdir(), 'lle-outside-'));
  t.after(() => { fs.rmSync(root, { recursive: true, force: true }); fs.rmSync(outside, { recursive: true, force: true }); });
  try { fs.symlinkSync(outside, path.join(root, 'live-layout-changes'), 'junction'); }
  catch (error) { if (error.code === 'EPERM') return t.skip('Creating symlinks requires privileges'); throw error; }
  assert.throws(() => createServer({ root, origin, port: 0 }), /symlink/);
  assert.deepEqual(fs.readdirSync(outside), []);
});
test('history stays bounded and reset writes empty overrides', async t => {
  const { app, base, root } = await setup(t);
  for (let i = 0; i < 23; i++) {
    const data = manifest(); data.revision = i;
    if (i === 22) data.pages = {};
    const res = await fetch(base + '/save', { method: 'POST', headers: headers(app), body: JSON.stringify(data) }); assert.equal(res.status, 200);
  }
  const out = path.join(root, 'live-layout-changes');
  assert.equal(fs.readdirSync(path.join(out, 'history')).length, 20);
  assert.deepEqual(JSON.parse(fs.readFileSync(path.join(out, 'overrides.json'))).pages, {});
});
test('accepts explicit-Apply editor data: detach, HTML, CSS properties and replacement images', () => {
  const data = manifest(), e = data.pages['/']['[data-lle-id="headline"]'];
  e.detached = true; e.html = '<strong>Replacement</strong>'; delete e.text;
  e.styles['word-spacing'] = '3px'; e.styles['--accent'] = '#abcdef';
  e.attrs = { src: 'data:image/png;base64,iVBORw0KGgo=', srcset: '', title: 'Example' };
  assert.equal(validate(data), data);
  e.attrs.src = 'data:image/svg+xml;base64,AAAA'; assert.throws(() => validate(data));
});
test('starting the writer alone does not create source artifacts', async t => {
  const { root } = await setup(t);
  assert.deepEqual(fs.readdirSync(path.join(root, 'live-layout-changes')), []);
});
