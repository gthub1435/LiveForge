'use strict';
// Tests random, unrelated project folders and an external-origin page; no Next adapter.
const assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), http = require('node:http');
const { chromium } = require('playwright'), store = require('../source/store.cjs'), { register } = require('../source/companion.cjs');
(async () => {
  const packageRoot = path.resolve(__dirname, '..'), temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'lle-portable-browser-'));
  const previous = process.env.LLE_STATE_DIR; process.env.LLE_STATE_DIR = path.join(temporary, 'state');
  const extension = path.join(temporary, 'extension'); fs.cpSync(path.join(packageRoot, 'extension'), extension, { recursive: true });
  const manifestFile = path.join(extension, 'manifest.json'), manifest = JSON.parse(fs.readFileSync(manifestFile));
  manifest.host_permissions = ['http://localhost/*', 'https://unrelated-site.test/*']; fs.writeFileSync(manifestFile, JSON.stringify(manifest));
  const id = fs.readFileSync(path.join(extension, 'EXTENSION-ID.txt'), 'utf8').trim();
  const installed = require('../source/install.cjs').install(packageRoot);
  assert.equal(installed.directory, path.join(temporary, 'state', 'companion'));
  console.log('PASS permanent companion installation independent of extracted package path');
  const root = path.join(temporary, 'no-node-no-framework'); fs.mkdirSync(root);
  const filename = path.join(root, 'index.html');
  const original = '<!doctype html><html><head><meta charset="utf-8"><style>body{padding:40px;font:22px system-ui}h1{color:blue}</style></head><body><h1 id="headline">Original static heading</h1><p id="second">Second element</p></body></html>';
  fs.writeFileSync(filename, original);
  const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(filename)); });
  await new Promise(resolve => server.listen(0, resolve)); const origin = 'http://localhost:' + server.address().port;
  let context;
  try {
    context = await chromium.launchPersistentContext(path.join(temporary, 'profile'), { channel: 'chromium', headless: true, viewport: { width: 1480, height: 1080 }, args: ['--no-sandbox', '--disable-extensions-except=' + extension, '--load-extension=' + extension], env: { ...process.env } });
    let worker = context.serviceWorkers()[0]; if (!worker) worker = await context.waitForEvent('serviceworker');
    const page = await context.newPage(), errors = []; page.on('pageerror', e => errors.push(e.message)); await page.goto(origin);
    const tabId = await worker.evaluate(async origin => (await chrome.tabs.query({ url: origin + '/*' })).at(-1).id, origin);
    const popup = await context.newPage(); await popup.goto('chrome-extension://' + id + '/popup.html');
    const send = async message => popup.evaluate(async m => chrome.runtime.sendMessage({ kind: 'lle', ...m }), message);
    const connected = await send({ action: 'connect', tab: tabId, root }); assert.equal(connected.ok, true, connected.error);
    const started = await send({ action: 'start', tab: tabId, mode: 'source', autoApply: true }); assert.equal(started.ok, true, started.error);
    await page.getByRole('status').filter({ hasText: 'Connected to source' }).waitFor();
    await page.locator('#headline').dblclick(); await page.keyboard.insertText('Saved without framework setup'); await page.mouse.click(4, 4);
    await page.waitForTimeout(600); assert.equal(fs.readFileSync(filename, 'utf8'), original, 'No source writes before explicit Apply, even with stale autoApply setting');
    const ui = page.locator('[data-live-layout-editor]');
    assert.ok(await ui.locator('.brand-mark').evaluate(n => getComputedStyle(n).backgroundImage.includes('data:image/png;base64,')), 'chosen logo must appear in the extension UI');
    await ui.getByRole('button', { name: 'Apply changes in code', exact: true }).click();
    assert.equal(await page.locator('[data-lle-step=choose]').count(), 0);
    // Chooser removed, source review created; Cancel is focused. Shift+Tab applies.
    await page.locator('[data-lle-step=review]').waitFor(); await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Enter');
    await page.getByRole('status').filter({ hasText: 'Updated original source' }).waitFor();
    assert.match(fs.readFileSync(filename, 'utf8'), /Saved without framework setup/);
    await page.locator('#headline').filter({ hasText: 'Saved without framework setup' }).waitFor();
    await page.waitForTimeout(1200); await page.getByRole('status').filter({ hasText: 'Connected to source' }).waitFor();
    assert.equal(await page.locator('#headline').textContent(), 'Saved without framework setup');
    assert.equal(fs.existsSync(path.join(root, 'package.json')), false);
    console.log('PASS folder connection, plain HTML source selection, explicit review/apply, saved reload, automatic reconnection; no package.json');
    // Regression: uninstrumented drag/resize must retain their original element
    // descriptor so the companion can discover the source at Apply time.
    await page.locator('#headline').dblclick();
    assert.equal(await ui.locator('#quickbar').isVisible(), false);
    await page.locator('#headline').click({ button: 'right' }); await ui.getByRole('button', { name: 'Live CSS inspector', exact: true }).click();
    const css = ui.locator('#cssPanel'); await css.locator('#cssSearch').fill('color');
    await css.getByRole('textbox', { name: 'CSS color', exact: true }).fill('rgb(22, 33, 44)'); await css.getByRole('textbox', { name: 'CSS color', exact: true }).press('Tab');
    await css.getByRole('button', { name: 'Close CSS inspector', exact: true }).click();
    const handle = await ui.locator('#move').boundingBox();
    await page.mouse.move(handle.x + handle.width / 2, handle.y + handle.height / 2); await page.mouse.down(); await page.mouse.move(handle.x + handle.width / 2 + 24, handle.y + handle.height / 2 + 16, { steps: 4 }); await page.mouse.up();
    const resize = await ui.locator('#resize').boundingBox();
    await page.mouse.move(resize.x + 7, resize.y + 7); await page.mouse.down(); await page.mouse.move(resize.x + 37, resize.y + 27, { steps: 4 }); await page.mouse.up();
    assert.doesNotMatch(fs.readFileSync(filename, 'utf8'), /translate:/);
    await ui.getByRole('button', { name: 'Apply changes in code', exact: true }).click();
    assert.equal(await page.locator('[data-lle-step=choose]').count(), 0);
    await page.locator('[data-lle-step=review]').waitFor(); await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Enter');
    await page.getByRole('status').filter({ hasText: 'Updated original source' }).waitFor();
    assert.match(fs.readFileSync(filename, 'utf8'), /translate: 24px 16px !important/); assert.match(fs.readFileSync(filename, 'utf8'), /width:/); assert.match(fs.readFileSync(filename, 'utf8'), /color: rgb\(22, 33, 44\) !important/);
    await page.waitForTimeout(1200); await page.getByRole('status').filter({ hasText: 'Connected to source' }).waitFor();
    console.log('PASS live CSS, drag and resize automatically save the matched original source through Native Messaging without compiler mappings');
    // Hidden hints survive source Apply/reload in the same tab. Show remains
    // a staged preview until the next explicitly reviewed source transaction.
    await page.locator('#headline').click({ button: 'right' }); await ui.getByRole('button', { name: 'Hide', exact: true }).click();
    assert.equal(await ui.locator('[data-hidden-marker]').count(), 1);
    await ui.getByRole('button', { name: 'Apply changes in code', exact: true }).click();
    await page.locator('[data-lle-step=review]').waitFor(); await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Enter');
    await page.getByRole('status').filter({ hasText: 'Updated original source' }).waitFor();
    assert.match(fs.readFileSync(filename, 'utf8'), /display: none !important/);
    await page.waitForTimeout(1200); await page.getByRole('status').filter({ hasText: 'Connected to source' }).waitFor();
    assert.equal(await page.locator('#headline').isVisible(), false);
    await ui.locator('[data-hidden-marker]').click(); assert.equal(await page.locator('#headline').isVisible(), true);
    assert.match(fs.readFileSync(filename, 'utf8'), /display: none !important/);
    await ui.getByRole('button', { name: 'Apply changes in code', exact: true }).click();
    await page.locator('[data-lle-step=review]').waitFor(); await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Enter');
    await page.getByRole('status').filter({ hasText: 'Updated original source' }).waitFor();
    assert.doesNotMatch(fs.readFileSync(filename, 'utf8'), /display: none !important/);
    await page.waitForTimeout(1200); await page.getByRole('status').filter({ hasText: 'Connected to source' }).waitFor();
    assert.equal(await page.locator('#headline').isVisible(), true); assert.equal(await ui.locator('[data-hidden-marker]').count(), 0);
    console.log('PASS source-hidden hint survives reload, Show preserves other styles and source remains unchanged until explicit Apply');
    // An unrelated local project can be connected without changing extension files.
    const other = path.join(temporary, 'different-project'); fs.mkdirSync(other); fs.writeFileSync(path.join(other, 'index.html'), '<h1>Different project</h1>');
    const switchResult = await send({ action: 'connect', tab: tabId, root: other }); assert.equal(switchResult.ok, true);
    assert.equal(store.projectFor(origin).root, fs.realpathSync(other));
    console.log('PASS different project binding without extension changes');
    const live = await context.newPage(); await live.route('https://unrelated-site.test/**', route => route.fulfill({ contentType: 'text/html', headers: { 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'" }, body: '<h1 id="live">Unrelated live website</h1><p>Live content</p>' })); await live.goto('https://unrelated-site.test/');
    const liveTab = await worker.evaluate(async () => (await chrome.tabs.query({ url: 'https://unrelated-site.test/*' })).at(-1).id);
    const denied = await send({ action: 'start', tab: liveTab, mode: 'source' }); assert.equal(denied.ok, false);
    const preview = await send({ action: 'start', tab: liveTab, mode: 'preview' }); assert.equal(preview.ok, true, preview.error);
    await live.locator('#live').dblclick(); await live.keyboard.insertText('Temporary live preview'); await live.mouse.click(4, 4);
    assert.equal(await live.locator('#live').textContent(), 'Temporary live preview');
    assert.equal(await live.locator('[data-live-layout-editor]').locator('#flush').isDisabled(), true);
    await live.reload(); assert.equal(await live.locator('#live').textContent(), 'Unrelated live website');
    console.log('PASS unrelated live-site preview under CSP, code Apply disabled, reload discards edits');
    assert.deepEqual(errors, []);
  } finally {
    if (context) await context.close(); server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
    if (previous === undefined) delete process.env.LLE_STATE_DIR; else process.env.LLE_STATE_DIR = previous;
    register(id); fs.rmSync(temporary, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
