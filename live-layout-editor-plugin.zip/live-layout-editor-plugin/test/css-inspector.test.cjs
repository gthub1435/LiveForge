'use strict';
const assert = require('node:assert/strict'), http = require('node:http');
const { chromium } = require('playwright'), { browserPlugin } = require('../live-layout-editor.cjs');
(async () => {
  const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end('<!doctype html><html><head><style>h1{color:rgb(10,20,30);--accent:purple}h1::before{content:"test";color:red}</style></head><body><h1 id="title" style="margin:80px">Live properties</h1><p id="second">Other target</p></body></html>'); });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); let browser;
  try {
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] }); const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } }), errors = [];
    page.on('pageerror', e => errors.push(e.message)); await page.goto('http://127.0.0.1:' + server.address().port); await page.addScriptTag({ content: '(' + browserPlugin.toString() + ')({});' });
    const ui = page.locator('[data-live-layout-editor]'), css = ui.locator('#cssPanel');
    await page.locator('#title').dblclick(); assert.equal(await css.isVisible(), true);
    await page.locator('#title').click({ button: 'right' }); await ui.getByRole('button', { name: 'Live CSS inspector', exact: true }).click();
    assert.equal(await css.isVisible(), true); assert.equal(await ui.locator('#quickbar').isVisible(), false);
    assert.ok(await css.locator('[data-css-property]').count() > 200);
    await css.getByRole('searchbox', { name: 'Filter CSS' }).fill('color');
    assert.equal(await css.getByRole('textbox', { name: 'CSS color', exact: true }).inputValue(), 'rgb(10, 20, 30)');
    await css.getByRole('textbox', { name: 'CSS color', exact: true }).fill('rgb(44, 55, 66)'); await css.getByRole('textbox', { name: 'CSS color', exact: true }).press('Tab');
    assert.equal(await page.locator('#title').evaluate(n => getComputedStyle(n).color), 'rgb(44, 55, 66)');
    await page.locator('#title').evaluate(n => { n.style.fontSize = '47px'; });
    await css.getByRole('searchbox', { name: 'Filter CSS' }).fill('font-size'); assert.equal(await css.getByRole('textbox', { name: 'CSS font-size', exact: true }).inputValue(), '47px');
    await css.locator('#cssView').selectOption('rules'); await css.locator('#cssSearch').fill('h1'); assert.match(await css.locator('#cssRows').textContent(), /color/);
    await css.locator('#cssView').selectOption('before'); await css.locator('#cssSearch').fill('color'); assert.equal(await css.getByRole('textbox', { name: 'CSS color', exact: true }).isDisabled(), true); assert.equal(await css.getByRole('textbox', { name: 'CSS color', exact: true }).inputValue(), 'rgb(255, 0, 0)');
    const before = await page.evaluate(() => window.LiveLayoutEditor.getChanges());
    const normal = await css.boundingBox(); await css.getByRole('button', { name: 'Minimize CSS inspector', exact: true }).click(); assert.ok((await css.boundingBox()).height < 100);
    await css.getByRole('button', { name: 'Restore CSS inspector', exact: true }).click(); assert.ok(Math.abs((await css.boundingBox()).width - normal.width) < 2);
    await css.getByRole('button', { name: 'Maximize CSS inspector', exact: true }).click(); assert.ok((await css.boundingBox()).width > 1400);
    await css.getByRole('button', { name: 'Restore CSS inspector size', exact: true }).click(); assert.ok(Math.abs((await css.boundingBox()).width - normal.width) < 2);
    assert.deepEqual(await page.evaluate(() => window.LiveLayoutEditor.getChanges()), before);
    await css.getByRole('button', { name: 'Close CSS inspector', exact: true }).click(); assert.equal(await css.isVisible(), false);
    assert.deepEqual(errors, []); console.log('PASS live computed CSS, search, CSS edits, matched rules, pseudo-element values, independent minimize/maximize/restore and preserved preview');
  } finally { if (browser) await browser.close(); server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
})().catch(error => { console.error(error); process.exitCode = 1; });
