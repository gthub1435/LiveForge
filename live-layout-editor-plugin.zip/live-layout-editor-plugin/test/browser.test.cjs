'use strict';
const assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), http = require('node:http');
let playwright;
try { playwright = require('playwright'); } catch { playwright = require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/playwright'); }
const { createServer, browserPlugin } = require('../live-layout-editor.cjs');
(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'lle-browser-'));
  const dir = path.resolve(__dirname, '..'), errors = [];
  const web = http.createServer((req, res) => {
    const route = new URL(req.url, 'http://localhost').pathname;
    if (route === '/' || route === '/second') { res.setHeader('Content-Type', 'text/html'); res.end(fs.readFileSync(path.join(dir, 'demo.html'))); }
    else if (route === '/live-layout-editor.cjs') { res.setHeader('Content-Type', 'text/javascript'); res.end(fs.readFileSync(path.join(dir, 'live-layout-editor.cjs'))); }
    else res.writeHead(404).end();
  });
  await new Promise(resolve => web.listen(0, '127.0.0.1', resolve));
  const origin = 'http://127.0.0.1:' + web.address().port;
  const writer = createServer({ root, origin, port: 0 }); await new Promise(resolve => writer.listen(resolve));
  const url = origin + '/?bridge=' + writer.server.address().port + '&token=' + writer.token;
  let browser;
  try {
    browser = await playwright.chromium.launch({ headless: true, ...(process.env.LLE_BROWSER_EXECUTABLE ? { executablePath: process.env.LLE_BROWSER_EXECUTABLE } : {}), args: ['--no-sandbox'] });
    const ctx = await browser.newContext({ viewport: { width: 1440, height: 1100 }, acceptDownloads: true });
    const page = await ctx.newPage(); page.on('pageerror', error => errors.push(error.message));
    const ui = () => page.locator('[data-live-layout-editor]');
    const source = () => fs.existsSync(path.join(root, 'live-layout-changes/overrides.json')) ? JSON.parse(fs.readFileSync(path.join(root, 'live-layout-changes/overrides.json'), 'utf8')) : { version: 1, revision: 0, pages: {} };
    const pick = async selector => { if (await ui().locator('#quickbar').isVisible()) await page.keyboard.press('Escape'); await page.locator(selector).dblclick(); };
    const menu = async selector => { await page.locator(selector).dispatchEvent('contextmenu', { bubbles: true, clientX: 300, clientY: 180 }); };
    const done = async () => page.keyboard.press('Escape');
    const apply = async () => { await ui().getByRole('button', { name: 'Apply changes in code', exact: true }).click(); await page.getByRole('status').filter({ hasText: 'Saved to project' }).waitFor(); };
    await page.goto(url); await page.getByRole('status').filter({ hasText: 'Connected' }).waitFor();
    // Editor chrome can be moved without changing the page or source manifest.
    const dragPanel = async (handleId, dx, dy) => {
      const handle = ui().locator('#' + handleId), r = await handle.boundingBox();
      await page.mouse.move(r.x + 12, r.y + r.height / 2); await page.mouse.down();
      await page.mouse.move(r.x + 12 + dx, r.y + r.height / 2 + dy, { steps: 5 }); await page.mouse.up();
    };
    const dockBefore = await ui().locator('#panel').boundingBox();
    await dragPanel('dockDrag', 500, -90);
    const dockMoved = await ui().locator('#panel').boundingBox();
    assert.ok(dockMoved.x > dockBefore.x + 450 && dockMoved.y < dockBefore.y - 60);
    assert.equal(source().revision, 0);
    await page.waitForTimeout(350);
    assert.ok(Math.abs((await ui().locator('#panel').boundingBox()).x - dockMoved.x) < 1);
    await ui().locator('#dockDrag').press('Home');
    assert.ok(Math.abs((await ui().locator('#panel').boundingBox()).x - dockBefore.x) < 1);
    // Editing is available immediately; no element dropdown and no launcher required.
    await pick('[data-lle-id="headline"]');
    await page.keyboard.insertText('Directly edited heading');
    await page.mouse.click(3, 3); // outside commits the inline edit to the preview
    assert.equal(await page.locator('[data-lle-id="headline"]').textContent(), 'Directly edited heading');
    assert.equal(source().revision, 0); assert.deepEqual(source().pages, {});
    assert.equal(fs.existsSync(path.join(root, 'live-layout-changes/overrides.json')), false);
    await page.waitForTimeout(650); // catch accidental autosaves after blur/debounce
    assert.equal(source().revision, 0);
    await ui().getByRole('button', { name: 'Undo', exact: true }).click();
    assert.equal(await page.locator('[data-lle-id="headline"]').textContent(), 'Make your next idea visible.');
    await ui().getByRole('button', { name: 'Redo', exact: true }).click();
    assert.equal(await page.locator('[data-lle-id="headline"]').textContent(), 'Directly edited heading');
    await apply(); assert.equal(source().revision, 1);
    // Export downloads two reports, highlights their scope, and never writes source.
    const exportDownloads = new Promise((resolve, reject) => {
      const files = []; const timeout = setTimeout(() => reject(new Error('Export downloads timed out')), 5000);
      const handler = file => { files.push(file); if (files.length === 2) { clearTimeout(timeout); page.off('download', handler); resolve(files); } };
      page.on('download', handler);
    });
    await ui().getByRole('button', { name: 'Export report', exact: true }).click();
    const exportedFiles = await exportDownloads;
    assert.deepEqual(exportedFiles.map(f => f.suggestedFilename()).sort(), ['live-layout-changes.json', 'live-layout-changes.txt']);
    assert.equal(source().revision, 1);
    assert.equal(await ui().locator('.effect-label, #actionHint').count(), 0);
    await page.reload(); await page.waitForFunction(() => document.querySelector('[data-lle-id="headline"]').textContent === 'Directly edited heading');
    // Contextual color; font-size; custom CSS property; exact positioning.
    await pick('[data-lle-id="headline"]'); await menu('[data-lle-id="headline"]');
    await ui().getByRole('spinbutton', { name: 'Font size', exact: true }).click();
    await ui().locator('#quickColor').evaluate(el => { el.value = '#dc143c'; el.dispatchEvent(new Event('input', { bubbles: true })); });
    assert.equal(await page.locator('[data-lle-id="headline"]').evaluate(el => getComputedStyle(el).color), 'rgb(220, 20, 60)');
    await ui().getByRole('spinbutton', { name: 'Font size', exact: true }).fill('48');
    await ui().getByRole('spinbutton', { name: 'Font size', exact: true }).press('Tab');
    await ui().getByRole('button', { name: 'More', exact: true }).click();
    await ui().getByText('Any CSS property', { exact: true }).click();
    await ui().locator('#customProp').fill('word-spacing'); await ui().locator('#customValue').fill('3px');
    await ui().getByRole('button', { name: 'Set CSS', exact: true }).click();
    assert.equal(await page.locator('[data-lle-id="headline"]').evaluate(el => getComputedStyle(el).wordSpacing), '3px');
    if (process.env.LLE_SCREENSHOT_DIR) {
      await page.screenshot({ path: path.join(process.env.LLE_SCREENSHOT_DIR, 'glass-editor-light.png') });
      await page.evaluate(() => { document.body.dataset.oldBg = document.body.style.background; document.body.style.background = '#0c1528'; });
      await page.screenshot({ path: path.join(process.env.LLE_SCREENSHOT_DIR, 'glass-editor-dark.png') });
      await page.evaluate(() => { document.body.style.background = document.body.dataset.oldBg; delete document.body.dataset.oldBg; });
    }
    await page.keyboard.press('Escape'); // close the context menu, keep selection
    const move = ui().getByRole('button', { name: 'Move selected element', exact: true });
    const r = await move.boundingBox(); await page.mouse.move(r.x + r.width / 2, r.y + r.height / 2);
    await page.mouse.down(); await page.mouse.move(r.x + r.width / 2 + 35, r.y + r.height / 2 + 22, { steps: 6 }); await page.mouse.up();
    assert.equal(source().revision, 1);
    const resize = ui().getByRole('button', { name: 'Resize selected element', exact: true });
    const rr = await resize.boundingBox(); await page.mouse.move(rr.x + 8, rr.y + 8); await page.mouse.down();
    await page.mouse.move(rr.x + 48, rr.y + 28, { steps: 5 }); await page.mouse.up();
    await apply(); assert.equal(source().pages['/']['[data-lle-id="headline"]'].styles.translate, '35px 22px');
    // Ungroup direct children, while keeping their screen coordinates and allowing undo.
    await pick('[data-lle-id="card-title-one"]');
    await menu('[data-lle-id="card-title-one"]');
    await ui().getByRole('button', { name: 'Parent', exact: true }).click();
    await ui().getByRole('button', { name: 'Parent', exact: true }).click();
    const beforeFree = await page.locator('[data-lle-id="card-one"]').boundingBox();
    assert.equal(await ui().getByRole('button', { name: 'Free children', exact: true }).isEnabled(), true);
    await ui().getByRole('button', { name: 'Free children', exact: true }).click();
    const afterFree = await page.locator('[data-lle-id="card-one"]').boundingBox();
    await page.waitForFunction(() => document.querySelector('[data-live-layout-editor]').shadowRoot.querySelectorAll('.effect-area').length === 3);
    assert.equal(await ui().locator('.effect-area').count(), 3);
    assert.equal(await ui().locator('.effect-label, #actionHint').count(), 0);
    assert.ok(Math.abs(beforeFree.x - afterFree.x) < 1 && Math.abs(beforeFree.y - afterFree.y) < 1);
    assert.equal(await page.locator('[data-lle-id="card-one"]').evaluate(el => el.parentElement.tagName), 'BODY');
    await ui().getByRole('button', { name: 'Undo', exact: true }).click();
    assert.equal(await page.locator('[data-lle-id="card-one"]').evaluate(el => el.parentElement.dataset.lleId), 'cards');
    await done();
    // Detach a nested element, move it outside its parent and replay it after Apply/reload.
    await pick('[data-lle-id="sample"]'); await menu('[data-lle-id="sample"]'); await ui().getByRole('button', { name: 'Free element', exact: true }).click();
    assert.equal(await page.locator('[data-lle-id="sample"]').evaluate(el => el.parentElement.tagName), 'BODY');
    await apply(); await page.reload(); await page.getByRole('status').filter({ hasText: 'Connected' }).waitFor();
    assert.equal(await page.locator('[data-lle-id="sample"]').evaluate(el => el.parentElement.tagName), 'BODY');
    // HTML content replacement is preview-only until Apply, is sanitized, and is reversible.
    await pick('[data-lle-id="card-title-two"]'); await menu('[data-lle-id="card-title-two"]'); await ui().getByRole('button', { name: 'Parent', exact: true }).click();
    await ui().getByRole('button', { name: 'Replace', exact: true }).click();
    await ui().locator('#html').fill('<h2 data-lle-id="replacement">Replaced card</h2><script>window.bad=true</script><img onerror="window.bad=true" src="javascript:alert(1)">');
    await ui().getByRole('button', { name: 'Replace contents', exact: true }).click();
    assert.equal(await page.locator('[data-lle-id="replacement"]').textContent(), 'Replaced card');
    assert.equal(await page.evaluate(() => !!window.bad), false);
    await ui().getByRole('button', { name: 'Undo', exact: true }).click();
    assert.equal(await page.locator('[data-lle-id="card-title-two"]').textContent(), 'Local source sync');
    await done();
    const buttonBeforeHide = await page.locator('[data-lle-id="cta"]').boundingBox();
    await pick('[data-lle-id="cta"]');
    await menu('[data-lle-id="cta"]');
    assert.equal(await ui().getByRole('button', { name: 'Free children', exact: true }).isDisabled(), true);
    assert.equal(await ui().getByRole('button', { name: 'Image file', exact: true }).isDisabled(), true);
    assert.equal(await ui().getByRole('button', { name: 'Free element', exact: true }).isEnabled(), true);
    await ui().getByRole('button', { name: 'Hide', exact: true }).click();
    assert.equal(await page.locator('[data-lle-id="cta"]').isVisible(), false);
    await ui().locator('.effect-area').first().waitFor({ state: 'attached' });
    assert.ok(await ui().locator('.effect-area').count() > 0);
    assert.equal(await ui().locator('.effect-label, #actionHint').count(), 0);
    await ui().getByRole('button', { name: 'Undo', exact: true }).click();
    assert.equal(await page.locator('[data-lle-id="cta"]').isVisible(), true);
    // Native text fields and image-file replacement are staged without source writes.
    await page.evaluate(() => {
      const field = document.createElement('input'); field.dataset.lleId = 'field'; field.value = 'Original value'; field.style.cssText = 'position:fixed;top:10px;left:300px;width:180px'; document.body.append(field);
      const image = document.createElement('img'); image.dataset.lleId = 'image'; image.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=='; image.style.cssText = 'position:fixed;top:10px;left:500px;width:100px;height:80px'; document.body.append(image);
    });
    const revisionBeforeContent = source().revision;
    await pick('[data-lle-id="field"]'); await page.keyboard.insertText('Changed value'); await page.mouse.click(3, 3);
    await menu('[data-lle-id="field"]');
    assert.equal(await page.locator('[data-lle-id="field"]').inputValue(), 'Changed value');
    assert.equal((await page.evaluate(() => window.LiveLayoutEditor.getChanges())).pages['/']['[data-lle-id="field"]'].attrs.value, 'Changed value');
    await pick('[data-lle-id="image"]');
    await menu('[data-lle-id="image"]');
    assert.equal(await ui().getByRole('button', { name: 'Image file', exact: true }).isEnabled(), true);
    assert.equal(await ui().getByRole('button', { name: 'Free children', exact: true }).isDisabled(), true);
    await ui().locator('#imageFile').setInputFiles({ name: 'replacement.png', mimeType: 'image/png', buffer: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aG7sAAAAASUVORK5CYII=', 'base64') });
    await page.waitForFunction(() => document.querySelector('[data-lle-id="image"]').getAttribute('src').startsWith('data:image/png;'));
    assert.equal(source().revision, revisionBeforeContent);
    await done();
    // SVG shapes can be selected and colored (SVG internals retain their SVG coordinate system).
    await page.evaluate(() => { const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('width', '100'); svg.setAttribute('height', '80'); svg.style.cssText='position:fixed;left:10px;top:10px'; svg.innerHTML='<rect data-lle-id="shape" x="0" y="0" width="90" height="70" fill="blue"/>'; document.body.append(svg); });
    await pick('[data-lle-id="shape"]');
    await menu('[data-lle-id="shape"]');
    await ui().locator('#quickColor').evaluate(el => { el.value = '#00ff00'; el.dispatchEvent(new Event('input', { bubbles: true })); });
    assert.equal(await page.locator('[data-lle-id="shape"]').evaluate(el => getComputedStyle(el).fill), 'rgb(0, 255, 0)');
    await done();
    // Conflicting tabs never overwrite the source.
    const other = await ctx.newPage(); await other.goto(url); await other.getByRole('status').filter({ hasText: 'Connected' }).waitFor();
    await apply(); const revision = source().revision;
    await other.locator('[data-lle-id="headline"]').dblclick(); await other.keyboard.insertText('Conflicting edit');
    await other.mouse.click(3, 3); await other.getByRole('button', { name: 'Apply changes in code', exact: true }).click();
    await other.getByRole('status').filter({ hasText: 'Not saved' }).waitFor(); assert.equal(source().revision, revision);
    await other.close({ runBeforeUnload: false });
    await ui().getByRole('button', { name: 'Reset page', exact: true }).click(); await apply();
    assert.deepEqual(source().pages, {});
    assert.equal(await page.locator('[data-lle-id="sample"]').evaluate(el => el.parentElement.dataset.lleId), 'card-one');
    assert.equal(await page.locator('[data-lle-id="headline"]').textContent(), 'Make your next idea visible.');
    await page.evaluate(() => window.LiveLayoutEditor.destroy());
    assert.equal(await page.locator('[data-live-layout-editor]').count(), 0);
    // Non-local websites stay DevTools-like even when passed a bridge config.
    const deployed = await ctx.newPage();
    await deployed.route('https://example.test/**', route => route.fulfill({ contentType: 'text/html', body: '<h1 data-lle-id="live-title">Live site</h1>' }));
    await deployed.goto('https://example.test/');
    await deployed.addScriptTag({ content: '(' + browserPlugin.toString() + ')(' + JSON.stringify({ base: 'http://127.0.0.1:' + writer.server.address().port, token: writer.token, origin: 'https://example.test' }) + ')' });
    assert.equal(await deployed.evaluate(() => window.LiveLayoutEditor.getMode()), 'preview');
    assert.equal(await deployed.getByRole('button', { name: 'Apply changes in code', exact: true }).count(), 0);
    await deployed.locator('[data-lle-id="live-title"]').dblclick(); await deployed.keyboard.insertText('Temporary only'); await deployed.mouse.click(1, 1);
    assert.equal(await deployed.locator('[data-lle-id="live-title"]').textContent(), 'Temporary only');
    await deployed.evaluate(() => window.LiveLayoutEditor.apply()); assert.deepEqual(source().pages, {});
    await deployed.reload(); assert.equal(await deployed.locator('[data-lle-id="live-title"]').textContent(), 'Live site');
    assert.deepEqual(errors, []);
    console.log('PASS browser: double-click, inline text, outside-click staging, explicit Apply, reload, quick color, arbitrary CSS, drag/resize, free children/detach, HTML sanitization/undo, SVG, conflicts, reset, live-site no-write and refresh');
  } finally {
    if (browser) await browser.close(); await new Promise(resolve => writer.server.close(resolve)); await new Promise(resolve => web.close(resolve)); fs.rmSync(root, { recursive: true, force: true });
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
