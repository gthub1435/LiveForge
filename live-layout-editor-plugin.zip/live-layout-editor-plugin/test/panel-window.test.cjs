'use strict';
const assert = require('node:assert/strict'), http = require('node:http');
const { chromium } = require('playwright'), { browserPlugin } = require('../live-layout-editor.cjs');
(async () => {
  const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end('<!doctype html><html><body><h1 id="heading" style="margin:80px">Edit while minimized</h1></body></html>'); });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); let browser;
  try {
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] }); const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } }), errors = [];
    page.on('pageerror', e => errors.push(e.message)); await page.goto('http://127.0.0.1:' + server.address().port);
    await page.addScriptTag({ content: '(' + browserPlugin.toString() + ')({});' });
    const ui = page.locator('[data-live-layout-editor]'), panel = ui.locator('#panel');
    const normal = await panel.boundingBox();
    await ui.getByRole('button', { name: 'Minimize editor panel', exact: true }).click();
    const minimized = await panel.boundingBox(); assert.ok(minimized.height < normal.height / 2); assert.ok(minimized.width < normal.width);
    assert.equal(await ui.getByRole('button', { name: 'Undo', exact: true }).isVisible(), false);
    await page.locator('#heading').dblclick(); await page.keyboard.insertText('Editing still active'); await page.mouse.click(4, 4);
    assert.equal(await page.locator('#heading').textContent(), 'Editing still active');
    await ui.getByRole('button', { name: 'Restore editor panel', exact: true }).click();
    const restored = await panel.boundingBox(); assert.ok(Math.abs(restored.width - normal.width) < 2); assert.ok(Math.abs(restored.x - normal.x) < 2); assert.ok(Math.abs((restored.y + restored.height) - (normal.y + normal.height)) < 2);
    const savedPreview = await page.evaluate(() => window.LiveLayoutEditor.getChanges());
    await ui.getByRole('button', { name: 'Maximize editor panel', exact: true }).click();
    const maximized = await panel.boundingBox(); assert.ok(maximized.width > 1400); assert.ok(maximized.height > 960);
    await ui.getByRole('button', { name: 'Minimize editor panel', exact: true }).click();
    assert.ok((await panel.boundingBox()).height < 100);
    await ui.getByRole('button', { name: 'Restore editor panel', exact: true }).click(); assert.ok((await panel.boundingBox()).height > 960);
    await ui.getByRole('button', { name: 'Restore editor panel size', exact: true }).click();
    assert.ok(Math.abs((await panel.boundingBox()).height - restored.height) < 2);
    assert.deepEqual(await page.evaluate(() => window.LiveLayoutEditor.getChanges()), savedPreview, 'window controls never change staged page/source data');
    await ui.getByRole('button', { name: 'Minimize editor panel', exact: true }).click();
    const beforeDrag = await panel.boundingBox(), handle = await ui.locator('#dockDrag').boundingBox();
    await page.mouse.move(handle.x + 12, handle.y + 8); await page.mouse.down(); await page.mouse.move(handle.x + 210, handle.y - 100, { steps: 5 }); await page.mouse.up();
    const afterDrag = await panel.boundingBox(); assert.ok(afterDrag.x > beforeDrag.x + 150);
    await page.setViewportSize({ width: 320, height: 640 });
    await page.waitForTimeout(300); const small = await panel.boundingBox(); assert.ok(small.x >= 0 && small.x + small.width <= 320 && small.y + small.height <= 640);
    assert.equal(await ui.getByRole('button', { name: 'Restore editor panel', exact: true }).isVisible(), true);
    assert.deepEqual(errors, []);
    console.log('PASS minimize keeps editing active, restore/maximize retain size and position, drag and narrow viewport work, preview data unchanged');
  } finally { if (browser) await browser.close(); server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
})().catch(error => { console.error(error); process.exitCode = 1; });
