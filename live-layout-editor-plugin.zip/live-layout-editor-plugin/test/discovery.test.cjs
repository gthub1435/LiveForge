'use strict';
const { test } = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const store = require('../source/store.cjs'), discovery = require('../source/discovery.cjs');
function setup(t, files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lle-portable-')), root = path.join(dir, 'arbitrary-project'); fs.mkdirSync(root);
  const previous = process.env.LLE_STATE_DIR; process.env.LLE_STATE_DIR = path.join(dir, 'state');
  for (const [file, text] of Object.entries(files)) fs.writeFileSync(path.join(root, file), text);
  const project = store.connect(root, 'http://localhost:4291'), session = store.openSession(project.origin);
  t.after(() => { if (previous === undefined) delete process.env.LLE_STATE_DIR; else process.env.LLE_STATE_DIR = previous; fs.rmSync(dir, { recursive: true, force: true }); });
  return { root, project, session, resolve: descriptor => store.dispatch({ action: 'resolve', origin: project.origin, session: session.session, descriptor }),
    plan: changes => store.planChanges({ origin: project.origin, session: session.session, changes }),
    apply: plan => store.applyPlan({ origin: project.origin, session: session.session, plan: plan.plan }) };
}
test('plain HTML project without package.json: discovery, review plan, original file write, restore', t => {
  const original = '<!doctype html>\n<html><body><h1 id="title" class="hero">Hello &amp; welcome</h1><img src="/old.png"><textarea>Old</textarea></body></html>';
  const f = setup(t, { 'index.html': original });
  const found = f.resolve({ tag: 'h1', text: 'Hello & welcome', attrs: { id: 'title' } });
  assert.equal(found.total, 1); assert.equal(found.candidates[0].file, 'index.html');
  const plan = f.plan([{ source: found.candidates[0].source, styles: { color: '#ff0000', width: '250px' }, attrs: { title: 'A "quoted" {literal}' }, text: 'New <literal> & title' }]);
  assert.equal(fs.readFileSync(path.join(f.root, 'index.html'), 'utf8'), original);
  const result = f.apply(plan), actual = fs.readFileSync(path.join(f.root, 'index.html'), 'utf8');
  assert.match(actual, /New &lt;literal&gt; &amp; title/); assert.match(actual, /color: #ff0000 !important/); assert.match(actual, /&quot;quoted&quot; &#123;literal&#125;/);
  assert.match(actual, /<img src="\/old.png">/); assert.ok(!fs.existsSync(path.join(f.root, 'package.json')));
  store.restore(result.transaction, f.project.origin); assert.equal(fs.readFileSync(path.join(f.root, 'index.html'), 'utf8'), original);
});
test('JSX discovery needs no compiler plugin; writes element style without modifying class CSS', t => {
  const f = setup(t, { 'App.jsx': 'export default () => <h1 className="text-blue-500">Heading</h1>;', 'styles.css': '.text-blue-500 { color:blue }' });
  const candidate = f.resolve({ tag: 'h1', text: 'Heading', attrs: {} }).candidates[0];
  const plan = f.plan([{ source: candidate.source, text: 'Saved heading', styles: { color: 'red' }, attrs: { title: 'Literal' } }]); f.apply(plan);
  const actual = fs.readFileSync(path.join(f.root, 'App.jsx'), 'utf8'); assert.match(actual, /style=\{\{/); assert.match(actual, /"color": "red"/); assert.match(actual, /Saved heading/); assert.match(actual, /className="text-blue-500"/);
  assert.equal(fs.readFileSync(path.join(f.root, 'styles.css'), 'utf8'), '.text-blue-500 { color:blue }');
});
for (const [file, input] of [
  ['Card.vue', '<script setup>const label = "dynamic";</script>\n<template><h2 id="static">Static card</h2><p>{{ label }}</p></template><style scoped>h2{color:blue}</style>'],
  ['Card.svelte', '<script>let label = "dynamic";</script>\n<h2 id="static">Static card</h2><p>{label}</p><style>h2{color:blue}</style>'],
  ['Card.astro', '---\nconst label = "dynamic";\n---\n<h2 id="static">Static card</h2><p>{label}</p><style>h2{color:blue}</style>']
]) test('literal template subset: ' + file, t => {
  const f = setup(t, { [file]: input });
  const source = f.resolve({ tag: 'h2', text: 'Static card', attrs: { id: 'static' } }).candidates[0].source;
  f.apply(f.plan([{ source, text: 'Changed card', styles: { padding: '12px' }, attrs: {} }]));
  const actual = fs.readFileSync(path.join(f.root, file), 'utf8'); assert.match(actual, /Changed card/); assert.match(actual, /padding: 12px !important/); assert.match(actual, /h2\{color:blue\}/);
});
test('ambiguous candidates remain explicit; file filter is bounded and excludes outside project', t => {
  const f = setup(t, { 'a.html': '<h1>Same</h1>', 'b.html': '<h1>Same</h1>' });
  const found = f.resolve({ tag: 'h1', text: 'Same', attrs: {} }); assert.equal(found.total, 2);
  const filtered = store.dispatch({ action: 'resolve', origin: f.project.origin, session: f.session.session, descriptor: { tag: 'h1' }, filter: 'b.html' }); assert.equal(filtered.total, 1); assert.equal(filtered.candidates[0].file, 'b.html');
  assert.throws(() => store.openSession('https://localhost.evil.test'), /localhost/);
});
test('dynamic template attributes/text and structure are rejected without partial writes', t => {
  const original = '<template><h2>{{name}}</h2><img :src="photo" :style="styles"><p>Safe</p></template>';
  const f = setup(t, { 'App.vue': original });
  const nodes = key => f.resolve({ tag: key, attrs: {} }).candidates[0].source;
  assert.throws(() => f.plan([{ source: nodes('h2'), text: 'Overwrite', styles: {}, attrs: {} }]), /literal/);
  assert.throws(() => f.plan([{ source: nodes('p'), text: 'First', styles: {}, attrs: {} }, { source: nodes('img'), styles: {}, attrs: { src: '/new.png' } }]), /Dynamic/);
  assert.throws(() => f.plan([{ source: nodes('img'), styles: { color: 'red' }, attrs: {} }]), /Dynamic/);
  assert.throws(() => f.plan([{ source: nodes('p'), styles: {}, attrs: {}, detached: true }]), /Structural/);
  assert.equal(fs.readFileSync(path.join(f.root, 'App.vue'), 'utf8'), original);
});
test('template hash conflicts after discovery and after plan cannot overwrite new work', t => {
  const f = setup(t, { 'index.html': '<h1>Original</h1>' }), source = f.resolve({ tag: 'h1' }).candidates[0].source;
  const plan = f.plan([{ source, text: 'Planned', styles: {}, attrs: {} }]); fs.writeFileSync(path.join(f.root, 'index.html'), '<h1>External edit</h1>');
  assert.throws(() => f.apply(plan), /CONFLICT/); assert.throws(() => f.plan([{ source, text: 'Stale', styles: {}, attrs: {} }]), /changed/);
  assert.equal(fs.readFileSync(path.join(f.root, 'index.html'), 'utf8'), '<h1>External edit</h1>');
});
test('template parser preserves source ranges and ignores scripts/styles/components', () => {
  const source = '<script>const fake = "<h1>Fake</h1>"</script><Fancy/><h1>Real</h1><style>h1{color:red}</style>';
  const nodes = discovery.elements(source, 'x.svelte'); assert.equal(nodes.filter(n => n.tag === 'h1').length, 1); assert.ok(!nodes.some(n => n.tag === 'fancy'));
});
test('automatic source resolution maps imported styled h1, ignores unrelated h1 and edits source element without shared declarations', t => {
  const f = setup(t, { 'page.tsx': 'import { PageTitle } from "./styles"; export default () => <PageTitle>Hall of Fame</PageTitle>;', 'styles.tsx': 'import styled from "styled-components"; export const PageTitle = styled.h1`color:blue;`;', 'error.tsx': 'export default () => <h1>Something went wrong</h1>;' });
  const found = f.resolve({ tag: 'h1', text: 'Hall of Fame', attrs: {} }); assert.ok(found.automatic); assert.equal(found.match.file, 'page.tsx');
  f.apply(f.plan([{ source: found.automatic, styles: { color: 'red' }, attrs: {}, text: 'Updated title' }]));
  assert.match(fs.readFileSync(path.join(f.root, 'page.tsx'), 'utf8'), /style=\{\{ "color": "red" \}\}/); assert.match(fs.readFileSync(path.join(f.root, 'page.tsx'), 'utf8'), /Updated title/);
  assert.match(fs.readFileSync(path.join(f.root, 'styles.tsx'), 'utf8'), /color:blue/);
});
test('automatic resolver refuses tied or weak tag-only guesses', t => {
  const f = setup(t, { 'a.html': '<h1>Same</h1>', 'b.html': '<h1>Same</h1>' }); assert.equal(f.resolve({ tag: 'h1', text: 'Same' }).automatic, null); assert.equal(f.resolve({ tag: 'h1' }).automatic, null);
});

test('static HTML text runs preserve line breaks, nested emphasis and SVG icons', t => {
  const original = '<h1 class="hero">Hello<br><em>world</em> today</h1><button id="go">Start <svg><path d="M0 0"/></svg></button>';
  const f = setup(t, { 'index.html': original });
  const heading = f.resolve({ tag: 'h1', text: 'Hello today', attrs: { class: 'hero' } }); assert.ok(heading.automatic);
  const button = f.resolve({ tag: 'button', text: 'Start ', attrs: { id: 'go' } }); assert.ok(button.automatic);
  const plan = f.plan([{ source: heading.automatic, textRuns: [{ index: 0, before: 'Hello', after: 'Welcome' }], styles: {}, attrs: {} }, { source: button.automatic, textRuns: [{ index: 0, before: 'Start ', after: 'Go now ' }], styles: {}, attrs: {} }]);
  assert.equal(fs.readFileSync(path.join(f.root, 'index.html'),'utf8'), original); f.apply(plan);
  const actual = fs.readFileSync(path.join(f.root, 'index.html'),'utf8'); assert.match(actual,/Welcome<br><em>world<\/em> today/); assert.match(actual,/Go now <svg><path d="M0 0"\/><\/svg>/);
});
test('text run conflicts and unsupported framework segments never silently write', t => {
  const f = setup(t, { 'index.html': '<h1 id="title">Hello<br>world</h1>', 'App.jsx': 'export default () => <h2>Static</h2>;' });
  const html = f.resolve({tag:'h1',text:'Helloworld',attrs:{id:'title'}}).automatic;
  assert.throws(()=>f.plan([{source:html,textRuns:[{index:0,before:'Wrong',after:'Changed'}],styles:{},attrs:{}}]),/no longer matches/);
  const jsx = f.resolve({tag:'h2',text:'Static',attrs:{}}).automatic;
  assert.throws(()=>f.plan([{source:jsx,textRuns:[{index:0,before:'Static',after:'Changed'}],styles:{},attrs:{}}]),/requires static HTML/);
});
