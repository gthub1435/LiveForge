'use client';
import React from 'react';
import styled from 'styled-components';
const Card = styled.section`
  color: navy;
  background: white;
  padding: 24px;
  border-radius: 18px;
`;
export default function Page() {
  return <main><h1 data-lle-id="source-title" style={{ color: 'blue', fontSize: 44 }}>Original source heading</h1><Card data-lle-id="source-card"><h2>Styled source card</h2><p>Change the card color and inspect the original tagged template.</p></Card><button data-lle-id="source-button">Literal button</button></main>;
}
