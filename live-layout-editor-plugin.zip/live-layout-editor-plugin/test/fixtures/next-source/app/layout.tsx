import React from 'react';
export default function Layout({ children }: { children: React.ReactNode }) { return <html><body style={{ margin: 0, padding: 70, background: '#eef0f7', fontFamily: 'system-ui' }}>{children}</body></html>; }
