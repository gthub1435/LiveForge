import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { withLiveLayout } = require('../../../source/next-adapter.cjs');
export default withLiveLayout({ compiler: { styledComponents: true } });
