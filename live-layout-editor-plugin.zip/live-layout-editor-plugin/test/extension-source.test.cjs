'use strict';
// Real Chromium extension -> Native Messaging -> companion -> Next source files.
// Requires the isolated Next fixture running on localhost:3197.
const assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const { chromium } = require('playwright'), store = require('../source/store.cjs'), { register } = require('../source/companion.cjs');
(async () => {
  const packageRoot = path.resolve(__dirname, '..'), fixture = path.join(__dirname, 'fixtures/next-source'), origin = 'http://localhost:3197';
  const pageFile = path.join(fixture, 'app/page.tsx'), original = fs.readFileSync(pageFile, 'utf8');
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'lle-extension-'));
  const oldState = process.env.LLE_STATE_DIR; process.env.LLE_STATE_DIR = path.join(temporary, 'state');
  const extension = path.join(temporary, 'extension'); fs.cpSync(path.join(packageRoot, 'extension'), extension, { recursive: true });
  const manifestFile = path.join(extension, 'manifest.json'), manifest = JSON.parse(fs.readFileSync(manifestFile));
  // Automated tests have no browser-toolbar gesture to grant activeTab.
  // Only this temporary test copy gets localhost host permissions.
  manifest.host_permissions = ['http://localhost/*', 'https://example.test/*']; fs.writeFileSync(manifestFile, JSON.stringify(manifest));
  const id = fs.readFileSync(path.join(extension, 'EXTENSION-ID.txt'), 'utf8').trim();
  store.connect(fixture, origin); register(id);
  let context;
  try {
    context = await chromium.launchPersistentContext(path.join(temporary, 'profile'), { channel: 'chromium', headless: true, viewport: { width: 1480, height: 1080 }, args: ['--disable-extensions-except=' + extension, '--load-extension=' + extension], env: { ...process.env } });
    let worker = context.serviceWorkers()[0]; if (!worker) worker = await context.waitForEvent('serviceworker');
    const ping = await worker.evaluate(async () => chrome.runtime.sendNativeMessage('app.livelayout.companion', { action: 'ping' }));
    assert.equal(ping.ok, true); console.log('PASS native companion handshake');
    const page = await context.newPage(), errors = [];
    page.on('pageerror', e => errors.push(e.message)); await page.goto(origin); await page.locator('[data-lle-id="source-title"]').waitFor();
    const marker = await page.locator('[data-lle-id="source-title"]').getAttribute('data-lle-source'); assert.ok(marker, 'Next development adapter must attach source markers');
    const tabId = await worker.evaluate(async origin => (await chrome.tabs.query({ url: origin + '/*' })).at(-1).id, origin);
    const controller = await context.newPage(); await controller.goto('chrome-extension://' + id + '/popup.html');
    const start = async options => {
      const result = await controller.evaluate(async args => chrome.runtime.sendMessage({ kind: 'lle', action: 'start', tab: args.tabId, mode: 'source', autoApply: args.auto, allowShared: true }), { tabId, auto: options.auto });
      assert.equal(result.ok, true, result.error);
      await page.getByRole('status').filter({ hasText: 'Connected to source' }).waitFor();
    };
    await start({ auto: false });
    const ui = page.locator('[data-live-layout-editor]');
    assert.equal(await ui.getByRole('button', { name: 'Apply changes in code', exact: true }).isDisabled(), true);
    await page.locator('[data-lle-id="source-title"]').dblclick(); await page.keyboard.insertText('Heading from the real extension'); await page.mouse.click(4, 4);
    assert.equal(fs.readFileSync(pageFile, 'utf8'), original);
    await ui.getByRole('button', { name: 'Apply changes in code', exact: true }).click();
    // Review uses a closed shadow root; the production dialog is still actionable
    // through keyboard focus: Cancel starts focused, Shift+Tab targets Apply.
    await page.locator('[data-lle-review]').waitFor(); await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Enter');
    await page.getByRole('status').filter({ hasText: 'Updated original source' }).waitFor();
    assert.match(fs.readFileSync(pageFile, 'utf8'), /Heading from the real extension/);
    assert.equal(fs.existsSync(path.join(fixture, 'live-layout-changes')), false);
    await page.reload(); await page.locator('[data-lle-id="source-title"]').filter({ hasText: 'Heading from the real extension' }).waitFor();
    console.log('PASS manual source review, original JSX write, and reload persistence');
    // Start a fresh editing session after Next's hot refresh.
    await start({ auto: true });
    await page.locator('[data-lle-id="source-title"]').dblclick();
    await page.locator('[data-lle-id="source-title"]').click({button:'right'});
    await ui.getByRole('spinbutton', { name: 'Font size', exact: true }).click();
    await ui.locator('#quickColor').evaluate(el => { el.value = '#dc143c'; el.dispatchEvent(new Event('input', { bubbles: true })); });
    await page.waitForTimeout(600);
    assert.doesNotMatch(fs.readFileSync(pageFile, 'utf8'), /#dc143c/);
    await ui.getByRole('button', { name: 'Apply changes in code', exact: true }).click();
    await page.locator('[data-lle-review]').waitFor(); await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Enter');
    await page.getByRole('status').filter({ hasText: 'Updated original source' }).waitFor();
    assert.match(fs.readFileSync(pageFile, 'utf8'), /"color": "#dc143c"/);
    console.log('PASS obsolete auto-apply option ignored; explicit source review edits original inline style');
    await page.reload(); await page.locator('[data-lle-id="source-card"]').waitFor(); await start({ auto: false });
    await page.locator('[data-lle-id="source-card"] h2').dblclick(); await page.locator('[data-lle-id="source-card"] h2').click({button:'right'}); await ui.getByRole('button', { name: 'Parent', exact: true }).click();
    await ui.locator('#quickColor').evaluate(el => { el.value = '#228855'; el.dispatchEvent(new Event('input', { bubbles: true })); });
    await ui.getByRole('button', { name: 'Apply changes in code', exact: true }).click();
    await page.locator('[data-lle-review]').waitFor(); await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Enter');
    await page.getByRole('status').filter({ hasText: 'Updated original source' }).waitFor();
    assert.match(fs.readFileSync(pageFile, 'utf8'), /color: #228855;/);
    console.log('PASS shared styled declaration is edited in the original template');
    // Unconnected live origins cannot reach the companion through the extension.
    const unrelated = await context.newPage(); await unrelated.route('https://example.test/**', route => route.fulfill({ contentType: 'text/html', body: '<h1>Unconnected live site</h1>' })); await unrelated.goto('https://example.test/');
    const liveTab = await worker.evaluate(async () => (await chrome.tabs.query({ url: 'https://example.test/*' })).at(-1).id);
    const denied = await controller.evaluate(async tab => chrome.runtime.sendMessage({ kind: 'lle', action: 'start', tab, mode: 'source' }), liveTab);
    assert.equal(denied.ok, false); assert.match(denied.error, /preview-only/);
    console.log('PASS live-site source connection rejected');
    assert.deepEqual(errors, []);
  } finally {
    if (context) await context.close(); fs.writeFileSync(pageFile, original);
    if (oldState === undefined) delete process.env.LLE_STATE_DIR; else process.env.LLE_STATE_DIR = oldState;
    // Restore the installed host registration to the durable package location.
    register(id); fs.rmSync(temporary, { recursive: true, force: true });
  }
})().catch(e => { console.error(e); process.exitCode = 1; });
