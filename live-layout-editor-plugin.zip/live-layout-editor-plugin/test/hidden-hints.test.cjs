'use strict';
const assert = require('node:assert/strict'), http = require('node:http');
const { chromium } = require('playwright'), { browserPlugin } = require('../live-layout-editor.cjs');
(async () => {
  const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end('<!doctype html><html><head><style>body{padding:80px;min-height:2000px}#a{display:inline-flex;color:blue}#b{margin-top:300px}</style></head><body><button id="a">First element</button><p id="b">Second element</p></body></html>'); });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); let browser;
  try {
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] }); const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } }), errors = [];
    page.on('pageerror', e => errors.push(e.message)); await page.goto('http://127.0.0.1:' + server.address().port); await page.addScriptTag({ content: '(' + browserPlugin.toString() + ')({});' });
    const ui = page.locator('[data-live-layout-editor]');
    await page.locator('#a').click({ button: 'right' }); await ui.locator('#quickColor').evaluate(n => { n.value = '#ff0000'; n.dispatchEvent(new Event('input', { bubbles: true })); });
    await ui.getByRole('button', { name: 'Hide', exact: true }).click(); assert.equal(await page.locator('#a').isVisible(), false);
    const first = ui.locator('[data-hidden-marker]').filter({ hasText: 'button#a' }); assert.equal(await first.isVisible(), true);
    await page.locator('#b').dblclick(); await page.keyboard.insertText('Second changed'); await page.mouse.click(4, 4);
    await page.locator('#b').click({ button: 'right' }); await ui.getByRole('button', { name: 'Hide', exact: true }).click(); assert.equal(await page.locator('#b').isVisible(), false);
    assert.equal(await ui.locator('#hiddenSummary').textContent(), 'Hidden elements · 2');
    await first.click(); assert.equal(await page.locator('#a').isVisible(), true); assert.equal(await page.locator('#a').evaluate(n => getComputedStyle(n).color), 'rgb(255, 0, 0)'); assert.equal(await page.locator('#a').evaluate(n => getComputedStyle(n).display), 'inline-flex');
    assert.equal(await page.locator('#b').isVisible(), false); assert.equal(await page.locator('#b').textContent(), 'Second changed');
    await ui.getByRole('button', { name: 'Undo', exact: true }).click(); assert.equal(await page.locator('#a').isVisible(), false); assert.equal(await first.isVisible(), true);
    await ui.getByRole('button', { name: 'Redo', exact: true }).click(); assert.equal(await page.locator('#a').isVisible(), true);
    await page.evaluate(() => scrollTo(0, 1200)); await page.waitForTimeout(300);
    const second = ui.locator('[data-hidden-marker]').filter({ hasText: 'p#b' }); assert.equal(await second.isVisible(), false);
    await ui.locator('#hiddenSummary').click(); await ui.locator('#hiddenList button').filter({ hasText: 'p#b' }).click();
    assert.equal(await page.locator('#b').isVisible(), true); assert.equal(await page.locator('#b').textContent(), 'Second changed');
    assert.equal(await ui.locator('#hiddenRack').isVisible(), false);
    await ui.getByRole('button', { name: 'Reset page', exact: true }).click(); assert.equal(await ui.locator('[data-hidden-marker]').count(), 0); assert.equal(await page.locator('#b').textContent(), 'Second element');
    await page.reload(); assert.equal(await page.locator('#a').isVisible(), true); assert.equal(await page.locator('#b').isVisible(), true);
    assert.deepEqual(errors, []); console.log('PASS named hidden markers, per-element Show without unrelated undo, display/color/text preservation, Undo/Redo, offscreen list restore and reset');
  } finally { if (browser) await browser.close(); server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
})().catch(error => { console.error(error); process.exitCode = 1; });
