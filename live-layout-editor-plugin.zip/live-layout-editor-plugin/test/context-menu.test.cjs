'use strict';
const assert = require('node:assert/strict'), http = require('node:http');
const { chromium } = require('playwright'), { browserPlugin } = require('../live-layout-editor.cjs');
(async () => {
  const server = http.createServer((req, res) => { res.setHeader('Content-Type', 'text/html'); res.end('<!doctype html><html><body><h1 id="headline" style="margin:80px">Right click to edit</h1><p id="other">Other element</p></body></html>'); });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); let browser;
  try {
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] }); const page = await browser.newPage({ viewport: { width: 1200, height: 900 } }), errors = [];
    page.on('pageerror', e => errors.push(e.message)); await page.goto('http://127.0.0.1:' + server.address().port); await page.addScriptTag({ content: '(' + browserPlugin.toString() + ')({});' });
    const ui = page.locator('[data-live-layout-editor]'), menu = ui.locator('#quickbar');
    await page.locator('#headline').dblclick(); assert.equal(await menu.isVisible(), false); assert.equal(await ui.locator('#inspector').isVisible(), false);
    await page.keyboard.insertText('Inline remains available'); await page.mouse.click(3, 3); assert.equal(await page.locator('#headline').textContent(), 'Inline remains available');
    await page.locator('#headline').click({ button: 'right' }); assert.equal(await menu.isVisible(), true);
    for (const name of ['Parent', 'Bring to front', 'Send to back', 'Bring forward', 'Send backward', 'Free element', 'Free children', 'Replace', 'Image file', 'Hide', 'More', 'Done']) assert.equal(await menu.getByRole('button', { name, exact: true }).isVisible(), true);
    await menu.getByRole('button', { name: 'More', exact: true }).click(); assert.equal(await ui.locator('#inspector').evaluate(n => n.closest('#quickbar') !== null), true);
    await menu.getByText('Any CSS property', { exact: true }).click(); await menu.locator('#customProp').fill('letter-spacing'); await menu.locator('#customValue').fill('2px'); await menu.getByRole('button', { name: 'Set CSS', exact: true }).click();
    assert.equal(await page.locator('#headline').evaluate(n => getComputedStyle(n).letterSpacing), '2px');
    await page.keyboard.press('Escape'); assert.equal(await menu.isVisible(), false); assert.equal(await ui.locator('#outline').evaluate(n => n.style.display), 'block');
    await page.keyboard.press('Shift+F10'); assert.equal(await menu.isVisible(), true);
    await page.mouse.click(5, 5); assert.equal(await menu.isVisible(), false);
    await page.locator('#other').evaluate(n => n.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, clientX: 1199, clientY: 899 })));
    const r = await menu.boundingBox(); assert.ok(r.x >= 0 && r.y >= 0 && r.x + r.width <= 1200 && r.y + r.height <= 900);
    await page.setViewportSize({ width: 320, height: 640 }); await page.waitForTimeout(300); const small = await menu.boundingBox(); assert.ok(small.x >= 0 && small.x + small.width <= 320 && small.y + small.height <= 640, JSON.stringify(small));
    await page.keyboard.press('Escape'); await ui.locator('#cssClose').click(); await page.locator('#other').dblclick(); assert.equal(await menu.isVisible(), false);
    assert.deepEqual(errors, []); console.log('PASS clean double-click, right-click options and nested details, keyboard menu/Escape, outside dismissal, viewport clamping');
  } finally { if (browser) await browser.close(); server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
})().catch(error => { console.error(error); process.exitCode = 1; });
