'use strict';
const { test } = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), os = require('node:os');
const { validatePackage } = require('../source/install.cjs');
test('installer rejects a lone CMD extracted by ZIP opening, before changing host registration', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'lle-incomplete-')); t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.writeFileSync(path.join(root, 'INSTALL-COMPANION.cmd'), '@echo off');
  assert.throws(() => validatePackage(root), /Extract All/);
  assert.doesNotThrow(() => validatePackage(path.resolve(__dirname, '..')));
});
