'use strict';
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const root = path.resolve(__dirname, '..'), { browserPlugin } = require('../live-layout-editor.cjs');
const file = path.join(root, 'extension/manifest.json'), manifest = JSON.parse(fs.readFileSync(file));
if (!manifest.key) { const { publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 }); manifest.key = publicKey.export({ type: 'spki', format: 'der' }).toString('base64'); fs.writeFileSync(file, JSON.stringify(manifest, null, 2) + '\n'); }
fs.writeFileSync(path.join(root, 'extension/editor-runtime.js'), '/* Packaged UI: no remote code or eval. */\nglobalThis.__LLE_BRAND__ = ' + JSON.stringify('data:image/png;base64,' + fs.readFileSync(path.join(root, 'extension/icons/logo-128.png')).toString('base64')) + ';\nglobalThis.__LLE_BROWSER_PLUGIN__ = ' + browserPlugin.toString() + ';\n');
const id = crypto.createHash('sha256').update(Buffer.from(manifest.key, 'base64')).digest('hex').slice(0, 32).replace(/[0-9a-f]/g, c => String.fromCharCode(97 + parseInt(c, 16)));
fs.writeFileSync(path.join(root, 'extension/EXTENSION-ID.txt'), id + '\n'); console.log('Extension ID: ' + id);
